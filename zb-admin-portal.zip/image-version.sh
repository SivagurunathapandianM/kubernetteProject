image_name=zb-platform/admin-portal
image_version=1.5.1

if [[ $BUILD_SOURCEBRANCHNAME != 'master' ]];then
    export image_version=$image_version-$(date +%s)
    echo "Running on non-master, snapshot image version: $image_version"
fi

artifactory_registry=docker-sco-local.artifact.swissre.com
azure_registry=orcdev.azurecr.io

artifactory_image="$artifactory_registry/$image_name:$image_version"
azure_image="$azure_registry/$image_name:$image_version"

echo -n "Artifactory image:";echo $artifactory_image | tee artifactory-image.txt
echo -n "Azure image:";echo $azure_image | tee azure-image.txt
echo -n "Image version:";echo $image_version | tee image-version.txt

