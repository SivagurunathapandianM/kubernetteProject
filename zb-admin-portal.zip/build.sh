#!/bin/bash
cd "$(dirname "$0")"
export AQUA_ARTIFACTORY_PASS=$1

# Source build env vars
. env.sh
. image-version.sh

# Build jar file
mvn -f ./zeebe-simple-monitor/pom.xml clean package

# Error code, F=fatal / W=warn, Error message
ERR_IMAGEVER=(1 F "Error getting image version, exiting...")
ERR_DOCKER_BUILD=(2 F "Error while building image, exiting...")
ERR_MVN_DEPS=(3 F "Error getting mvn dependencies, exiting...")
ERR_PUSH_ACR=(4 F "Error pushing to ACR, exiting.")
ERR_PUSH_ARTI=(5 W "Error pushing to Artifactory, continuing...")
ERR_AQUA=(5 W "Error scanning image with Aqua, continuing...")

function chkErr() {
    local ret=$1
    shift
    local err=("$@")
    if [[ $ret -eq 0 ]];then
        return
    else
        echo ${err[2]} 1>&2
        if [[ ${err[1]} == "F" ]];then
            exit ${err[0]}
        fi
    fi
}

chkErr $? "${ERR_IMAGEVER[@]}"

cat aks-config/Dockerfile.tmpl | envsubst >Dockerfile
docker build -t $artifactory_image -t $azure_image .
chkErr $? "${ERR_MVN_DEPS[@]}"

docker push  $artifactory_image
chkErr $? "${ERR_PUSH_ARTI[@]}"

docker run --rm -v /var/run/docker.sock:/var/run/docker.sock docker-aqua-local.artifact.swissre.com/aqua-scanner-swissre:latest scan -H https://docker-scan.swissre.com/  -U $AQUA_USER -P "$AQUA_ARTIFACTORY_PASS" --html --local -n $artifactory_image --no-verify >../../aquascan.html
chkErr $? "${ERR_AQUA[@]}"

docker push $azure_image
chkErr $? "${ERR_PUSH_ACR[@]}"

echo Done.

exit 0


