#!/usr/bin/env bash

while :;do
java -javaagent:/glowroot/glowroot.jar -Dglowroot.data.dir=/tmp/glowroot/datadir \
    -Dglowroot.log.dir=/tmp/glowroot/logdir -Dglowroot.tmp.dir=/tmp/glowroot/tmpdir \
    -jar simple-monitor.jar -Xmx3300m -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp
  sleep 20
done
