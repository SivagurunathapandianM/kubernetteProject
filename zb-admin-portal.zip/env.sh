export APP_NAME=admin-portal
export DNS_HOSTNAME=admin
export APP_HOME=/app/
export SIMPLEMON_VERSION=0.20.1
export NS=zb
