#!/bin/bash
cd "$(dirname "$0")"
#set -x
. env.sh

case $1 in
		DEV)
				# DEV
#				export GW_LBIP=172.23.164.97
#				export ING_LBIP=172.23.164.98
#				export LB_SUBNET="SR-SCO-DEV-WE-ZEEBE-SN-01"
				export AKS_ENV="sco-dev"
				;;
		NONPROD)
				# NP
				export GW_LBIP=172.23.216.98
				export ING_LBIP=172.23.216.97
				export LB_SUBNET="SCO-NP-LB"
				export AKS_ENV="sco-np"
				;;
		PROD)
				# P
				export GW_LBIP=172.23.224.160
				export ING_LBIP=172.23.224.159
				export LB_SUBNET="SCO-PROD-LB"
				export AKS_ENV="sco"
				;;
		*)
				echo "Arg1: DEV, NONPROD, PROD"
				exit 1
esac

export ENVIRONMENT=$1
export SA=zb-sa

if [[ "$#" -eq 2 && -n $2 ]]; then
	export K8SConfig=$2
	echo -n $K8SConfig | base64 -d >kube.config
	export KUBECONFIG=$PWD/kube.config
	echo ***\\n\\nSecond argument found, using as custom kube.config
fi

# echo Setting proxy
# export HTTPS_PROXY=http://gate.zrh.swissre.com:8080/
# export HTTP_PROXY=http://gate.zrh.swissre.com:8080/
# export NO_PROXY=localhost,127.0.0.1,.swissre.com,.sccloud.swissre.com,.corp.gwpnet.com,.swissreapps.com,.swissreapps-np.com,.swissreapps-ee.com
# export http_proxy=http://gate.zrh.swissre.com:8080/
# export https_proxy=http://gate.zrh.swissre.com:8080/
# export no_proxy=localhost,127.0.0.1,.swissre.com,.sccloud.swissre.com,.corp.gwpnet.com,.swissreapps.com,.swissreapps-np.com,.swissreapps-ee.com

alias kubectl=/usr/local/bin/kubectl
kubectl cluster-info
kubectl config current-context

ERR_APP_DEL=(1 W "Cannot delete statefulset, continuing...")
ERR_APP_APPLY=(2 F "Error applying statefulset, exiting...")
ERR_SVC_DEL=(3 W "Cannot delete service, continuing...")
ERR_SVC_APPLY=(4 F "Error applying service, exiting...")
ERR_ING_DEL=(5 W "Cannot delete ingress, continuing...")
ERR_ING_APPLY=(6 F "Cannot apply ingress, exiting...")

function chkErr() {
		local ret=$1
		shift
		local err=("$@")
		if [ $ret -eq 0 ];then				
				return
		else
				echo ${err[2]} 1>&2
				if [ ${err[1]} == "F" ];then
						rm -f kube.config
						exit ${err[0]}
				fi				
		fi
}

echo "pwd: $PWD"

export AP_IMAGE_VERSION=$(cat ./image-version.txt)
echo -e ***\\n\\n  Admin Portal Image version: ${AP_IMAGE_VERSION}

export AP_AZURE_IMAGE=$(cat ./azure-image.txt)
echo -e ***\\n\\n  Admin Portal Azure image: ${AP_AZURE_IMAGE}

# Local dev
if [[ -z "$AGENT_WORKFOLDER" ]]; then
# if we're not in a CD pipeline
  echo 'Deploying locally...'
  cd aks-config
fi

echo -e ***\\n  Deploying Statefulset
kubectl -n $NS delete statefulset.apps/$APP_NAME
chkErr $? "{ERR_APP_DEL[@]}"
cat statefulset.yaml | envsubst | kubectl -n $NS apply -f -
chkErr $? "{ERR_APP_APPLY[@]}"

echo -e ***\\n  Deploying service
kubectl -n $NS delete service/$APP_NAME
chkErr $? "{ERR_SVC_DEL[@]}"
cat service.yaml | envsubst | kubectl -n $NS apply -f -
chkErr $? "{ERR_SVC_APPLY[@]}"

echo -e ***\\n  Deploying ingress
kubectl -n $NS delete ing $APP_NAME-ingress
chkErr $? "{ERR_ING_DEL[@]}"
cat ingress.yaml | envsubst | kubectl -n $NS apply -f -
chkErr $? "{ERR_ING_APPLY[@]}"

echo -e ***\\n  Deployment Finished

echo -e ***\\n  Validating release...
success=false
echo "    Checking Admin Portal..."				
for i in {0..10};do
		if [ $i != 0 ];then echo -ne "      Sleeping 20 secs - ";date;sleep 20;fi

		kubectl -n zb get all | grep -e "statefulset.apps/admin-portal *1/1" >/dev/null
		if [ $? == 0 ];then
				echo "    Admin Portal Running..."
				success=true
				break
		fi
done

rm -f kube.config

if [ $success != true ];then
		echo -e ***\\n  Release validation failed. Please check the cluster if it is deployed correctly.
		exit 9
fi

echo -e ***\\n  Admin Portal up and running, exiting.
exit 0
