package io.zeebe.monitor.utils;

import io.zeebe.monitor.entity.VariableEntity;
import io.zeebe.monitor.rest.AuditLogEntry;
import io.zeebe.monitor.rest.InstanceEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class InstanceEventTimelineHelper {

    private static final Logger LOG = LoggerFactory.getLogger(InstanceEventTimelineHelper.class);

    public static final String ACTIVATING_EVENT = "ELEMENT_ACTIVATING";

    public static final Map<String, String> ELEMENT_ICON_MAP = new HashMap<>();

    static {
        // Icon pack demo: https://cdn.staticaly.com/gh/bpmn-io/bpmn-font/master/dist/demo.html
        ELEMENT_ICON_MAP.put("PROCESS", "bpmn-icon-data-object");
        ELEMENT_ICON_MAP.put("START_EVENT", "bpmn-icon-start-event-none");
        ELEMENT_ICON_MAP.put("END_EVENT", "bpmn-icon-end-event-none");
        ELEMENT_ICON_MAP.put("MULTI_INSTANCE_BODY", "bpmn-icon-parallel-mi-marker");
        ELEMENT_ICON_MAP.put("SUB_PROCESS", "bpmn-icon-sub-process-marker");
        ELEMENT_ICON_MAP.put("PARALLEL_GATEWAY", "bpmn-icon-gateway-parallel");
        ELEMENT_ICON_MAP.put("EXCLUSIVE_GATEWAY", "bpmn-icon-gateway-xor");
        ELEMENT_ICON_MAP.put("EVENT_BASED_GATEWAY", "bpmn-icon-gateway-eventbased");
        ELEMENT_ICON_MAP.put("SERVICE_TASK", "bpmn-icon-service-task");
        ELEMENT_ICON_MAP.put("INTERMEDIATE_CATCH_EVENT", "bpmn-icon-intermediate-event-catch-timer");
        ELEMENT_ICON_MAP.put("CALL_ACTIVITY", "bpmn-icon-call-activity");
    }

    public static Map<Long, Map<String, Object>> collectVariablesByScope(Collection<List<VariableEntity>> variableEntities){
        Map<Long, Map<String, Object>> variables = new HashMap<>();

        for (List<VariableEntity> variableEntityList : variableEntities){
            for (VariableEntity ve : variableEntityList){
                Map<String, Object> variablesForScope = variables.computeIfAbsent(
                        ve.getScopeKey(),
                        scopeKey -> new HashMap<>());

                variablesForScope.put(ve.getName(), ve.getValue());
            }
        }

        return variables;
    }

    public static InstanceEvent constructTimeline(
            List<AuditLogEntry> auditLogEntries){
        Map<Long, InstanceEvent> eventSet = new HashMap<>();
        List<AuditLogEntry> sortedLogEntries = new LinkedList<>(auditLogEntries);
        sortedLogEntries.sort(Comparator.comparing(AuditLogEntry::getTimestamp));

        InstanceEvent main = new InstanceEvent();

        for (AuditLogEntry entry : sortedLogEntries){
            if (entry.getState().equals(ACTIVATING_EVENT)){
                InstanceEvent event = new InstanceEvent(entry);
                InstanceEvent parent = eventSet.get(event.getScope());

                if (parent != null) {
                    parent.getEventList().add(event);
                } else if (event.getElementType().equals("PROCESS")) {
                    main = event;
                }

                eventSet.put(event.getKey(), event);
            }
        }

        LOG.trace("# of unused events: {}", (sortedLogEntries.size() - eventSet.size()));
        LOG.trace("\n------\n" + main.toPrettyString() + "------\n");

        return main;
    }

}
