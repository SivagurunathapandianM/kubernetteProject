package io.zeebe.monitor.entity;

public interface ElementInstanceStatistics {

  String getElementId();

  long getCount();
}
