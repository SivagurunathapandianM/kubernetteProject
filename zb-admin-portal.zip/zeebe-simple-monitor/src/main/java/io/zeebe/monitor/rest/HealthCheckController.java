package io.zeebe.monitor.rest;

import io.zeebe.monitor.entity.AdminDelayEntity;
import io.zeebe.monitor.repository.AdminDelayRepository;
import io.zeebe.monitor.repository.HazelcastConfigRepository;
import io.zeebe.monitor.repository.WorkflowInstanceRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import javax.transaction.Transactional;
import java.util.Optional;

@Controller
public class HealthCheckController {

    private static final Logger LOG = LoggerFactory.getLogger(HealthCheckController.class);

    @Autowired
    private WorkflowInstanceRepository workflowInstanceRepository;

    @Autowired
    private HazelcastConfigRepository hazelcastConfigRepository;

    @Autowired
    private AdminDelayRepository adminDelayRepository;

    @GetMapping("/health/instances/{key}")
    @Transactional
    public ResponseEntity<Boolean> instanceHealth(
            @PathVariable long key) {

        Boolean response = workflowInstanceRepository
                .findByKey(key)
                .isPresent();

        return new ResponseEntity<>(
                response,
                response ? HttpStatus.OK : HttpStatus.NOT_FOUND);
    }

    @GetMapping("/import-delay")
    @Transactional
    public ResponseEntity<Long> fetchImportDelay() {
        Long delay = -1L;
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        Optional<AdminDelayEntity> topRecord = adminDelayRepository
                .findTopByOrderByIdDesc();

        if (topRecord.isPresent()){
            delay = topRecord.get().getDelay();
            if (delay == null){
                // current check is still ongoing,
                // calculate what the delay is so far
                delay = System.currentTimeMillis() - (topRecord.get().getCreated() * 1000L);
            }
            status = HttpStatus.OK;
        } else {
            LOG.warn("No AdminDelay records found in database.");
        }

        return new ResponseEntity<>(delay, status);
    }
}
