package io.zeebe.monitor.security;

import io.zeebe.monitor.ZeebeSimpleMonitorApp;
import io.zeebe.monitor.entity.IncidentEntity;
import io.zeebe.monitor.entity.JobEntity;
import io.zeebe.monitor.entity.WorkflowEntity;
import io.zeebe.monitor.entity.WorkflowInstanceEntity;
import io.zeebe.monitor.repository.IncidentRepository;
import io.zeebe.monitor.repository.JobRepository;
import io.zeebe.monitor.repository.WorkflowInstanceRepository;
import io.zeebe.monitor.repository.WorkflowRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Optional;

@Component
public class SnowGroupBasedPermissionEvaluator implements PermissionEvaluator {

    public static final String RESOURCE_INSTANCE_SHOW_WORKFLOW = "WorkflowInstanceShowWorkflow";
    public static final String RESOURCE_INSTANCE = "WorkflowInstance";
    public static final String RESOURCE_WORKFLOW = "Workflow";
    public static final String RESOURCE_INCIDENT = "Incident";
    public static final String RESOURCE_JOB = "Job";

    private static final Logger LOG = LoggerFactory.getLogger(SnowGroupBasedPermissionEvaluator.class);

    private static final boolean IS_DEV_OR_NONPROD = ZeebeSimpleMonitorApp.ENVIRONMENT.matches("^DEV|NONPROD$");
    private static final boolean IS_DEV = ZeebeSimpleMonitorApp.ENVIRONMENT.equals("DEV");

    @Autowired
    private WorkflowRepository workflowRepository;

    @Autowired
    private WorkflowInstanceRepository workflowInstanceRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private IncidentRepository incidentRepository;

    @Override
    public boolean hasPermission(Authentication authentication, Object o, Object o1) {
        if (IS_DEV){
            return true;
        }

        boolean hasPermission = false;

        if (authentication instanceof OAuth2AuthenticationToken){
            OAuth2AuthenticationToken oAuth2Token = (OAuth2AuthenticationToken) authentication;
            String email = oAuth2Token.getPrincipal().getAttribute("upn");
            if (email == null || email.isEmpty()){
                return false;
            }

            long key = Long.parseLong(String.valueOf(o));
            String resourceType = String.valueOf(o1);
            String bpmnProcessId = "";
            String apm = "";

            if (o == null && resourceType.equals("")){
                return true;
            }

            long parentWorkflowInstanceKey = -1;

            switch (resourceType) {
                case RESOURCE_INSTANCE_SHOW_WORKFLOW:
                case RESOURCE_INSTANCE:
                    Optional<WorkflowInstanceEntity> instance = workflowInstanceRepository.findByKey(key);
                    if (instance.isPresent()) {
                        parentWorkflowInstanceKey = instance.get().getParentWorkflowInstanceKey();
                        bpmnProcessId = instance.get().getBpmnProcessId();
                        apm = extractApmFromBpmnProcessId(bpmnProcessId);
                    }
                    break;
                case RESOURCE_WORKFLOW:
                    Optional<WorkflowEntity> workflow = workflowRepository.findByKey(key);
                    if (workflow.isPresent()) {
                        bpmnProcessId = workflow.get().getBpmnProcessId();
                        apm = extractApmFromBpmnProcessId(bpmnProcessId);
                    }
                    break;
                case RESOURCE_JOB:
                    Optional<JobEntity> job = jobRepository.findByKey(key);
                    if (job.isPresent()) {
                        // the worker's name uses the same naming conventions
                        // thus it can be used for the same purpose
                        bpmnProcessId = job.get().getWorker();
                        apm = extractApmFromBpmnProcessId(bpmnProcessId);
                    }
                    break;
                case RESOURCE_INCIDENT:
                    Optional<IncidentEntity> incident = incidentRepository.findById(key);
                    if (incident.isPresent()) {
                        bpmnProcessId = incident.get().getBpmnProcessId();
                        apm = extractApmFromBpmnProcessId(bpmnProcessId);
                    }
                    break;
                default:
                    LOG.error("The resource type ({}) in @PreAuthorize is wrong!", resourceType);
                    break;
            }

            if (!apm.isEmpty()){
                LOG.info("APM found for resource ({} - {}): {}", resourceType, key, apm);
                hasPermission = AuthUtils.isUserAuthorizedForAPM(email, apm);
            }

            if (!hasPermission && !apm.equals("sco")){
                // Users in SCO have access to all resources
                LOG.info("No permission found for the resource's APM '{}', checking SCO for access...", apm);
                hasPermission = AuthUtils.isUserAuthorizedForAPM(email, "sco");
            }

            if (!hasPermission && resourceType.equals(RESOURCE_INSTANCE_SHOW_WORKFLOW)){
                LOG.info("Show-Workflow view, checking ITIL role for {}", email);
                hasPermission = AuthUtils.doesUserHaveITILRole(email);
                if (hasPermission) {
                    LOG.info("User {} has ITIL role, allowing access", email);
                }
            }

            if (!hasPermission && parentWorkflowInstanceKey > 0){
                // if the user is trying to access a called workflow instance,
                // check if they have permissions to open the parent instance
                return hasPermission(authentication, parentWorkflowInstanceKey, resourceType);
            }
        } else {
            LOG.info("OAuth2 Authentication was unsuccessful.");
        }

        LOG.info("User has permission: {}", hasPermission);

        return hasPermission;
    }

    @Override
    public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType, Object permission) {
        return false;
    }

    public static String extractApmFromBpmnProcessId(String bpmnProcessId){
        String[] bpmnProcessIdArr = bpmnProcessId.split("\\.");
        String apm = "";
        if (bpmnProcessIdArr.length == 2){
            apm = bpmnProcessIdArr[0].toLowerCase();
        }

        return apm;
    }
}