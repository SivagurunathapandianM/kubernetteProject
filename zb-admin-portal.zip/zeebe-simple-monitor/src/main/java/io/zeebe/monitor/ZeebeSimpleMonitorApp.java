/*
 * Copyright © 2017 camunda services GmbH (info@camunda.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.zeebe.monitor;

import io.zeebe.monitor.security.AuthUtils;
import io.zeebe.monitor.security.CredentialCacheHelper;
import io.zeebe.spring.client.EnableZeebeClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.io.IOException;
import java.io.StringReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Arrays;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

@SpringBootApplication
@EnableZeebeClient
@EnableScheduling
@EnableAsync
@EnableSpringDataWebSupport
public class ZeebeSimpleMonitorApp {

  private static final Logger LOG = LoggerFactory.getLogger(ZeebeSimpleMonitorApp.class);
  public static final String ENVIRONMENT = Optional.ofNullable(System.getenv("ENVIRONMENT")).orElse("DEV");
  public static final String APP_VERSION = Optional.ofNullable(System.getenv("APP_VERSION")).orElse("0.0.0");

  public static void main(String... args) {
    try {
      Properties appProps = loadLocalProperties();
      AuthUtils.populateApmToGroupNameMap(appProps);
      CredentialCacheHelper.init();
      SpringApplication.run(ZeebeSimpleMonitorApp.class, args);
    } catch (IOException e) {
      LOG.error("Error during startup!", e);
    }
  }

  private static Properties loadLocalProperties() throws IOException {
    Properties appProps = new Properties();
    appProps.load(ZeebeSimpleMonitorApp.class.getClassLoader().getResourceAsStream("AdminPortal.properties"));

    return appProps;
  }

  // CURRENTLY UNUSED - will be picked up later: SCO-948
  @Deprecated
  private static Properties loadProperties() throws InterruptedException, IOException {
    Properties localProperties = loadLocalProperties();

    LOG.info("Environment is: {}", ENVIRONMENT);
    LOG.info("Altering config file location to: {}", (localProperties.getProperty("configServer.configFileName")).replace("ENVIRONMENT", ENVIRONMENT));
    localProperties.put("configServer.configFileName", (localProperties.getProperty("configServer.configFileName")).replace("ENVIRONMENT", ENVIRONMENT));

    Properties appProps = new Properties();
    boolean isResponseFromConfigServerReceived = false;
    String propertiesAsString = null;
    LOG.info("Fetching environment specific properties from Config Server");

    URI uri = URI.create(
            localProperties.getProperty("configServer.hostRoot") +
            localProperties.getProperty("configServer.filesLocation") +
            localProperties.getProperty("configServer.configFileName")
    );

    LOG.info("Config URI: {}", uri.toString());
    while (!isResponseFromConfigServerReceived) {
      HttpClient httpClient = HttpClient.newHttpClient();
      HttpRequest request = HttpRequest.newBuilder()
              .GET()
              .uri(uri)
              .build();
      HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
      propertiesAsString = response.body();

      if (response.statusCode() == 200) {
        isResponseFromConfigServerReceived = true;
      } else {
        LOG.info("Properties fetching URI: \n{}", request.uri());
        LOG.info("Fetching properties failed: \n{}", response.statusCode());
        LOG.info("Response body: \n{}", response.body());
      }
    }

    LOG.info("Got properties from config server: \n{}", propertiesAsString);
    appProps.load(new StringReader(propertiesAsString));

    return appProps;
  }

  @Bean
  public ScheduledExecutorService scheduledExecutor() {
    return Executors.newSingleThreadScheduledExecutor();
  }

  @Bean
  public Executor asyncExecutor() {
    final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(1);
    executor.setMaxPoolSize(1);
    executor.setQueueCapacity(32);
    executor.initialize();
    return executor;
  }
}
