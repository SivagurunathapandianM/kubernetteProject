package io.zeebe.monitor.rest;

public class HazelcastDto {
    private long head;
    private long tail;
    private long current;

    public long getHead() {
        return head;
    }

    public void setHead(long head) {
        this.head = head;
    }

    public long getTail() {
        return tail;
    }

    public void setTail(long tail) {
        this.tail = tail;
    }

    public long getCurrent() {
        return current;
    }

    public void setCurrent(long current) {
        this.current = current;
    }

    public long getBacklog() {
        return tail - current;
    }

}
