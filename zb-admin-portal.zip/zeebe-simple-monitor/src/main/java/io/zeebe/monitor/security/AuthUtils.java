package io.zeebe.monitor.security;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import io.zeebe.monitor.ZeebeSimpleMonitorApp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.util.UriUtils;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

public class AuthUtils {
    private static final Logger LOG = LoggerFactory.getLogger(AuthUtils.class);

    private static Map<String, String[]> apmToGroupNameMap = new HashMap<>();

    private static final String SNOW_GROUP_MEMBERLIST_ENDPOINT_FORMAT = "https://swissreesm%s.service-now.com//api/now/table/sys_user_grmember?sysparm_query=%s&sysparm_fields=user.email";
    private static final String SNOW_ITIL_ROLE_CHECK_ENDPOINT_FORMAT = "https://swissreesm%s.service-now.com/api/now/table/sys_user?sysparm_query=%s&sysparm_fields=user_name&sysparm_limit=1";
    // DEV is unrestricted, NP and P uses production ESM for queries (group memberships, ITIL role)
    private static final Map<String, String> ENV_TO_SNOW_INSTANCE_MAP = Map.of(
            "DEV", "dev",
            "NONPROD", "",
            "PROD", ""
    );

    public static final String SNOW_ENVIRONMENT = ENV_TO_SNOW_INSTANCE_MAP.getOrDefault(ZeebeSimpleMonitorApp.ENVIRONMENT, "dev");

    public static boolean isUserAuthorizedForAPM(String email, String apm){
        boolean isAuthorized = false;
        String[] groupNames = apmToGroupNameMap.getOrDefault(apm, new String[]{});
        if (groupNames.length == 0){
            LOG.info("No entries in the APM mapping for '{}', not allowing access", apm);
        } else {
            for (String groupName : groupNames){
                LOG.debug("Checking SNOW group: {}", groupName);
                if (isUserPartOfAuthorizedGroup(email, groupName)){
                    LOG.info("User found in group '{}', allowing access", groupName);
                    isAuthorized = true;
                    break;
                }
            }
        }

        return isAuthorized;
    }

    public static boolean doesUserHaveITILRole(String email) {
        LOG.info("Email address: {}", email);
        String authHeader = getSnowAuthHeader();
        boolean userHasRole = false;

        String url =
                String.format(
                        SNOW_ITIL_ROLE_CHECK_ENDPOINT_FORMAT,
                        SNOW_ENVIRONMENT,
                        UriUtils.encode("roles=itil^active=true^email=" + email, StandardCharsets.UTF_8)
                );

        LOG.debug("URL: {}", url);

        final HttpRequest request = HttpRequest.newBuilder()
                .GET()
                .uri(URI.create(url))
                .header("Authorization", authHeader)
                .header("Content-Type", "application/json")
                .build();

        final HttpClient httpClient = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofSeconds(10))
                .build();

        try {
            HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            LOG.info("SNOW Response Code: {}", httpResponse.statusCode());
            LOG.info("SNOW Response Body: {}", httpResponse.body());
            if (httpResponse.statusCode() == HttpStatus.OK.value()){
                Gson gson = new GsonBuilder().create();
                QueryResult queryResult = gson.fromJson(httpResponse.body(), QueryResult.class);
                userHasRole = !queryResult.resultList.isEmpty();
            }
        } catch (IOException | InterruptedException e) {
            LOG.error("Error while getting response from SNOW: ", e);
        }

        return userHasRole;
    }

    private static boolean isUserPartOfAuthorizedGroup(
            String email, String groupName) {

        Set<String> emailAddresses = new HashSet<>();

        LOG.info("Email address: {}", email);

        CredentialCacheHelper.CredentialCache credentialCache = CredentialCacheHelper.get(groupName);
        if (credentialCache != null && credentialCache.isValid()) {
            emailAddresses = credentialCache.getEmailAddresses();
            LOG.info("Members for CI '{}' retrieved from Cache: {}", groupName, emailAddresses);
            LOG.info("Cache valid for {} more minutes",
                    Duration.ofMillis(credentialCache.getValidTo() - System.currentTimeMillis()).toMinutes()
            );
        } else {
            String authHeader = getSnowAuthHeader();

            String url =
                    String.format(
                            SNOW_GROUP_MEMBERLIST_ENDPOINT_FORMAT,
                            SNOW_ENVIRONMENT,
                            UriUtils.encode("group.name=" + groupName, StandardCharsets.UTF_8)
                    );
            LOG.debug("URL: {}", url);

            final HttpRequest request = HttpRequest.newBuilder()
                    .GET()
                    .uri(URI.create(url))
                    .header("Authorization", authHeader)
                    .header("Content-Type", "application/json")
                    .build();

            final HttpClient httpClient = HttpClient.newBuilder()
                    .version(HttpClient.Version.HTTP_2)
                    .connectTimeout(Duration.ofSeconds(10))
                    .build();

            try {
                HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                LOG.info("SNOW Response Code: {}", httpResponse.statusCode());
                LOG.info("SNOW Response Body: {}", httpResponse.body());
                Gson gson = new GsonBuilder().create();
                QueryResult queryResult = gson.fromJson(httpResponse.body(), QueryResult.class);

                emailAddresses = queryResult.getEmailAddressList();
                CredentialCacheHelper.add(groupName, emailAddresses);

                LOG.info("Members for CI '{}' retrieved from SNOW: {}", groupName, emailAddresses);

            } catch (IOException | InterruptedException e) {
                LOG.error("Error while getting response from SNOW: ", e);
            }
        }

        for (String groupMemberEmail : emailAddresses){
            if (groupMemberEmail.equalsIgnoreCase(email)){
                return true;
            }
        }

        return false;
    }

    private static String getSnowAuthHeader() {
        String snowCredentials = String.format(
                "%s:%s",
                System.getenv("SNOW_USER"),
                new String(Base64.getDecoder().decode(System.getenv("SNOW_PASSWORD")))
        );

        return String.format(
                "Basic %s",
                new String(Base64.getEncoder().encode(snowCredentials.getBytes(StandardCharsets.UTF_8)))
        );
    }

    public static class QueryResult {
        public QueryResult() {}

        @SerializedName("result")
        private List<FilteredUserObject> resultList;

        public Set<String> getEmailAddressList(){
            return this.resultList.stream().map(FilteredUserObject::getEmail).collect(Collectors.toSet());
        }

        public List<FilteredUserObject> getResultList() {
            return resultList;
        }

        public void setResultList(List<FilteredUserObject> resultList) {
            this.resultList = resultList;
        }
    }

    public static class FilteredUserObject {
        public FilteredUserObject() {}

        @SerializedName("user.email")
        private String email;

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }
    }

    public static Map<String, String[]> getApmWorkflowMapping(){
        return apmToGroupNameMap;
    }

    public static void populateApmToGroupNameMap(Properties appProps) {
        appProps.forEach((k, v) -> {
            String key = String.valueOf(k);
            if (String.valueOf(key).startsWith("mapping.")){
                String apm = key.substring(8);
                String groupNames = String.valueOf(v);

                LOG.info("APM to Group Name mapping found: {} -> {}", apm, groupNames);

                AuthUtils.getApmWorkflowMapping().put(
                        apm,
                        Arrays.stream(groupNames.split(","))
                                .map(String::trim)
                                .map(String::toUpperCase)
                                .toArray(String[]::new)
                );
            }
        });
    }
}