package io.zeebe.monitor.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CredentialCacheHelper {
    private static final Logger LOG = LoggerFactory.getLogger(CredentialCacheHelper.class);

    private static Map<String, CredentialCache> cachedCredentials = new HashMap<>();

    private static Duration CACHE_LIFESPAN = Duration.ofHours(4L);

    public static void init(){
        try {
            String credentialLifespanEnv = System.getenv("CACHE_LIFESPAN_IN_HOURS");
            long cacheLifespanInHours = Long.parseLong(credentialLifespanEnv);
            CACHE_LIFESPAN = Duration.ofHours(cacheLifespanInHours);
        } catch (NumberFormatException ae){
            LOG.error("CACHE_LIFESPAN environment variable is not a number! Using default ({} hours) instead.", CACHE_LIFESPAN.toHours());
        }
    }

    public static CredentialCache get(String groupName){
        return cachedCredentials.get(groupName);
    }

    public static void add(String groupName, Set<String> emailAddresses){
        cachedCredentials.put(groupName, new CredentialCache(emailAddresses));
    }

    public static class CredentialCache {
        private long validTo = -1;
        private Set<String> emailAddresses;

        public CredentialCache(Set<String> emailAddresses) {
            this.validTo = System.currentTimeMillis() + CACHE_LIFESPAN.toMillis();
            this.emailAddresses = emailAddresses;
        }

        public long getValidTo(){
            return validTo;
        }

        public boolean isValid(){
            return System.currentTimeMillis() < validTo;
        }

        public Set<String> getEmailAddresses() {
            return emailAddresses;
        }
    }
}
