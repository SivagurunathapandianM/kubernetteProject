package io.zeebe.monitor.rest;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import io.zeebe.monitor.utils.InstanceEventTimelineHelper;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class InstanceEvent {
    private String timestamp;
    private long key;
    private long scope; // parent

    @SerializedName("events")
    private List<InstanceEvent> eventList = new LinkedList<>();

    private String elementType;
    private String elementId;
    private String name;
    private String icon;

    public InstanceEvent(AuditLogEntry entry) {
        this.key = entry.getKey();
        this.scope = entry.getFlowScopeKey();
        this.elementType = entry.getBpmnElementType();
        this.name = entry.getElementName();
        this.elementId = entry.getElementId();
        this.timestamp = entry.getTimestamp();
        this.icon = InstanceEventTimelineHelper.ELEMENT_ICON_MAP.getOrDefault(this.elementType, "bpmn-icon-task");
    }

    public InstanceEvent() {}

    public long getScope() {
        return scope;
    }

    public void setScope(long scope) {
        this.scope = scope;
    }

    public List<InstanceEvent> getEventList() {
        return eventList;
    }

    public void setEventList(List<InstanceEvent> eventList) {
        this.eventList = eventList;
    }

    public long getKey() {
        return key;
    }

    public void setKey(long key) {
        this.key = key;
    }

    public String getElementType() {
        return elementType;
    }

    public void setElementType(String elementType) {
        this.elementType = elementType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toPrettyString(){
        return toPrettyString(0);
    }

    public String getElementId() {
        return elementId;
    }

    public void setElementId(String elementId) {
        this.elementId = elementId;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    @Override
    public String toString(){
        return new Gson().toJson(this);
    }

    public String toPrettyString(int depth){
        StringBuilder sb = new StringBuilder();

        sb.append("  ".repeat(depth));
        sb.append((this.eventList.size() > 0) ? "+ " : "- ");
        sb.append(this.elementId);
        sb.append(" (").append(this.elementType).append(")");
        sb.append("\n");

        for (InstanceEvent event : eventList){
            sb.append(event.toPrettyString(depth + 1));
        }

        return sb.toString();
    }
}
