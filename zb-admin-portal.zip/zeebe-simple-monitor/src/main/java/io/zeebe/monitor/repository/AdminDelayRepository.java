package io.zeebe.monitor.repository;

import io.zeebe.monitor.entity.AdminDelayEntity;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;

public interface AdminDelayRepository
        extends PagingAndSortingRepository<AdminDelayEntity, Long> {

  Optional<AdminDelayEntity> findTopByOrderByIdDesc();

}
