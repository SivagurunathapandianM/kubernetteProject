package io.zeebe.monitor.security;

import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.user.OAuth2User;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * TEMPORARY WORKAROUND FOR PROD
 * -----------------
 * NO LONGER IN USE!
 * @see io.zeebe.monitor.security.SnowGroupBasedPermissionEvaluator
**/
@Deprecated
public class EmailBasedPermissionEvaluator implements PermissionEvaluator {
    private static final boolean IS_DEV_OR_NONPROD = System.getenv("ENVIRONMENT").matches("^DEV|NONPROD$");
    private static final List<String> ALLOWED_EMAILS = Arrays.asList(
            "arpad_fejes@swissre.com",
            "attila_monostori@swissre.com",
            "balazs_suru@swissre.com",
            "laszlo_sari@swissre.com",
            "karoly_telekes@swissre.com",
            "prithivirajan_dhamotharan@swissre.com",
            "franz_faul@swissre.com",
            "venkatsathyanarayana_ps@swissre.com",
            "stefan_voegele@swissre.com",
            "pitchiah_n@swissre.com",
            "marton_hever@swissre.com",
            "jakub_ptak@swissre.com",
            "alexey_semenov@swissre.com",
            "igor_talanov@swissre.com"
        );

    private static boolean isEmailAllowed(Authentication auth){
        if (auth != null) {
            OAuth2User user = (OAuth2User) auth.getPrincipal();
            if (user != null){
                final String email = user.getAttribute("upn");
                return email != null && ALLOWED_EMAILS.contains(email.toLowerCase());
            }
        }

        return false;
    }

    @Override
    public boolean hasPermission(Authentication authentication, Object o, Object o1) {
        return IS_DEV_OR_NONPROD || isEmailAllowed(authentication);
    }

    @Override
    public boolean hasPermission(Authentication authentication, Serializable serializable, String s, Object o) {
        return IS_DEV_OR_NONPROD || isEmailAllowed(authentication);
    }
}
