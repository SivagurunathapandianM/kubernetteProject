package io.zeebe.monitor.rest;

public class WorkflowInstanceNotFoundException extends RuntimeException {
    public WorkflowInstanceNotFoundException(String message) {
        super(message);
    }
}
