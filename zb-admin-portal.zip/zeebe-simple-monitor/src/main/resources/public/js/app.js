function showError(message) {
	document.getElementById("errorText").innerHTML = message;
	$('#errorPanel').show();
}

function showSuccess(message) {
	document.getElementById("successText").innerHTML = message;
	$('#successPanel').show();
}

function showInfo(message) {
	document.getElementById("infoText").innerHTML = message;
	$('#infoPanel').show();
}

function showErrorResponse(xhr, ajaxOptions, thrownError) {
	if (xhr.responseJSON) {
		showError(xhr.responseJSON.message);
	}
	else {
		showError(thrownError);
	}
}

// --------------------------------------------------------------------

function reload() {
	history.go(0)
}

// --------------------------------------------------------------------

var stompClient = null;

var subscribedWorkflowInstanceKeys = [];
var subscribedWorkflowKeys = [];
function connect() {
    var socket = new SockJS('/notifications');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function(frame) {
        stompClient.subscribe('/notifications/workflow-instance', function(message) {
            handleMessage(JSON.parse(message.body));
        });
    });
 }

function disconnect() {
    if(stompClient != null) {
        stompClient.disconnect();
    }
}

function sendMessage(msg) {
    stompClient.send("/notifications", {},
    JSON.stringify(msg));
}

function handleMessage(notification) {
     if (subscribedWorkflowInstanceKeys.includes(notification.workflowInstanceKey)) {
         showInfo('Workflow instance has changed.');
     }

     if (subscribedWorkflowKeys.includes(notification.workflowKey)) {
         showInfo('Instance(s) of this workflow have changed.');
     }
 }

 function subscribeForWorkflowInstance(key) {
     subscribedWorkflowInstanceKeys.push(key);
 }

 function subscribeForWorkflow(key) {
    subscribedWorkflowKeys.push(key);
 }

// --------------------------------------------------------------------

function uploadModels() {

	var fileUpload = document.getElementById('documentToUpload');

	var filesToUpload = {
		files: []
	}

	var processUploadedFile = function(fileUpload, index) {
		return function(e) {
        var binary = '';
        var bytes = new Uint8Array( e.target.result );
        var len = bytes.byteLength;
        for (var j = 0; j < len; j++) {
            binary += String.fromCharCode( bytes[ j ] );
        }

        var currentFile = {
        	filename: fileUpload.files[index].name,
        	mimeType: fileUpload.files[index].type,
        	content:  btoa(binary)
        }

        filesToUpload.files.push(currentFile);

        // if all files are processed - do the upload
        if (filesToUpload.files.length == fileUpload.files.length) {
        	uploadFiles();
        }
		};
	}

  // read all selected files
	if(typeof FileReader === 'function' && fileUpload.files.length > 0) {
	    var index;
		for (index = 0; index < fileUpload.files.length; ++index) {

		    var reader = new FileReader();
		    reader.onloadend = processUploadedFile(fileUpload, index);
            reader.readAsArrayBuffer(fileUpload.files[index]);
        }
    }

	var uploadFiles = function() {
	    $.ajax({
           type : 'POST',
           url: '/api/workflows/',
           headers: csrfHeaderObject,
           data:  JSON.stringify(filesToUpload),
           contentType: 'application/json; charset=utf-8',
           success: function (result) {
           	showSuccess("New deployment created.");
           },
           error: function (xhr, ajaxOptions, thrownError) {
          	 showErrorResponse(xhr, ajaxOptions, thrownError);
           },
        	 timeout: 5000,
           crossDomain: true,
	    });
	};
}

// --------------------------------------------------------------------

function createInstance(key) {
	$.ajax({
       type : 'POST',
       url: '/api/workflows/' + key,
       headers: csrfHeaderObject,
       data:  getVariablesDocument(),
       contentType: 'application/json; charset=utf-8',
       success: function (result) {
       	showSuccess("New instance created.");
       },
       error: function (xhr, ajaxOptions, thrownError) {
      	 showErrorResponse(xhr, ajaxOptions, thrownError);
       },
    	 timeout: 5000,
       crossDomain: true,
    });
}

// --------------------------------------------------------------------

function updateVariable(scopeKey, name) {

		var newValue = document.getElementById("variable-new-value-" + scopeKey + "-" + name).value;

		var data = '{"' + name + '":' + newValue + '}';

		$.ajax({
	       type : 'PUT',
	       url:  '/api/instances/' + scopeKey + "/set-variables",
	       headers: csrfHeaderObject,
	       data:  data,
	       contentType: 'application/json; charset=utf-8',
	       success: function (result) {
	       	showSuccess("Variable updated.");
	       },
	       error: function (xhr, ajaxOptions, thrownError) {
	      	 showErrorResponse(xhr, ajaxOptions, thrownError);
	       },
	    	 timeout: 5000,
	       crossDomain: true,
	    });
}

function setVariable() {

		var scopeKeyElement = document.getElementById("variable-scopeKey");
		var scopeKey = scopeKeyElement.options[scopeKeyElement.selectedIndex].value;

		var name = document.getElementById("variable-name").value;

		var newValue = document.getElementById("variable-value").value;

		var data = '{"' + name + '":' + newValue + '}';

		var local = document.getElementById("variable-local").checked;

		var url = '/api/instances/' + scopeKey + "/set-variables";

		if (local) {
			url = url + "-local";
		}

		$.ajax({
	       type : 'PUT',
	       url:  url,
	       headers: csrfHeaderObject,
	       data:  data,
	       contentType: 'application/json; charset=utf-8',
	       success: function (result) {
	       	showSuccess("Variable set.");
	       },
	       error: function (xhr, ajaxOptions, thrownError) {
	      	 showErrorResponse(xhr, ajaxOptions, thrownError);
	       },
	    	 timeout: 5000,
	       crossDomain: true,
	    });
}

// --------------------------------------------------------------------

function updateRetries(jobKey) {
		$.ajax({
	             type : 'PUT',
	             url: '/api/instances/' + jobKey + "/update-retries",
	             headers: csrfHeaderObject,
	             data:  document.getElementById("remaining-retries-" + jobKey).value,
	             contentType: 'application/json; charset=utf-8',
	             success: function (result) {
	             	showSuccess("Retries updated.");
	             },
	             error: function (xhr, ajaxOptions, thrownError) {
	            	 showErrorResponse(xhr, ajaxOptions, thrownError);
	             },
            	 timeout: 5000,
	             crossDomain: true,
	    });
}

// --------------------------------------------------------------------

function resolveJobIncident(incidentKey, jobKey) {

		var remainingRetries = document.getElementById("remaining-retries-" + incidentKey).value;

		resolveIncident(incidentKey, jobKey, remainingRetries);
}

function resolveWorkflowInstanceIncident(incidentKey) {
		resolveIncident(incidentKey, null, null);
}

function resolveIncident(incidentKey, jobKey, remainingRetries) {

		var data = {
			jobKey: jobKey,
			remainingRetries: remainingRetries
		};

		$.ajax({
	             type : 'PUT',
	             url: '/api/instances/' + incidentKey + "/resolve-incident",
	             headers: csrfHeaderObject,
	             data:  JSON.stringify(data),
	             contentType: 'application/json; charset=utf-8',
	             success: function (result) {
	             	showSuccess("Incident resolved.");
	             },
	             error: function (xhr, ajaxOptions, thrownError) {
	            	 showErrorResponse(xhr, ajaxOptions, thrownError);
	             },
            	 timeout: 5000,
	             crossDomain: true,
	    });
}

// --------------------------------------------------------------------

function cancelInstance(key) {
		$.ajax({
	             type : 'DELETE',
	             url: '/api/instances/' + key,
	             headers: csrfHeaderObject,
	             contentType: 'application/json; charset=utf-8',
	             success: function (result) {
	             	showSuccess("Instance canceled.");
	             },
	             error: function (xhr, ajaxOptions, thrownError) {
	            	 showErrorResponse(xhr, ajaxOptions, thrownError);
	             },
            	 timeout: 5000,
	             crossDomain: true,
	    });
}

// --------------------------------------------------------------------

function completeJob(jobKey) {

		$.ajax({
	             type : 'PUT',
	             url: '/api/jobs/' + jobKey + '/complete',
	             headers: csrfHeaderObject,
	             data:  getVariablesDocumentFrom(jobKey),
	             contentType: 'application/json; charset=utf-8',
	             success: function (result) {
	             	showSuccess("Job completed.");
	             },
	             error: function (xhr, ajaxOptions, thrownError) {
	            	 showErrorResponse(xhr, ajaxOptions, thrownError);
	             },
            	 timeout: 5000,
	             crossDomain: true,
	    });
}

// --------------------------------------------------------------------

function failJob(jobKey) {

		$.ajax({
	             type : 'PUT',
	             url: '/api/jobs/' + jobKey + '/fail',
	             headers: csrfHeaderObject,
	             contentType: 'application/json; charset=utf-8',
	             success: function (result) {
	             	showSuccess("Job failed.");
	             },
	             error: function (xhr, ajaxOptions, thrownError) {
	            	 showErrorResponse(xhr, ajaxOptions, thrownError);
	             },
            	 timeout: 5000,
	             crossDomain: true,
	    });
}

// --------------------------------------------------------------------

function throwError(jobKey) {

	var data = {
		errorCode: document.getElementById("error-code-" + jobKey).value
	};

	$.ajax({
		type : 'PUT',
		url: '/api/jobs/' + jobKey + '/throw-error',
		headers: csrfHeaderObject,
		data:  JSON.stringify(data),
		contentType: 'application/json; charset=utf-8',
		success: function (result) {
			showSuccess("Error thrown.");
		},
		error: function (xhr, ajaxOptions, thrownError) {
			showErrorResponse(xhr, ajaxOptions, thrownError);
		},
		timeout: 5000,
		crossDomain: true,
	});
}

// --------------------------------------------------------------------

function publishMessage() {

	var data = {
		name: document.getElementById("message-name").value,
		correlationKey: document.getElementById("message-correlation-key").value,
		payload: getVariablesDocument(),
		timeToLive: document.getElementById("message-ttl").value
	};

	publishMessageWithPayload(data);
}

function publishMessageSubscription(key) {

	var data = {
		name: document.getElementById("message-name-" + key).value,
		correlationKey: document.getElementById("message-correlation-key-" + key).value,
		payload: getVariablesDocumentFrom(key),
		timeToLive: document.getElementById("message-ttl-" + key).value
	};

	publishMessageWithPayload(data);
}

function publishMessageWithPayload(data) {

		$.ajax({
	             type : 'POST',
	             url: '/api/messages/',
	             headers: csrfHeaderObject,
	             data:  JSON.stringify(data),
	             contentType: 'application/json; charset=utf-8',
	             success: function (result) {
	             	showSuccess("Message published.");
	             },
	             error: function (xhr, ajaxOptions, thrownError) {
	            	 showErrorResponse(xhr, ajaxOptions, thrownError);
	             },
            	 timeout: 5000,
	             crossDomain: true,
	    });
}

// --------------------------------------------------------------------

function getVariablesDocumentFrom(key) {

	var formCount = 10;
	var variableCount = 0;
	var variableDocument = '{';

	var i;
	for (i = 1; i <= formCount; i++) {
		var varName = document.getElementById('variable-form-' + i + '-name_' + key).value;
		var varValue = document.getElementById('variable-form-' + i + '-value_' + key).value;

		if (varValue.length == 0) {
			varValue = null;
		}

		if (varName.length > 0) {
			if (variableCount > 0) {
				variableDocument += ',';
			}
			variableDocument += '"' + varName + '":' + varValue;
			variableCount += 1;
		}
	}

	variableDocument += '}';

	return variableDocument;
}

function getVariablesDocument() {

	var formCount = 10;
	var variableCount = 0;
	var variableDocument = '{';

	var i;
	for (i = 1; i <= formCount; i++) {
		var varName = document.getElementById('variable-form-' + i + '-name').value;
		var varValue = document.getElementById('variable-form-' + i + '-value').value;

		if (varValue.length == 0) {
			varValue = null;
		}

		if (varName.length > 0) {
			if (variableCount > 0) {
				variableDocument += ',';
			}
			variableDocument += '"' + varName + '":' + varValue;
			variableCount += 1;
		}
	}

	variableDocument += '}';

	return variableDocument;
}

// --------------------------------------------------------------------

function loadDiagram(resource) {
	viewer.importXML(resource, function(err) {
							if (err) {
								console.log('error rendering', err);
				             	showError(err);
							} else {
								var canvas = viewer.get('canvas');

								container.removeClass('with-error')
										 .addClass('with-diagram');

								// zoom to fit full viewport
								canvas.zoom('fit-viewport');
							}
						});
}

function addElementInstanceActiveMarker(canvas, elementId) {
	canvas.addMarker(elementId, 'bpmn-element-active');
}

function addElementInstanceIncidentMarker(canvas, elementId) {
	canvas.addMarker(elementId, 'bpmn-element-incident');
}

function addElementSelectedMarker(elementId) {
	canvas.addMarker(elementId, 'bpmn-element-selected');
}

function removeElementSelectedMarker(elementId) {
	canvas.removeMarker(elementId, 'bpmn-element-selected');
}

function addElementInstanceCounter(overlays, elemenId, active, ended) {

		var style = ((active > 0) ? "bpmn-badge-active" : "bpmn-badge-inactive");

		overlays.add(elemenId, {
		  position: {
		    top: -25,
  			left: 0
		  },
		  html: '<span class="' + style + '" data-toggle="tooltip" data-placement="bottom" title="active | ended">'
		  				+ active + ' | ' + ended
		  				+ '</span>'
		});
}

function addIncidentMarker(overlays, elemenId) {
		overlays.add(elemenId, {
		  position: {
		    top: -25,
  			right: 10
		  },
		  html: '<span class="bpmn-badge-incident" data-toggle="tooltip" data-placement="bottom" title="incident">'
		  				+ "⚡"
		  				+ '</span>'
		});
}

function markSequenceFlow(elementRegistry, graphicsFactory, flow) {
	var element = elementRegistry.get(flow);
	var gfx = elementRegistry.getGraphics(element);

	colorSequenceFlow(graphicsFactory, element, gfx, '#52b415');
}

function colorSequenceFlow(graphicsFactory, sequenceFlow, gfx, color) {
	var businessObject = sequenceFlow.businessObject,
		di = businessObject.di;

	di.set('stroke', color);
	di.set('fill', color);

	graphicsFactory.update('connection', sequenceFlow, gfx);
}

// --------------------------------------------------------------------

function initFilter(){
    let filterInput = document.getElementById('filter-input');

    if (filterInput){
        autocomplete({
            input: filterInput,
            showOnFocus: true,
            onSelect: function (item, inputfield) {
                inputfield.value = item;
                validateFilterInput();
            },
            fetch: function (text, callback) {
                var match = text.toLowerCase();
                callback(filterInputValues.filter(function(n) {
                    return n.toLowerCase().indexOf(match) !== -1;
                }));
            },
            render: function(item, value) {
                var itemElement = document.createElement("div");
                var regex = new RegExp(value, 'gi');
                var inner = item.replace(regex, function(match) {
                    return "<strong>" + match + "</strong>"
                });
                itemElement.innerHTML = inner;
                return itemElement;
            },
            emptyMsg: "No matches"
        });

        $('#filter-btn').click(function(){
            location.href = `${location.pathname}?filter=${$(filterInput).val()}`;
        });

        $('#clear-btn').click(function(){
            location.href = location.pathname;
        });

        $('#filter-input')
            .blur(validateFilterInput)
            .keyup(function(e){
                if (e.which === 9) {
                    this.value = $('.autocomplete > .selected').text();
                } else if (e.which === 13 && validateFilterInput() && $('.autocomplete').length === 0){
                    $('#filter-btn').click();
                }
            });

        validateFilterInput();
    }

}

function validateFilterInput(){
    var valid = filterInputValues.indexOf($('#filter-input').val()) > -1;
    $('#filter-btn').prop(
        'disabled',
        !valid
    );
    return valid;
}

function gatherAdditionalDataForEvent(event, registry){
	if (event.elementType == 'BOUNDARY_EVENT' || event.elementType == 'INTERMEDIATE_CATCH_EVENT'){
		// what type of boundary / catch event?
		let element = registry.get(event.elementId);
		element.businessObject.eventDefinitions.forEach(function(eventDef){
			if (eventDef.$type === 'bpmn:TimerEventDefinition'){
				event.icon = 'bpmn-icon-intermediate-event-catch-timer';
				return;
			} else if (eventDef.$type === 'bpmn:ErrorEventDefinition'){
				event.icon = 'bpmn-icon-intermediate-event-catch-error';
				return;
			} else if (eventDef.$type === 'bpmn:MessageEventDefinition'){
				event.icon = 'bpmn-icon-intermediate-event-catch-message';
				return;
	        }
		});
	} else if (event.elementType == 'MULTI_INSTANCE_BODY'){
		// multi instance loop: sequential or parallel?
		let element = registry.get(event.elementId);
		if (element.businessObject.loopCharacteristics.isSequential){
			event.icon = 'bpmn-icon-sequential-mi-marker';
		}
	}

	event.events.forEach(function(childEvent){
		gatherAdditionalDataForEvent(childEvent, registry);
	});
}

$(initFilter);
$(function(){
    $('#nav-tab')
        .find('#nav-item-minimize')
        .click(function(){
            $('body').toggleClass('bottom-pane-minimized');
        })
        .end()
        .find('.nav-item:not(#nav-item-minimize)')
        .click(function(){
            $('body').removeClass('bottom-pane-minimized');
        })
        .find('.nav-item.nav-link')
        .click(
            function(){
                let timelineViewActive = this.id == 'nav-timeline-tab';
                $('body').toggleClass('timeline-view', timelineViewActive);
                if (!timelineViewActive){
                    $('[data-element-id].timeline-highlight').removeClass('timeline-highlight');
                }
            }
        );
});

function downloadBpmn(filename, data){
    var blob = new Blob([data], {type: 'text/plain'});
    if (window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveBlob(blob, filename);
    } else {
        var elem = window.document.createElement('a');
        elem.href = window.URL.createObjectURL(blob);
        elem.download = filename;
        document.body.appendChild(elem);
        elem.click();
        document.body.removeChild(elem);
    }
}

function copyToClipboard(value){
    let elem = document.createElement("textarea");
    elem.style.position = "absolute";
    elem.style.left = "-9999px";
    elem.style.top = "0";
    document.body.appendChild(elem);
    if (typeof value == "string" && value.match('^".*"$')){
        // string values come with quotation marks
        value = value.substr(1, value.length - 2);
    }
    elem.textContent = value.toString();
    elem.select();
    document.execCommand("copy");
    document.body.removeChild(elem);
}

function getPrettyValueAndType(value){
    let prettyValue = value;
    let type = typeof value;
    try {
      let jsonVal = JSON.parse(value);
      type = typeof jsonVal;
      if (type === 'object'){
          prettyValue = JSON.stringify(jsonVal, null, 2);
      }
    } catch(e){ /* not valid json, return String value */ }

    return {"rawValue" : value, "prettyValue" : prettyValue, "type" : type};
}

function shortenedJson(value){
    return `${value.substring(0, 1)} ... ${value.substring(value.length - 1)}`;
}

function canToggleJsonShortener(variable){
    return variable.type === 'object'
        && variable.rawValue !== null
        && variable.rawValue !== 'null';
}

function toggleShortenedJson(event){
    $(event.target).closest('td').toggleClass('shortened-json-visible');
}

const csrfHeaderObject = {};
csrfHeaderObject[$("#csrfHeader").attr("content")] = $("#csrfToken").attr("content");
