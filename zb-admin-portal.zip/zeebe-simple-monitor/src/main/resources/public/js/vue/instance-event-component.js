const InstanceEventComponent = Vue.component('instance-event', {
    props: [ 'event', 'depth', 'icon' ],
    delimiters: ['[{', '}]'],
    data: function() {
        return {
            showChildren: this.depth < 2
        }
    },
    methods: {
        highlightElement: function(key, id){
            if (this.$root.$data.visibleVariables == key){
                this.$root.$data.visibleVariables = this.$root.$data.processEvent.key;
                id = this.$root.$data.processEvent.elementId;
            } else {
                this.$root.$data.visibleVariables = key;
            }

            let timelineCont = $('.timeline-container');
            let elements = $(`[data-element-id=${id}]`);
            let elementCont = $(`[data-key=${key}]`).parent();

            $('.timeline-highlight').removeClass('timeline-highlight');
            elements.filter('.djs-element.djs-shape').addClass('timeline-highlight');

            let elementPos = elementCont.position().top;
            elementCont.parents('.instance-event > .instance-event').toArray().forEach(
                     function(p){
                         elementPos += Math.abs($(p).position().top);
                     }
                 );

            let timelineScrollPos = timelineCont.scrollTop();
            if (timelineScrollPos > elementPos ||
                elementPos > (timelineScrollPos + timelineCont.height())){
                timelineCont.scrollTop(elementPos);
            }
        },
        toggleChildren : function(){
            this.showChildren = !this.showChildren;
        }
    },
    computed: {
        labelClassObject: function () {
            return {
                active: this.event.key == this.$root.$data.visibleVariables,
                toggleable: this.event.events.length > 0
            }
        }
    },
    template:
`<div class="instance-event">
    <i class="m-icon event-children-toggle text-secondary"
            v-if="event.events.length > 0 && depth > 0"
            @click="toggleChildren"
            :class="{ 'expanded' : showChildren }"
    >expand_more</i>
    <div class="label-container d-flex"
         :class="labelClassObject"
         @click="highlightElement(event.key, event.elementId)"
         :data-element-id="event.elementId"
         :data-key="event.key">
        <div class="event-icon-container text-secondary">
            <span :class="icon"></span>
        </div>
        <div class="label-wrapper">
            <span class="label-text">
                <span v-if="event.name.length == 0" class="badge">id:</span>
                <template v-if="event.name.length == 0">
                    [{ this.event.elementId }]
                </template>
                <template v-else>
                    [{ this.event.name }]
                </template>
                [{ event.elementType === 'MULTI_INSTANCE_BODY' ? '(Multi Instance)' : '' }]
            </span>
            <span class="badge">[{ new Date(event.timestamp).toLocaleString() }]</span>
        </div>
    </div>
    <instance-event
            v-for="event in event.events"
            :style="{'display' : (showChildren ? 'block' : 'none')}"
            :key="event.key"
            :event="event"
            :depth="depth + 1"
            :icon="event.icon">
    </instance-event>
</div>`
    }
);
