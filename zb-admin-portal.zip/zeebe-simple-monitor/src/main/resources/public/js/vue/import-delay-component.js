const ImportDelayComponent = Vue.component('import-delay', {
    delimiters: ['[{', '}]'],
    data() {
        return {
            delay : -1,
            timer : ''
        }
    },
    computed: {
        delayStatusObject: function(){
            let supplementaryIcon = "check_circle";
            let textColorClass = "text-success";
            let delayTooltip = `Import delay is healthy (~${this.delay} ms).`;

            if (this.delay < 0 || typeof this.delay === 'undefined'){
                supplementaryIcon = "help";
                textColorClass = "text-info";
                delayTooltip = "Import delay is unknown. Try reloading the page.";
            } else if (this.delay > 5 * 60 * 1000){
                supplementaryIcon = "error";
                textColorClass = "text-danger";
                delayTooltip = `Import delay is significant. (~${Math.round(this.delay / 1000)} s).`;
            } else if (this.delay > 2 * 60 * 1000){
                supplementaryIcon = "warning";
                textColorClass = "text-warning"
                delayTooltip = `Import delay is noticeable. (~${Math.round(this.delay / 1000)} s).`;
            }

            return { supplementaryIcon, textColorClass, delayTooltip }
        },
    },
    created() {
        this.fetchDelay();
        this.timer = setInterval(this.fetchDelay, 3 * 60 * 1000);
    },
    mounted() {
        $('.import-delay-bar').tooltip();
    },
    methods: {
        fetchDelay: function(){
            fetch('/import-delay')
                .then(response => response.status == 200 ? response.json() : -1)
                .then(delay => this.delay = delay)
                .catch(error => this.delay = -1);
        }
    },
    beforeDestroy() {
        clearInterval(this.timer);
    },
    template:
`<div class="import-delay-bar unselectable"
        data-toggle="tooltip"
        data-placement="left"
        title="Loading..."
        :data-original-title="delayStatusObject.delayTooltip"
        >
    <i class="m-icon supplementary-icon" :class="delayStatusObject.textColorClass">
        [{ delayStatusObject.supplementaryIcon }]
    </i><i class="m-icon">
        signal_cellular_alt
    </i>
</div>`
    }
);

$(function(){
    if (document.getElementById('import-delay-container')){
        importDelayVueApp = new Vue({ el: '#import-delay-container'});
    }
});
