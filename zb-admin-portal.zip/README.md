Zeebe Admin Portal
=========================

A monitoring application for [Zeebe](https://zeebe.io) based on the [Zeebe Simple Monitor](https://github.com/zeebe-io/zeebe-simple-monitor). It is designed to

* get in touch with Zeebe and workflow execution (BPMN)
* test workflows manually
* provide insides how workflows are executed 

The application imports the data from Zeebe using the [Hazelcast exporter](https://github.com/zeebe-io/zeebe-hazelcast-exporter). The data is then aggregated and stored into a MySQL database. The data is displayed on server-side rendered HTML pages.

![how-it-works](zeebe-simple-monitor/docs/how-it-works.png)

Custom Functionality
=========================

Show Workflow view
-------------------------
Similar to its BPM counterpart, a Show Workflow view is available when trying to gain information at a glance in SNOW. The endpoint is available similarly to the instance view at `/views/show-workflow/{key}` (instead of `/views/instances/{key}`). The difference between the two endpoints is on the front-end: the Show Workflow view has all navigation elements removed, and it does not have any sort of administratory functionality.

Health Check
-------------------------
There are 2 health check related endpoints implemented currently:

* `/actuator/health`: Spring Boot's own Actuator endpoint is specifically configured to be accessible with no authorization whatsoever.
```bash
$ curl -ks https://admin.sco-dev.swissre.com/actuator/health
> {"status":"UP","groups":["liveness","readiness"]}
```

* `/instances/health/{key}`: an instance health check endpoint set up to be used mainly during smoke tests. Only users with `TECH_USER` roles are allowed to access this endpoint (using Basic Authorization). Adding users is possible in `BasicAuthSecurityConfig`'s `UserDetailsService`.

```bash
$ curl -sk -w "%{response_code}" -u tecscoci:xyz https://admin.sco-dev.swissre.com/health/instances/2251799848908284
> 200
```

Authorization
-------------------------
The Admin Portal uses Azure AD SSO to identify the user, and a simple workflow APM -> SNOW Group name mapping configuration to determine whether the logged in user is allowed to open resources (workflows, instances) of the given APM.

This mapping is found in `AdminPortal.properties`, and it is structured in the following format:
`mapping:workflowAPM=groupName1,groupName2`
...where:
* `mapping` is a static prefix identifying this property as a mapping configuration
* `workflowAPM` specifies the APM found in the workflow's name: for example `sco.test`'s APM is `sco`
* `groupName1` (`,groupName2, etc.`) specifies one or more group names in SNOW - if the logged in user is a member of one of these groups, they will have access to the resource.

The list of users who can access any given APM is cached internally for 4 hours.

On the code side this is achieved using a custom implemented Permission Evaluator, and multiple (ordered) Spring Security configurations.


MySQL
-------------------------
All the workflow informations are stored in MySQL database. By default, the access to this database is restricted within kubernetes cluster. Its connection details can be obtained from pod using this command:

`kubectl -n zb describe pod/mysql-0`

Note down, `MYSQL_DATABASE, MYSQL_USER and MYSQL_PASSWORD`

To connect to this from database outside can be achieved by port forwarding

### Port forwarding
Get the pod name of MySQL instance for the environment which you like to access and execute the below command:

`kubectl port-forward -n zb pods/mysql-0 3306:3306`

Keep this command running while you wish to access the database.

In your MySQL client use this details to access the database:

```
Server Host: localhost
Port: 3306
```

In the case of an application.yaml file, your spring.data.url property would have the following value:
```
jdbc:mysql://localhost:3306/zbdb
```