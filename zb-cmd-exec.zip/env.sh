export TASK_TYPE=sco.cmd-exec
export ZEEBE_ADDRESS=zeebe.sco-dev.swissre.com:8090
export BROKER_ADDRESS=$ZEEBE_ADDRESS

