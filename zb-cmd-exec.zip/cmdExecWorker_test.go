package main

import (
	"testing"
)

type isValidCmdTestCase struct {
	Cmd            string
	ExpectedResult bool
}

func TestCommandValidation(t *testing.T) {
	testCases := []isValidCmdTestCase{
		{"C:/Users/MyUser/wd/test2.ps1", true},
		{"C:/Users/MyUser/test.ps1", true},
		{"C:/Users/test2.ps1", false},
		{"/usr/local/myproject/bin/exec", true},
		{"/usr/local/otherproject/bin/getstatus", true},
		{"invalidCmd", false},
	}

	whitelist := []string{
		"C:\\Users\\MyUser\\wd\\.*",
		"C:\\Users\\MyUser\\test.ps1",
		"/usr/local/myproject/bin/.*",
		"/usr/local/otherproject/bin/getstatus",
	}

	cmdExec, err := NewCmdExecWorker(whitelist, 0, make(map[string]string), 15)
	if err != nil {
		t.Fatal(err)
	}

	for _, testCase := range testCases {
		result := cmdExec.isValidCommand(testCase.Cmd)
		if result != testCase.ExpectedResult {
			t.Fatalf("the validity (%v) of a command (%s) does not match with the expected result (%v)", result, testCase.Cmd, testCase.ExpectedResult)
		}
	}
}
