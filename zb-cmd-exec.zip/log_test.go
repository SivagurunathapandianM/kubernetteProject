package main

import (
	"bytes"
	"log"
	"strings"
	"testing"
)

type TestData struct {
	Message            string
	ExpectedLogMessage string
}

type TestCase struct {
	Name         string
	FilterConfig FilterConfig
	Data         []TestData
}

func TestFilteredLog(t *testing.T) {
	testCases := []TestCase{
		{
			Name:         "NoFilter",
			FilterConfig: FilterConfig{},
			Data: []TestData{
				{
					Message:            "PASSWORD = pw123",
					ExpectedLogMessage: "PASSWORD = pw123",
				},
				{
					Message:            "Other log entry",
					ExpectedLogMessage: "Other log entry",
				},
			},
		},
		{
			Name: "FilterPassword",
			FilterConfig: FilterConfig{
				Pattern: map[string]string{
					"1": `(PASSWORD\s*=\s*)([[:alnum:]]*)`,
				},
				Replace: map[string]string{
					"1": `$1***`,
				},
			},
			Data: []TestData{
				{
					Message:            "PASSWORD = pw123",
					ExpectedLogMessage: "PASSWORD = ***",
				},
				{
					Message:            "Other log entry",
					ExpectedLogMessage: "Other log entry",
				},
			},
		},
	}

	log.SetFlags(0) // turn off timestamps
	for _, testCase := range testCases {
		buf := bytes.NewBufferString("")
		log.SetOutput(buf)
		setLogFilters(testCase.FilterConfig)
		for _, data := range testCase.Data {
			log.Printf(data.Message)
			msg := buf.String()
			if removeWhitespaces(msg) != removeWhitespaces(data.ExpectedLogMessage) {
				t.Fatalf("Test case '%s' falied. Exptected '%s', got '%s'", testCase.Name, data.ExpectedLogMessage, msg)
			}
			buf.Reset()
		}
	}
}

func removeWhitespaces(s string) string {
	return strings.Join(strings.Fields(s), "")
}
