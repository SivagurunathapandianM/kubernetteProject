export GO111MODULE=on
export GOPROXY=https://artifact.swissre.com/api/go/go-registry
export GONOPROXY=none
export GOPRIVATE=swissre.com/sco
export CGO_ENABLED=0
