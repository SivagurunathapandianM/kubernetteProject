package main

import (
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/magiconair/properties"

	"swissre.com/sco/go-utils/service"
	"swissre.com/sco/go-utils/zbworker"
)

var (
	flags      *flag.FlagSet
	cmd        string
	svcName    string
	userName   string
	workingDir string
	configPath string
	autoStart  bool
	version    string
)

type FilterConfig struct {
	Pattern map[string]string
	Replace map[string]string
}

type AppConfig struct {
	BrokerAddr        string
	TaskType          string
	ZeebeCredentials  string `properties:"ZeebeCredentials,default="`
	WhiteList         []string
	Timeout           int               `properties:"Timeout,default=0"`
	ZeebeJobTimeout   int               `properties:"ZeebeJobTimeout,default=300"`
	ZeebeConcurrency  int               `properties:"ZeebeConcurrency,default=1"`
	ZeebeRPCTimeout   int               `properties:"ZeebeRPCTimeout,default=15"`
	LogFilter         FilterConfig      `properties:"LogFilter,default=LogFilter{}"`
	HeartbeatInterval int               `properties:"HeartbeatInterval,default=5"`
	Environment       map[string]string `properties:"Environment,default="`
}

func main() {
	var err error
	defer logStacktraceOnPanic()

	initFlags()
	svcConfig := &service.Config{
		Name:             svcName,
		Username:         userName,
		WorkingDirectory: workingDir,
		ConfigFilePath:   configPath,
		Description:      "Zeebe command execution worker",
		Dependencies:     []string{},
	}
	zbWorker, err := createZeebeWorker(workingDir, configPath, cmd)
	if err != nil {
		log.Fatalf("falied to create Zeebe worker client: %s", err)
	}
	sysService := service.NewService(zbWorker, svcConfig)

	switch cmd {
	case "install":
		err = sysService.Install()
		if err != nil {
			break
		}
		if autoStart {
			err = sysService.Start()
		}
	case "remove":
		err = sysService.Remove()
	case "start":
		err = sysService.Start()
	case "stop":
		err = sysService.Stop()
	case "restart":
		err = sysService.Restart()
	case "run":
		err = sysService.Run()
	case "version":
		fmt.Println(version)
	default:
		usage(fmt.Sprintf("invalid command %s", cmd))
	}
	if err != nil {
		log.Fatalf("failed to %s %s: %s", cmd, svcName, err)
	}
	return
}

func initFlags() {
	flags = flag.NewFlagSet("zb-cmd-exec-svc-flagset", 0)
	flags.StringVar(&userName, "u", "", "Username, which the service will be run under. On Windows, it\n"+
		"is expected in the form UserDomain\\UserName and by default,\n"+
		"it is empty and the service uses the LocalSystem account. On\n"+
		"Linux systems, it is a mandatory attribute.")
	flags.StringVar(&workingDir, "d", ".", "Working directory of the service")
	flags.StringVar(&configPath, "c", "app.properties", "Configuration file path.")
	flags.BoolVar(&autoStart, "auto", true, "Start service after installation immediately.")

	if len(os.Args) < 2 {
		usage("not enough arguments found. Missing command.")
	}
	cmd = os.Args[1]
	if cmd == "version" {
		return
	}

	// run <config_path> [<working_dir> [<service_name>]]
	if cmd == "run" {
		configPath = os.Args[2]

		// optional positional arguments
		if len(os.Args) > 3 {
			workingDir = os.Args[3]
		}
		if len(os.Args) > 4 {
			svcName = os.Args[4]
		}

		return
	}

	if len(os.Args) < 3 {
		usage("not enough arguments found. Missing service name.")
	}
	svcName = os.Args[2]

	if len(os.Args) > 3 {
		if err := flags.Parse(os.Args[3:]); err != nil {
			log.Fatalf("failed to parse command line arguments: %s\n", err)
		}
	}

	var err error
	workingDir, err = filepath.Abs(workingDir)
	if err != nil {
		log.Fatalf("failed to get the absolute path of the provided working directory: %s", err)
	}

	configPath, err = filepath.Abs(configPath)
	if err != nil {
		log.Fatalf("failed to get the absolute path of the provided configuration file: %s", err)
	}
}

func createZeebeWorker(workingDir, configPath, cmd string) (zbworker.ZeebeWorker, error) {
	if cmd != "run" {
		// We need a proper ZeebeWorker instance only in case of 'run' command.
		// In other cases, it will not be used by the OS service object at all.
		return nil, nil
	}

	var appConfig *AppConfig
	var handler zbworker.JobHandler
	configPath, err := filepath.Abs(configPath)
	if err != nil {
		panic(fmt.Sprintf("failed to determine absolute path for config path '%s': %s", configPath, err))
	}

	if workingDir != "" {
		err := os.Chdir(workingDir)
		if err != nil {
			panic(fmt.Sprintf("could not change current working directory: %s", err))
		}
		log.Printf("changed working dir: %s\n", workingDir)
	}

	initLogs()
	log.Println("Starting zb-cmd-exec v" + version)
	appConfig, err = loadProperties(configPath)
	if err != nil {
		return nil, fmt.Errorf("failed to load properties: %s", err)
	}

	setLogFilters(appConfig.LogFilter)

	go logVersion(version, appConfig.HeartbeatInterval)
	handler, err = NewCmdExecWorker(appConfig.WhiteList, appConfig.Timeout, appConfig.Environment, appConfig.ZeebeRPCTimeout)
	if err != nil {
		return nil, fmt.Errorf("failed to create new cmd exec worker: %s", err)
	}

	zbBuilder := zbworker.NewZeebeWorkerBuilder().
		BrokerAddress(appConfig.BrokerAddr).
		AttachWorker(appConfig.TaskType, handler).
		Concurrency(appConfig.ZeebeConcurrency).
		JobTimeout(time.Duration(appConfig.ZeebeJobTimeout) * time.Second).
		RpcTimeout(time.Duration(appConfig.ZeebeRPCTimeout) * time.Second)

	if appConfig.ZeebeCredentials != "" {
		credsBytes, err := ioutil.ReadFile(appConfig.ZeebeCredentials)
		if err != nil {
			return nil, fmt.Errorf("failed to read credentials file '%s': %s", appConfig.ZeebeCredentials, err)
		}
		credsStr := strings.TrimSpace(string(credsBytes))
		creds := strings.SplitN(credsStr, ":", 2)
		if len(creds) < 2 {
			return nil, fmt.Errorf("failed to get username and password from file '%s'", appConfig.ZeebeCredentials)
		}

		zbBuilder.Credentials(creds[0], creds[1])
	} else {
		zbBuilder.UsePlaintext(true)
		log.Println("No user info given, using plain text connection.")
	}

	return zbBuilder.Build(), nil
}

func loadProperties(configPath string) (*AppConfig, error) {
	log.Printf("opening config file: %s\n", configPath)
	propsBytes, err := ioutil.ReadFile(configPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read properties file: %s", err)
	}

	// replace CRLF sequences with single LF characters because at the time of writing,
	// github.com/magiconair/properties could not handle the escaping of CRLF newlines
	// (\\r\n was parsed as \n) thus multiline string properties only contained their
	// first lines.
	propsString := strings.ReplaceAll(string(propsBytes), "\r\n", "\n")
	p := properties.MustLoadString(propsString)

	var config AppConfig
	err = p.Decode(&config)
	if err != nil {
		return nil, fmt.Errorf("failed to read properties into AppConfig: %s", err)
	}

	return &config, nil
}

func usage(errMsg string) {
	fileName := filepath.Base(os.Args[0])
	fmt.Fprintf(os.Stderr,
		"%s\n\n"+
			"Usage:\n"+
			"  %[2]s <COMMAND> [OPTIONS...]\n\n"+
			"Commands:\n"+
			"  install <service_name> [-d <working_dir>] [-c <config_file>] [-u <username>] [-auto=false|true]\n"+
			"        Install cmd-exec worker as a new system service. By default, the service will be\n"+
			"        automatically started after installation.\n"+
			"  run <config_file> [<working_dir>]\n"+
			"        Run the cmd-exec worker without installing it as a service.\n"+
			"  remove <service_name>\n"+
			"        Remove the given system service.\n"+
			"  start <service_name>\n"+
			"        Start the given system service.\n"+
			"  stop <service_name>\n"+
			"        Stop the given system service.\n"+
			"  restart <service_name>\n"+
			"        Restart the given system service.\n"+
			"  version\n"+
			"        Print version.\n\n"+
			"Options:\n",
		errMsg, fileName)

	flags.PrintDefaults()
	os.Exit(2)
}

func logVersion(version string, interval int) {
	if interval == 0 {
		return
	}

	for {
		log.Println("Still alive, v" + version)

		time.Sleep(time.Second * time.Duration(interval))
	}
}
