package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"os"
	"regexp"
	"runtime"
	"runtime/debug"
	"time"
)

type Filter struct {
	Pattern *regexp.Regexp
	Replace string
}

type filteredLogWriter struct {
	filters []*Filter
	writer  io.Writer
}

func (w *filteredLogWriter) Write(p []byte) (int, error) {
	for _, filter := range w.filters {
		p = filter.Pattern.ReplaceAll(p, []byte(filter.Replace))
	}

	return w.writer.Write(p)
}

func setLogFilters(filterConfig FilterConfig) {
	filters, err := compileLogFilters(filterConfig)
	if err != nil {
		log.Fatalf("failed to compile log filters: %s", err)
	}

	writer := &filteredLogWriter{
		filters: filters,
		writer:  log.Writer(),
	}

	log.SetOutput(writer)
}

func compileLogFilters(filterConfig FilterConfig) ([]*Filter, error) {
	var filters []*Filter
	for k, _ := range filterConfig.Pattern {
		pattern := filterConfig.Pattern[k]
		replace, ok := filterConfig.Replace[k]
		if !ok {
			return nil, fmt.Errorf("no replace value found for pattern %s", k)
		}

		patternExp := regexp.MustCompile(pattern)

		filters = append(filters, &Filter{
			Pattern: patternExp,
			Replace: replace,
		})
	}

	return filters, nil
}

func initLogs() {
	log.SetFlags(0)
	f, err := os.OpenFile("log.txt", os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		log.Fatalf("failed to open log file: %s", err)
	}

	log.SetOutput(Writer{out: io.MultiWriter(f, os.Stdout)})
}

func logStacktraceOnPanic() {
	if r := recover(); r != nil {
		log.Println("stacktrace from panic: \n" + string(debug.Stack()))
	}
}

type Writer struct {
	out io.Writer
}

func (w Writer) Write(p []byte) (n int, err error) {
	temp := p

	if runtime.GOOS == "windows" {
		temp = bytes.ReplaceAll(p, []byte("\n"), []byte("\r\n"))
	}

	return w.out.Write([]byte(time.Now().UTC().Format(time.RFC3339) + " " + string(temp)))
}
