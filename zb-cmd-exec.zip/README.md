# Introduction 
The command executor is a ZB worker which (based on the input parameters) runs an OS (Linux and Windows) command.

## Quickstart

Get the compiled binaries either from
* the build artifacts (https://dev.azure.com/swissre/SCO-OrchestrationPlatform/_build?definitionId=7585)
* or from `\\scw000003499.corp.gwpnet.com\zeebe\SOFTWARE\zb-cmd-exec.zip`

### Configure
Edit `app.properties` configuration file to your needs. Note that if you define your value as `${MY_VAR}`, then the value
will be taken from the respective environment variable.

| Property  | Description |
|-----------|-------------|
| BrokerAddress    | Address of the zeebe broker in the form of `<host>:<port>`. E.g. `zeebe.sco-dev.swissre.com:8090`   |
| TaskType         | Type of the Zeebe task the service will be working on. E.g. `SCO.my-cmd-exec-task`  |
| Whitelist        | A series of regexps separated by semi-colons (`;`) that control the which scripts/binaries can be executed. Any path that does not match with any of the regexps will be rejected. E.g. `/scripts/.*`. Note that if you want to format your list into multiple lines, you have to escape the newline characters e.g. <br> `/foo/bar;\ `<br> `/foo/baz`  |
| Timeout (optional)         | Maximum duration an execution can take up. The default is `0` which means no timeout. If the time is up, the program will be suspended and the end result will be a failure |
| ZeebeCredentials (optional) | The path of the file that contains the credentials of the Zeebe client. The contents of the file are expected in the form of `<username>:<password>`. If not present, the worker will connect to the broker via plaintext.
| ZeebeConcurrency (optional) | Maximum number of concurrent goroutines to be spawned to complete jobs. (`default = 1`)
| ZeebeJobTimeout (optional) | The duration in seconds no other worker should work on job activated by this worker. (`default = 300`)
| LogFilter (optional) | Log filters can be used for masking sensitive data. A filter can be defined with the following properties:<br>```LogFilter.Pattern.<num>=<pattern>```<br>```LogFilter.Replace.<num>=<replace>```<br> `Pattern` is a regular expression against which the messages will be matched. Matched expressions will be replaced with the `Replace` property. In `Replace`, numbered submatches can be used via `$n` where `n` denotes the number of the submatch. (`default = no filter`)<br><br>Example properties:<br>```LogFilter.Pattern.1 = (Password\\s*=\\s*)([[:alnum:]]*)```<br>```LogFilter.Replace.1 = $1***```<br>```# The string pattern `“Password =”` is replaced with the string pattern `”Password = ***”` during logging```<br><br>```LogFilter.Pattern.2 = ([0-9]{4})([0-9]{8,15})```<br>```LogFilter.Replace.2 = $1********```<br>```# A dummy credit card filter that only shows the first four digits of credit cards.```
| Environment (optional) | Static environment variables can be set via `Environment` properties. These environment variables will be passed to all Zeebe jobs. If an environment variable is also defined by the Zeebe job than it will be overridden by the job's variable.<br><br>Example properties:<br>```Environment.MY_VAR = some_value```<br>```# set MY_VAR environment variable```

### Zeebe task

__Input parameters__

    command (string): The shell script/binary to be executed.
    args (array): Arguments to the executable.
    pwd (string): The working directory of the execution. If empty, it is inherited from the service.
    env (object): Additional environment variables for the execution.
    
__Output parameters__

    output (string): The combined output from stdout and stderr of the execution.
    result (string): The result of the execution. Can be  either "success" or "failure".
    exitCode (int): The exit code, that was returned by the process. -1 if the process failed to start.

### Run service
* Always try to run your worker with `zb-cmd-exec run app.properties` before installing the service to ensure the configuration is not faulty.
* Install the service with `zb-cmd-exec install MyZbCmdSvc`. By default, the service will start automatically after installation.
  Regardless of your host OS, you will need administrator rights to do so.
  * Linux: execute with `sudo`
  * Windows: right click on powershell/cmd -> `Run as administrator`
* Deploy the sample workflow by running `zbctl deploy cmd-exec.bpmn`
* Create an instance (in bash) such as 
  * `zbctl create instance cmd-exec --variables '{"command":"C:\\SRDEV\\PortableGit\\bin\\bash.exe","args":["c:\\SRDEV\\test.sh"],"pwd":"c:\\SRDEV\\","env":{"ENV_VAR":"v1","ENV_VAR2":"v2"}}'`
  * The variables are expected in the following json schema:
    ```
    {
      "command": "path/to/executable",
      "args": ["arg1", "arg2"],
      "pwd": "path/to/working/dir", // if empty, it will be PWD of the parent service
      "env": {"ENV_VAR": "value1", "ENV_VAR2":"value2"} // additional environment variables, can be empty object
    }
    ```
* Observe the result in the Camunda Operate Console: https://operator.sco-dev.swissre.com/#/ 

## Build
* Setup your Go environment by executing `go_env.sh`
* If you want to cross-compile, set your target platform by defining the `GOOS=(linux | windows)` environment variable.
* Compile with ```go build -ldflags "-X main.version=`date -u +.%Y%m%d.%H%M%S`" zb-cmd-exec```

## Usage
```
$ zb-cmd-exec
Usage:
  zb-cmd-exec <COMMAND> [OPTIONS...]

Commands:
  install <service_name> [-d <working_dir>] [-c <config_file>] [-u <username>] [-auto=false|true]
        Install cmd-exec worker as a new system service. By default, the service will be
        automatically started after installation.
  run <config_file> [<working_dir>]
        Run the cmd-exec worker without installing it as a service.
  remove <service_name>
        Remove the given system service.
  start <service_name>
        Start the given system service.
  stop <service_name>
        Stop the given system service.
  restart <service_name>
        Restart the given system service.
  version
        Print version.

Options:
  -auto
        Start service after installation immediately. (default true)
  -c string
        Configuration file path. (default "app.properties")
  -d string
        Working directory of the service (default ".")
  -u string
        Username, which the service will be run under. On Windows, it
        is expected in the form UserDomain\UserName and by default,
        it is empty and the service uses the LocalSystem account. On
        Linux systems, it is a mandatory attribute.

```

## Frequently Asked Questions

#### Can I execute `.sh` scripts on a Windows machine?

The direct execution of `.sh` scripts on Windows is not supported.
The recommended way of running them is to port them to powershell
or wrap them in a `ps1` script in which you call your `.sh` script
with your favourite Linux shell emulator.