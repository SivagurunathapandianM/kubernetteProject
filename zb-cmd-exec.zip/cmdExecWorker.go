package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os/exec"
	"regexp"
	"runtime"
	"strings"
	"swissre.com/sco/go-utils/zbworker/utils"
	"sync"
	"time"

	"github.com/zeebe-io/zeebe/clients/go/pkg/entities"
	"github.com/zeebe-io/zeebe/clients/go/pkg/worker"

	"swissre.com/sco/go-utils/zbworker"
)

type CmdExecWorker struct {
	handledJobs map[int64]bool
	whitelist   []*regexp.Regexp
	timeout     int
	env         map[string]string
	mutex       sync.Mutex
	rpcTimeout  int
}

func NewCmdExecWorker(whitelistExprs []string, timeout int, env map[string]string, rpcTimeout int) (*CmdExecWorker, error) {
	whitelist, err := compileWhitelist(whitelistExprs)
	if err != nil {
		return nil, fmt.Errorf("failed to compile whitelist rexeps: %s", err)
	}

	return &CmdExecWorker{
		whitelist:   whitelist,
		timeout:     timeout,
		env:         env,
		handledJobs: make(map[int64]bool),
		rpcTimeout:  rpcTimeout,
	}, nil
}

func (c *CmdExecWorker) Handle(client worker.JobClient, job entities.Job) error {
	var err error
	jobKey := job.GetKey()

	if c.isJobAlreadyHandled(jobKey) {
		return nil
	}
	c.lockJob(jobKey)
	defer c.unlockJob(jobKey)

	vars, err := job.GetVariablesAsMap()
	if err != nil {
		return fmt.Errorf("failed to get variables from job: %s", err)
	}

	cmd, err := extractCommandFromVariables(vars)
	if err != nil {
		return fmt.Errorf("failed to extract command from variables: %s", err)
	}
	pwd, err := extractPwdFromVariables(vars)
	if err != nil {
		return fmt.Errorf("failed to extract pwd from variables: %s", err)
	}
	env, err := extractEnvFromVariables(vars)
	if err != nil {
		return fmt.Errorf("failed to extract env from variables: %s", err)
	}
	args, err := extractArgsFromVariables(vars)
	if err != nil {
		return fmt.Errorf("failed to extract args from variables: %s", err)
	}

	env = mergeEnvMaps(c.env, env)

	if !c.isValidCommand(cmd) {
		return fmt.Errorf("Invalid command. Command '%s' is not part of whitelist\n", cmd)
	}

	printWithKey(jobKey, fmt.Sprintf("cmd:%s\n", cmd))
	printWithKey(jobKey, fmt.Sprintf("args:%s\n", args))
	printWithKey(jobKey, fmt.Sprintf("pwd:%s\n", pwd))
	printWithKey(jobKey, fmt.Sprintf("env:%s\n", env))

	out, exitCode := executeCommand(cmd, args, pwd, env, c.timeout)

	var outVars = make(map[string]interface{})
	outVars["output"] = out
	outVars["exitCode"] = exitCode
	if exitCode == 0 {
		outVars["result"] = "success"
	} else {
		outVars["result"] = "failure"
		printWithKey(jobKey, fmt.Sprintf("Error executing command (%d): %s\n", exitCode, out))
	}

	printWithKey(jobKey, fmt.Sprintf("Output: %s\n", out))

	// TODO: rewrite async + errors from this func to channel back to caller
	for retry := 100; retry > 0; retry-- {
		err = utils.CompleteJob(client, job, outVars, c.rpcTimeout)
		if err == nil {
			break
		}
		time.Sleep(15 * time.Second)
	}
	if err != nil {
		return fmt.Errorf("failed to complete job '%d': %s", jobKey, err)
	}

	// TODO:
	//go completeJob(client, job, outVars, c.rpcTimeout)

	return nil
}

/*
func completeJob(client worker.JobClient, job entities.Job, outVars map[string]interface{}, rpcTimeout int) {
	err := utils.CompleteJob(client, job, outVars, rpcTimeout)
	if err != nil {
		return fmt.Errorf("failed to complete job '%d': %s", jobKey, err)
	}
}*/

func (c *CmdExecWorker) isValidCommand(cmd string) bool {
	for _, regex := range c.whitelist {
		if regex.MatchString(cmd) {
			return true
		}
	}

	return false
}

func (c *CmdExecWorker) isJobAlreadyHandled(key int64) bool {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	return c.handledJobs[key]
}

func (c *CmdExecWorker) lockJob(key int64) {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	c.handledJobs[key] = true
}

func (c *CmdExecWorker) unlockJob(key int64) {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	c.handledJobs[key] = false
}

func executeCommand(cmd string, args []string, pwd string, envMap map[string]string, timeout int) (string, int) {
	cmdCtx := context.Background()
	if timeout > 0 {
		var cancel context.CancelFunc
		cmdCtx, cancel = context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
		defer cancel()
	}

	// .ps1 files cannot be executed directly (they result in error
	// 'fork/exec test.ps1: %1 is not a valid Win32 application.').
	// As a workaround, prepend 'powershell.exe -File' to the cmd
	// so that direct powershell script execution remains possible
	// and we do not compromise the service's security by forcing
	// our customers to whitelist 'powershell.exe'
	if runtime.GOOS == "windows" && strings.HasSuffix(cmd, ".ps1") {
		args = append([]string{"-File", cmd}, args...)
		cmd = "powershell.exe"
	}

	// required because cmd cannot use slash separated paths
	if runtime.GOOS == "windows" && strings.HasSuffix(cmd, ".bat") {
		cmd = strings.ReplaceAll(cmd, "/", "\\")
	}

	command := exec.CommandContext(cmdCtx, cmd, args...)
	if pwd != "" {
		command.Dir = pwd
	}
	var envs []string
	for k, v := range envMap {
		envs = append(envs, k+"="+v)
	}
	command.Env = envs

	var ret string
	out, err := command.CombinedOutput()
	exitCode := command.ProcessState.ExitCode()

	// return error if failed to execute process
	if exitCode == -1 && err != nil {
		ret = err.Error()
	} else {
		ret = string(out)
	}

	return ret, exitCode
}

func extractCommandFromVariables(vars zbworker.TaskVariableMap) (string, error) {
	if vars["command"] == nil {
		return "", fmt.Errorf("no command parameter found")
	}
	cmd, ok := vars["command"].(string)
	if !ok {
		return "", fmt.Errorf("command is not a string")
	}
	return pathToSlash(cmd), nil
}

func extractPwdFromVariables(vars zbworker.TaskVariableMap) (string, error) {
	if vars["pwd"] == nil {
		return "", nil
	}
	pwd, ok := vars["pwd"].(string)
	if !ok {
		return "", fmt.Errorf("pwd is not a string")
	}
	return pwd, nil
}

func extractEnvFromVariables(vars zbworker.TaskVariableMap) (map[string]string, error) {
	envs := make(map[string]string)
	if vars["env"] == nil {
		return envs, nil
	}

	var envMapInterface map[string]interface{}
	switch vars["env"].(type) {
	case string:
		err := json.Unmarshal([]byte(vars["env"].(string)), &envMapInterface)
		if err != nil {
			return nil, fmt.Errorf("failed to parse env: %s", err)
		}
	case map[string]interface{}:
		envMapInterface = vars["env"].(map[string]interface{})
	default:
		return nil, fmt.Errorf("env is not a JSON object")
	}

	for k, v := range envMapInterface {
		value, ok := v.(string)
		if !ok {
			return nil, fmt.Errorf("env '%s' value '%v' is not a string", k, v)
		}
		envs[k] = value
	}

	return envs, nil
}

func extractArgsFromVariables(vars zbworker.TaskVariableMap) ([]string, error) {
	var args []string

	if vars["args"] == nil {
		return args, nil
	}

	switch vars["args"].(type) {
	case string:
		err := json.Unmarshal([]byte(vars["args"].(string)), &args)
		if err != nil {
			return nil, fmt.Errorf("failed to parse command arguments: %s", err)
		}
	case []interface{}:
		for _, argInterface := range vars["args"].([]interface{}) {
			arg, ok := argInterface.(string)
			if !ok {
				return nil, fmt.Errorf("args is not in the proper format [\"arg1\", \"arg2\", ...]")
			}
			args = append(args, arg)
		}
	}

	return args, nil
}

func compileWhitelist(exprs []string) ([]*regexp.Regexp, error) {
	log.Println("compiling whitelist...")
	var whitelist []*regexp.Regexp

	for _, expr := range exprs {
		expr = pathToSlash(expr)
		log.Println(expr)
		regex, err := regexp.Compile(expr)
		if err != nil {
			return nil, fmt.Errorf("failed to compile regexp '%s': %s", expr, err)
		}
		whitelist = append(whitelist, regex)
	}

	return whitelist, nil
}

func mergeEnvMaps(a, b map[string]string) map[string]string {
	for k, v := range b {
		a[k] = v
	}
	return a
}

func pathToSlash(path string) string {
	return strings.ReplaceAll(path, "\\", "/")
}

func printWithKey(key int64, msg string) {
	log.Printf("#%d: %s", key, msg)
}
