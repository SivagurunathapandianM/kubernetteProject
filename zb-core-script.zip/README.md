# zeebe-script-worker

A Zeebe worker to evaluate scripts (i.e. script tasks). Scripts are useful for prototyping, to do (simple) calculations, or creating/modifying variables.

## Deploying service

Azure CD pipeline works now for DEV deployment. For deploying it to NONPROD and PROD you need manually execution now. 
Those deployment uses the Default-Linux agent pool, which does not have the envstub library. 

####Manual deployment

* ssh to jumphost vm which has access to **NONPROD** and **PROD** clusters. (`scl000103350.sccloud.swissre.com`)
* replace `@docker.repository@:@project.version@` placeholder with latest docker image in the `/caas-config/zb-script-worker-deploy.yaml`
* use the `/caas-config/setup-caas.sh` script to deploy
  * First argument is the base64 encoded k8s config file with access to the specific cluser
  * Second is the environment which could be one of the following:  **`DEV | NONPROD | PROD`** 
  * Third is the client id for the SCO apm. (`sco.zeebe-script-runner`)
  * Fourth is the password for the client id. It is stored in keepass under `ZB/script-runner` folder





<br /><br /><br /><br /><br /><br /><br /><br /><br />

## Usage

Example BPMN with service task:

```xml
<bpmn:serviceTask id="scripting" name="Evaluate the Script">
  <bpmn:extensionElements>
    <zeebe:taskDefinition type="script" />
    <zeebe:taskHeaders>
      <zeebe:header key="language" value="javascript" />
      <zeebe:header key="script" value="a + b" />
    </zeebe:taskHeaders>
  </bpmn:extensionElements>
</bpmn:serviceTask>
```

* the worker is registered for the type `script`
* required custom headers:
  * `language` - the name of the script language
  * `script` - the script to evaluate
* available context/variables in script:
  * `job` (ActivatedJob) - the current job
  * `zeebeClient` (ZeebeClient) - the client of the worker
* the result of the evaluation is passed as `result` variable   

Available script languages:
* javascript (Oracle Nashorn)
* [groovy](http://groovy-lang.org/)
* [feel](https://github.com/camunda/feel-scala)

## Install

1) Download the [JAR file](https://github.com/zeebe-io/zeebe-script-worker/releases) 

2) Execute the JAR via

    `java -jar target/zeebe-script-worker-{VERSION}.jar`

### Configuration

The connection can be changed by setting the environment variables:
* `zeebe.client.broker.contactPoint` (default: `127.0.0.1:26500`).

## Build from Source

Build with Maven:
    
`mvn clean install`

## Custom Functions

For functionality better suited to Java than Javascript, custom functions can be created that are then called by the workflow.
Script header example:
```
var Utils = Java.type('com.swissre.bpm.zeebescriptrunner.scriptRunner.Utils'); 
var result = Utils.prettyPrintZeebeObject(sourceObject); 
result
```

## Code of Conduct

This project adheres to the Contributor Covenant [Code of
Conduct](/CODE_OF_CONDUCT.md). By participating, you are expected to uphold
this code. Please report unacceptable behavior to code-of-conduct@zeebe.io.
