package com.swissre.bpm.zeebescriptrunner;

import com.swissre.bpm.javautils.zeebeworkerbase.zeebe.ZeebeWorkerBase;
import com.swissre.bpm.zeebescriptrunner.zeebe.ZeebeScriptWorker;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLException;
import java.io.IOException;
import java.io.StringReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

public class ZeebeScriptRunnerService {
    private static Logger LOG = LoggerFactory.getLogger(ZeebeScriptRunnerService.class);
    public static final String ENVIRONMENT = Optional.ofNullable(System.getenv("ENVIRONMENT")).orElse("DEV");

    public static void main(String[] args) throws SSLException {
        LOG.info("ZeebeScriptRunnerService is starting up!");

        Properties properties;
        try {
            properties = loadProperties();
        } catch (IOException | InterruptedException e) {
            LOG.error("ZeebeScriptRunnerService can not load properties. Exiting. ", e);
            return;
        }
        LOG.info("ZeebeScriptRunnerService loaded the properties: {}", properties);

        ZeebeScriptWorker scriptWorker = new ZeebeScriptWorker();

        List<String> supportedAPMs = Arrays.asList(StringUtils.split(properties.getProperty("supportedAPMs"), ","));
        int healthCheckPort = Integer.parseInt(properties.getProperty("healthCheck.port"));

        for (String apm : supportedAPMs) {
            String jobType = String.join(".", apm, properties.getProperty("zeebeBroker.jobType.scriptRunner"));
            ZeebeWorkerBase.newBuilder(properties.getProperty("zeebeBroker.host") + ":" + properties.getProperty("zeebeBroker.port"))
                    .setAuthCredentials(jobType, System.getenv(properties.getProperty("env.auth.password")))
                    .setHealthCheckHostRoot(properties.getProperty("healthCheck.rootPath"))
                    .setHealthCheckPort(healthCheckPort)
                    .setVersion(properties.getProperty("healthCheck.version"))
                    .attachWorker(jobType, scriptWorker,
                            System.getenv("ZEEBE_MAX_JOB_ACTIVE") == null ? 1 : Integer.parseInt(System.getenv("ZEEBE_MAX_JOB_ACTIVE")))
                    .build();

            healthCheckPort += 1;
        }
    }

    private static Properties loadLocalProperties() throws IOException {
        Properties appProps = new Properties();
        appProps.load(ZeebeScriptRunnerService.class.getClassLoader().getResourceAsStream("ScriptRunner.properties"));
        return appProps;
    }

    private static Properties loadProperties() throws InterruptedException, IOException {
        Properties localProperties = loadLocalProperties();

        LOG.info("Environment: {}", ENVIRONMENT);
        LOG.info("Altering config file location to: {}", (localProperties.getProperty("configServer.configFileName")).replace("ENVIRONMENT", ENVIRONMENT));
        localProperties.put("configServer.configFileName", (localProperties.getProperty("configServer.configFileName")).replace("ENVIRONMENT", ENVIRONMENT));

        Properties appProps = new Properties();
        boolean isResponseFromConfigServerReceived = false;
        String propertiesAsString = null;
        LOG.info("Fetching environment specific properties from Config Server");
        while (!isResponseFromConfigServerReceived) {
            HttpClient httpClient = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .GET()
                    .uri(URI.create(localProperties.getProperty("configServer.hostRoot")
                            + localProperties.getProperty("configServer.filesLocation")
                            + localProperties.getProperty("configServer.configFileName")))
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            propertiesAsString = response.body();
            if (response.statusCode() == 200)
                isResponseFromConfigServerReceived = true;
            else {
                LOG.info("Properties fetching uri: \n{}", request.uri());
                LOG.info("Properties fetching got failed: \n{}", response.statusCode());
                LOG.info("response body: \n{}", response.body());
            }
        }
        LOG.info("Got properties from config server: \n{}", propertiesAsString);
        appProps.load(new StringReader(propertiesAsString));
        appProps.put("healthCheck.version", localProperties.get("healthCheck.version"));
        return appProps;
    }
}
