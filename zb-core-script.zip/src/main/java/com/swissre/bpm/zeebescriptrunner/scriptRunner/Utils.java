package com.swissre.bpm.zeebescriptrunner.scriptRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.swissre.bpm.zeebescriptrunner.ZeebeScriptRunnerService;

public class Utils {
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final ObjectWriter WRITER = MAPPER.writerWithDefaultPrettyPrinter();

    public static String getZeebeEnvironment() {
        return ZeebeScriptRunnerService.ENVIRONMENT;
    }

    public static String prettyPrintZeebeObject(Object object) throws JsonProcessingException {
        return WRITER.writeValueAsString(object);
    }

    public static String prettyPrintZeebeObjectToHtml(Object object) throws JsonProcessingException {
        // good idea to wrap this in <pre> tags when used in an email
        return prettyPrintZeebeObject(object)
                .replaceAll("\n", "<br>")
                .replaceAll(" {2}", "&nbsp;&nbsp;");
    }
}
