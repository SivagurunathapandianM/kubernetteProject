#!/bin/bash
#set -x

# Error mnemonic = (ErrorCode *F*ailure|*W*arning ErrorMessage)
ERR_SUBST_ENV=(1 F "Error substituting variables")
ERR_K8S_DEL=(2 W "Warning deleting deployment")
ERR_K8S_DEPLOY=(3 F "Error applying deployment")
ERR_K8S_SERVICE=(4 F "Error applying service")


function chkErr() {
    local ret=$1
    shift
    local err=("$@")
    if [ $ret -eq 0 ];then
        return
    else
        echo ${err[2]} 1>&2
        if [ ${err[1]} == "F" ];then
            exit ${err[0]}
        fi
    fi
}



# Check arg count
if [ $# -ne 4 ];then
		echo "Usage: setup-caas.sh K8SConfig(Base64) Environment(DEV|NONPROD|PROD) ZBClientSecret ZEEBE_MAX_JOB_ACTIVE"
		exit 1
fi

export K8SConfig=$1
export ENVIRONMENT=$2
export CLIENTSECRET=$3
export ZEEBE_MAX_JOB_ACTIVE=$4

echo -n $K8SConfig | base64 -d >kube.config
export KUBECONFIG=$PWD/kube.config

# Detect if running in an ADO release pipeline or not
if [[ ! -z $SYSTEM_ARTIFACTSDIRECTORY  ]];then cd $SYSTEM_ARTIFACTSDIRECTORY/caas-setup/caas-setup;fi

#sed -i "s/@clientsecret@/$1/g" zb-script-worker-secret.yaml
#sed -i "s/@clientsecret@/$1/g" zb-script-worker-deploy.yaml


#kubectl -n zb-core-services apply -f zb-script-worker-secret.yaml

kubectl -n zb-core-services delete  deployment.apps/zb-script-worker
chkErr $? "${ERR_K8S_DEL[@]}"

cat zb-script-worker-deploy.yaml | envsubst | kubectl -n zb-core-services apply -f -
chkErr $? "${ERR_K8S_DEPLOY[@]}"

#kubectl -n zb-core-services apply -f zb-script-worker-deploy.yaml
#chkErr $? "${ERR_K8S_DEPLOY[@]}"

#kubectl -n zb-core-services apply -f zb-script-worker-ingress.yaml
kubectl -n zb-core-services apply -f zb-script-worker-service.yaml
chkErr $? "${ERR_K8S_SERVICE[@]}"

rm -f kube.config
