package com.swissre.bpm.mstemplate.zeebe.util;

public class MicroserviceTemplateResponse {

    private String statusCode;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
}
