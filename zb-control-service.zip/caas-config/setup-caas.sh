#!/bin/bash
set -x

# Detect if running in an ADO release pipeline or not
if [[ ! -z $SYSTEM_ARTIFACTSDIRECTORY  ]];then cd $SYSTEM_ARTIFACTSDIRECTORY/caas-setup/caas-setup;fi

sed -i "s/@clientsecret@/$1/g" zb-control-03-secret.yaml
sed -i "s/@clientsecret@/$1/g" zb-control-04-deploy.yaml

#**********************************************************************************************#
# Only delete the namespace if it is really needed - it would need the DNS A records recreated #
#**********************************************************************************************#

#kubectl delete namespace zb-control
#kubectl apply -f zb-control-01-ns.yaml

kubectl -n zb-control apply -f zb-control-02-role.yaml

# only deploy the secret manually
#kubectl -n zb-control apply -f zb-control-03-secret.yaml

kubectl -n zb-control delete  deployment.apps/zb-control
kubectl -n zb-control apply -f zb-control-04-deploy.yaml
kubectl -n zb-control apply -f zb-control-05-ingress.yaml
kubectl -n zb-control apply -f zb-control-06-service.yaml
