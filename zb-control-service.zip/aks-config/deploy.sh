#!/bin/bash
cd "$(dirname "$0")"

# Check arg count
if [ $# -ne 9 ];then
		echo "Usage: setup-caas.sh K8SConfig(Base64) Environment(DEV|NONPROD|PROD) EVAClientId EVAClientScope EVAClientSecret EVATokenUri EVAWebHookUri EVAItGtmUri LOG_LEVEL"
		exit 1
fi

export K8SConfig=$1
export ENVIRONMENT=$2
export EVAClientId=$3
export EVAClientScope=$4
export EVAClientSecret=$5
export EVATokenUri=$6
export EVAWebHookUri=$7
export EVAItGtmUri=$8
export LOG_LEVEL=$9

echo -n $K8SConfig | base64 -d >kube.config
export KUBECONFIG=$PWD/kube.config

kubectl -n zb delete replicaset.apps/zb-control

cat zb-control-replicaset.yaml | envsubst | kubectl -n zb apply -f -
cat zb-control-service.yaml | envsubst | kubectl -n zb apply -f -
#cat zb-control-ingress.yaml | envsubst | kubectl -n zb apply -f -
