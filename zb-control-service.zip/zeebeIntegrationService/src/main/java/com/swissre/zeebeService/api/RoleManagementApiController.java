package com.swissre.zeebeService.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.bpm.grpc.customgateway.*;
import com.swissre.zeebeService.grpc.RoleManagementClient;
import com.swissre.zeebeService.model.ClientRole;
import com.swissre.zeebeService.model.GetRolesResponse;
import com.swissre.zeebeService.model.GetRolesResponseRoles;
import com.swissre.zeebeService.model.ResponseStatus;
import com.swissre.zeebeService.util.BasicAuthHelper;
import io.grpc.StatusRuntimeException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

import static com.swissre.zeebeService.util.ResponseEntityHandler.getResponseEntityFromStatus;

@Controller
@Api(value = "RoleManagement", description = "the RoleManagement API", tags = {"Role Management",})
public class RoleManagementApiController implements RoleManagementApi {
    private static final Logger LOG = LogManager.getLogger(RoleManagementApiController.class);
    private final ObjectMapper objectMapper;
    private final HttpServletRequest request;

    @Value("${zeebeBroker.host}")
    private String hostName;

    @Value("${zeebeBroker.port}")
    private String portNumber;

    @Value("${zeebeBroker.grpc.retries}")
    private String maxGrpcRetries;

    @org.springframework.beans.factory.annotation.Autowired
    public RoleManagementApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<ResponseStatus> registerClientRole(@ApiParam(value = "Register role credentials", required = true) @Valid @RequestBody ClientRole clientRole) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            httpStatus = HttpStatus.NOT_ACCEPTABLE;
            return new ResponseEntity<>(responseStatus, httpStatus);
        }

        RoleManagementClient client = new RoleManagementClient(hostName, Integer.valueOf(portNumber));
        ClientRoleMessage clientRequest = ClientRoleMessage.newBuilder()
                .setApm(clientRole.getApm())
                .setClientId(ClientId.newBuilder().setClientId(clientRole.getClientId()).build())
                .setRole(Role.valueOf(clientRole.getRole().toString()))
                .build();
        LOG.info("Registering {} role with {} apm for {} client.", clientRole.getRole(), clientRole.getApm(), clientRole);

        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<ResponseStatus> response = new ResponseEntity<>(new ResponseStatus(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            LOG.debug("Registering role for the {} th time.", grpcRetries);
            response = registeringClientRole(client, request.getHeader("Authorization"), clientRequest);
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                grpcRetries++;
            else
                retrying = false;
        }

        return response;
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<ResponseStatus> modifyClientRole(@ApiParam(value = "Modify role credentials", required = true) @Valid @RequestBody ClientRole clientRole) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            httpStatus = HttpStatus.NOT_ACCEPTABLE;
            return new ResponseEntity<>(responseStatus, httpStatus);
        }

        RoleManagementClient client = new RoleManagementClient(hostName, Integer.valueOf(portNumber));
        ClientRoleMessage clientRequest = ClientRoleMessage.newBuilder()
                .setApm(clientRole.getApm())
                .setClientId(ClientId.newBuilder().setClientId(clientRole.getClientId()).build())
                .setRole(Role.valueOf(clientRole.getRole().toString()))
                .build();
        LOG.info("Modifying {} role with {} apm for {} client.", clientRole.getRole(), clientRole.getApm(), clientRole);

        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<ResponseStatus> response = new ResponseEntity<>(new ResponseStatus(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            LOG.debug("Modifying role for the {} th time.", grpcRetries);
            response = modifyingClientRole(client, request.getHeader("Authorization"), clientRequest);
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                grpcRetries++;
            else
                retrying = false;
        }

        return response;
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<ResponseStatus> revokeClientRole(@ApiParam(value = "Input parameters in JSON", required = true) @Valid @RequestBody ClientRole revokeRole) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            httpStatus = HttpStatus.NOT_ACCEPTABLE;
            return new ResponseEntity<>(responseStatus, httpStatus);
        }

        RoleManagementClient client = new RoleManagementClient(hostName, Integer.valueOf(portNumber));
        RevokeRoleMessage clientRequest = RevokeRoleMessage.newBuilder()
                .setApm(revokeRole.getApm())
                .setClientId(ClientId.newBuilder().setClientId(revokeRole.getClientId()).build())
                .build();
        LOG.info("Revoking {} role with {} apm for {} client.", revokeRole.getRole(), revokeRole.getApm(), revokeRole);

        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<ResponseStatus> response = new ResponseEntity<>(new ResponseStatus(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            LOG.debug("Revoking role for the {} th time.", grpcRetries);
            response = revokingClientRole(client, request.getHeader("Authorization"), clientRequest);
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                grpcRetries++;
            else
                retrying = false;
        }

        return response;
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<GetRolesResponse> getRoles() {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();
        GetRolesResponse response = new GetRolesResponse();

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            httpStatus = HttpStatus.NOT_ACCEPTABLE;
            response.setStatus(responseStatus);
            return new ResponseEntity<>(response, httpStatus);
        }

        RoleManagementClient client = new RoleManagementClient(hostName, Integer.valueOf(portNumber));
        ClientId clientRequest = ClientId.newBuilder()
                .setClientId(BasicAuthHelper.getBasicAuthUsername(request.getHeader("Authorization")))
                .build();

        GetClientRolesResponse getClientRolesResponse;
        try {
            getClientRolesResponse = client.getClientRoles(request.getHeader("Authorization"), clientRequest);
        } catch (StatusRuntimeException e) {

            if (e.getStatus().getCode() == io.grpc.Status.Code.UNAUTHENTICATED) {
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage("Unauthenticated.");
                httpStatus = HttpStatus.UNAUTHORIZED;
            } else {
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage(e.getMessage());
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            }
            response.setStatus(responseStatus);

            return new ResponseEntity<>(response, httpStatus);
        }
        ResponseEntity<ResponseStatus> responseEntity = getResponseEntityFromStatus(getClientRolesResponse.getStatus());
        responseStatus = responseEntity.getBody();
        httpStatus = responseEntity.getStatusCode();

        if (getClientRolesResponse.getStatus().getStatusCode().equals(StatusCode.SUCCESS)) {
            List<GetRolesResponseRoles> roles = new ArrayList<>();
            for (RoleMessage role : getClientRolesResponse.getRolesList()) {
                GetRolesResponseRoles roleResponse = new GetRolesResponseRoles();
                roleResponse.apm(role.getApm());
                roleResponse.role(role.getRole().name());
                roles.add(roleResponse);
            }
            response.setRoles(roles);
        }

        response.setStatus(responseStatus);
        LOG.debug("Got following roles: {}", response.getRoles().toString());
        return new ResponseEntity<>(response, httpStatus);
    }

    private ResponseEntity<ResponseStatus> registeringClientRole(RoleManagementClient client, String authHash, ClientRoleMessage clientRequest) {
        HttpStatus httpStatus;
        ResponseStatus response = new ResponseStatus();
        Status status;

        try {
            status = client.registerClientRole(authHash, clientRequest);
        } catch (StatusRuntimeException e) {

            if (e.getStatus().getCode() == io.grpc.Status.Code.UNAUTHENTICATED) {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage("Unauthenticated.");
                httpStatus = HttpStatus.UNAUTHORIZED;
            } else {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage(e.getMessage());
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            }

            return new ResponseEntity<>(response, httpStatus);
        }
        LOG.info("Registered {} role with {} apm for {} client.", clientRequest.getRole(), clientRequest.getApm(), clientRequest.getClientId());
        return getResponseEntityFromStatus(status);
    }

    private ResponseEntity<ResponseStatus> modifyingClientRole(RoleManagementClient client, String authHash, ClientRoleMessage clientRequest) {
        HttpStatus httpStatus;
        Status status;
        ResponseStatus response = new ResponseStatus();

        try {
            status = client.modifyClientRole(authHash, clientRequest);
        } catch (StatusRuntimeException e) {

            if (e.getStatus().getCode() == io.grpc.Status.Code.UNAUTHENTICATED) {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage("Unauthenticated.");
                httpStatus = HttpStatus.UNAUTHORIZED;
            } else {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage(e.getMessage());
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            }

            return new ResponseEntity<>(response, httpStatus);
        }
        LOG.info("Modified {} role with {} apm for {} client.", clientRequest.getRole(), clientRequest.getApm(), clientRequest.getClientId());

        return getResponseEntityFromStatus(status);
    }

    private ResponseEntity<ResponseStatus> revokingClientRole(RoleManagementClient client, String authHash, RevokeRoleMessage clientRequest) {
        HttpStatus httpStatus;
        Status status;
        ResponseStatus response = new ResponseStatus();

        try {
            status = client.revokeClientRole(authHash, clientRequest);
        } catch (StatusRuntimeException e) {

            if (e.getStatus().getCode() == io.grpc.Status.Code.UNAUTHENTICATED) {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage("Unauthenticated.");
                httpStatus = HttpStatus.UNAUTHORIZED;
            } else {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage(e.getMessage());
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            }

            return new ResponseEntity<>(response, httpStatus);
        }
        LOG.info("Revoked {} apm for {} client.", clientRequest.getApm(), clientRequest.getClientId());

        return getResponseEntityFromStatus(status);
    }
}
