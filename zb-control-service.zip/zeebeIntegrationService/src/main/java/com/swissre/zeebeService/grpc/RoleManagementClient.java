package com.swissre.zeebeService.grpc;

import com.swissre.bpm.grpc.customgateway.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Metadata;
import io.grpc.stub.MetadataUtils;

public class RoleManagementClient {
    ManagedChannel channel;

    public RoleManagementClient(String authHost, int authPort) {
        channel = ManagedChannelBuilder
                .forAddress(authHost, authPort)
                .usePlaintext()
                .build();
    }

    private RoleManagementServiceGrpc.RoleManagementServiceBlockingStub createStub(String authHash) {
        Metadata header = new Metadata();
        final Metadata.Key<String> AUTHORIZATION_METADATA_KEY =
                Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER);
        header.put(AUTHORIZATION_METADATA_KEY, authHash);

        RoleManagementServiceGrpc.RoleManagementServiceBlockingStub stub = RoleManagementServiceGrpc
                .newBlockingStub(channel);
        stub = MetadataUtils.attachHeaders(stub, header);

        return stub;
    }

    public Status registerClientRole(String authHash, ClientRoleMessage request) {
        return createStub(authHash).addClientRoleForApm(request);
    }

    public Status modifyClientRole(String authHash, ClientRoleMessage request) {
        return createStub(authHash).modifyClientRoleForApm(request);
    }

    public Status revokeClientRole(String authHash, RevokeRoleMessage request) {
        return createStub(authHash).revokeClientRoleForApm(request);
    }

    public GetClientRolesResponse getClientRoles(String authHash, ClientId request) {
        return createStub(authHash).getClientRoles(request);
    }
}
