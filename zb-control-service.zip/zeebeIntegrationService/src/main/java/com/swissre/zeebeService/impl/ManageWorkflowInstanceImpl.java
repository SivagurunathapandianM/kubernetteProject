package com.swissre.zeebeService.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.gson.Gson;
import com.swissre.zeebeService.elastic.model.*;
import com.swissre.zeebeService.model.WorkflowStatusByProcessIdValue;
import com.swissre.zeebeService.model.*;
import com.swissre.zeebeService.util.AuthCredentialsProvider;
import io.zeebe.client.ZeebeClient;
import io.zeebe.client.ZeebeClientBuilder;
import io.zeebe.client.api.response.WorkflowInstanceEvent;
import org.apache.http.HttpHost;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import javax.xml.bind.DatatypeConverter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class ManageWorkflowInstanceImpl {
    private static final Logger LOG = LogManager.getLogger(ManageWorkflowInstanceImpl.class);
    private Properties appProps;

    private static Properties loadProperties() throws IOException {
        Properties appProps = new Properties();
        appProps.load(Objects.requireNonNull(ManageWorkflowInstanceImpl.class.getClassLoader().getResourceAsStream("application.properties")));
        return appProps;
    }

    @Deprecated
    public CancelAllWorkflowInstancesResponse cancelAllWorkflowInstances(String authCredentials, String workflowId, int version, String hostName, String portNumber) throws IOException {
        CancelAllWorkflowInstancesResponse response = new CancelAllWorkflowInstancesResponse();

        appProps = loadProperties();
        final ZeebeClientBuilder clientBuilder = ZeebeClient.newClientBuilder().brokerContactPoint(hostName + ":" + portNumber)
                .credentialsProvider(new AuthCredentialsProvider(authCredentials))
                .defaultJobTimeout(Duration.ofSeconds(Long.valueOf(appProps.getProperty("zeebeBroker.timeoutSecs")))).usePlaintext();
        RestHighLevelClient elkClient = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost(appProps.getProperty("elasticSearch.host"), Integer.parseInt(appProps.getProperty("elasticSearch.port")), "https")));
        SearchRequest searchRequest = new SearchRequest("zeebe-record-workflow-instance");
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder query = QueryBuilders.boolQuery()
                .filter(QueryBuilders.termQuery("value.bpmnProcessId", workflowId))
                .filter(QueryBuilders.termQuery("value.version", version));
        sourceBuilder.query(query);
        sourceBuilder.size(1000);
        sourceBuilder.timeout(new TimeValue(60, TimeUnit.SECONDS));
        searchRequest.source(sourceBuilder);
        SearchResponse searchResponse = elkClient.search(searchRequest, RequestOptions.DEFAULT);

        Set<Long> instances = new HashSet<>();
        if (searchResponse.getHits().totalHits != 0) {
            for (SearchHit hit : searchResponse.getHits()) {
                WorkflowInstanceByWorkflowIdSource hitSource = new Gson().fromJson(hit.getSourceAsString(), WorkflowInstanceByWorkflowIdSource.class);
                if (hitSource.getIntent().equals("ELEMENT_TERMINATED") || hitSource.getIntent().equals("ELEMENT_COMPLETED")) {
                    instances.remove(hitSource.getValue().getWorkflowInstanceKey());
                } else {
                    instances.add(hitSource.getValue().getWorkflowInstanceKey());
                }
            }
            elkClient.close();
            LOG.info("Retrieved " + instances.size() + " instances for cancelAllWorkflowInstances.");
            LOG.info("Deleting workflow instances");

            List<RemoveObjectResponse> responses = new ArrayList<>();
            for (Long instanceId : instances) {
                RemoveObjectResponse removeObject = new RemoveObjectResponse();
                removeObject.setInstanceId(instanceId);
                if (cancelInstance(clientBuilder, instanceId) == null) {
                    removeObject.setStatus(RemoveObjectResponse.StatusEnum.SUCCESS);
                } else {
                    removeObject.setStatus(RemoveObjectResponse.StatusEnum.FAILED);
                }
                responses.add(removeObject);
            }
            response.setCancelAllWorkflowInstances(responses);
            ResponseStatus responseStatus = new ResponseStatus();
            responseStatus.status(ResponseStatus.StatusEnum.SUCCESS);
            responseStatus.message("Retrieved " + instances.size() + " instances for cancelAllWorkflowInstances.");
            response.setResponseStatus(responseStatus);
            return response;
        }

        ResponseStatus responseStatus = new ResponseStatus();
        responseStatus.status(ResponseStatus.StatusEnum.SUCCESS);
        responseStatus.message("Hasn't found instances!");
        response.setResponseStatus(responseStatus);
        return response;
    }

    public WorkflowInstancesResponse getWorkflowInstancesByWorkflowId(String workflowId, String status, int from, int size) throws IOException {
        WorkflowInstancesResponse response = new WorkflowInstancesResponse();
        appProps = loadProperties();
        String statusQuery;
        switch (status) {
            case "active":
                statusQuery = "ELEMENT_ACTIVATED";
                break;
            case "completed":
                statusQuery = "ELEMENT_COMPLETED";
                break;
            case "cancelled":
                statusQuery = "ELEMENT_TERMINATED";
                break;
            default:
                statusQuery = "";
        }
        RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost(appProps.getProperty("elasticSearch.host"), Integer.parseInt(appProps.getProperty("elasticSearch.port")), "https")));
        SearchRequest searchRequest = new SearchRequest("zeebe-record-workflow-instance");
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder query = QueryBuilders.boolQuery()
                .filter(QueryBuilders.termQuery("value.bpmnProcessId", workflowId));
        if (!statusQuery.isEmpty())
            query.filter(QueryBuilders.termQuery("intent", statusQuery));
        sourceBuilder.query(query);
        sourceBuilder.from(from);
        sourceBuilder.size(size);
        sourceBuilder.timeout(new TimeValue(60, TimeUnit.SECONDS));
        searchRequest.source(sourceBuilder);
        SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

        Set<WorkflowInstance> instances = new HashSet<>();
        if (searchResponse.getHits().totalHits != 0) {
            for (SearchHit hit : searchResponse.getHits()) {
                WorkflowInstanceByWorkflowIdSource hitSource = new Gson().fromJson(hit.getSourceAsString(), WorkflowInstanceByWorkflowIdSource.class);
                WorkflowInstance instance = new WorkflowInstance();
                instance.setBpmnProcessId(hitSource.getValue().getBpmnProcessId());
                instance.setVersion(hitSource.getValue().getVersion());
                instance.setWorkflowInstanceKey(hitSource.getValue().getWorkflowInstanceKey());
                instance.setWorkflowKey(hitSource.getValue().getWorkflowKey());
                instances.add(instance);
            }
        }
        client.close();
        LOG.info("Retrieved " + instances.size() + " instances for getWorkflowInstancesByWorkflowId.");
        response.setWorkflowInstances(new ArrayList<>(instances));
        ResponseStatus responseStatus = new ResponseStatus();
        responseStatus.status(ResponseStatus.StatusEnum.SUCCESS);
        responseStatus.message("Retrieved " + instances.size() + " instances for getWorkflowInstancesByWorkflowId.");
        response.setResponseStatus(responseStatus);
        return response;
    }

    public WorkflowInstanceByIdResponse getWorkflowInstancesById(String instanceId, int from, int size) throws IOException {
        WorkflowInstanceByIdResponse response = new WorkflowInstanceByIdResponse();
        appProps = loadProperties();

        RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost(appProps.getProperty("elasticSearch.host"), Integer.parseInt(appProps.getProperty("elasticSearch.port")), "https")));
        SearchRequest searchRequest = new SearchRequest("zeebe-record-workflow-instance");
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder query = QueryBuilders.boolQuery()
                .filter(QueryBuilders.termQuery("value.workflowInstanceKey", instanceId));
        sourceBuilder.query(query);
        sourceBuilder.from(from);
        sourceBuilder.size(size);
        sourceBuilder.timeout(new TimeValue(60, TimeUnit.SECONDS));
        searchRequest.source(sourceBuilder);
        SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

        Set<WorkflowInstanceById> instances = new HashSet<>();
        if (searchResponse.getHits().totalHits != 0) {
            for (SearchHit hit : searchResponse.getHits()) {
                WorkflowInstanceByInstanceIdSource hitSource = new Gson().fromJson(hit.getSourceAsString(), WorkflowInstanceByInstanceIdSource.class);
                WorkflowInstanceById instance = new WorkflowInstanceById();
                instance.setPartitionId(hitSource.getPartitionId());
                instance.setSourceRecordPosition(hitSource.getSourceRecordPosition());
                instance.setPosition(hitSource.getPosition());
                instance.setKey(hitSource.getKey());
                instance.setRecordType(hitSource.getRecordType());
                instance.setValueType(hitSource.getValueType());
                instance.setTimestamp(hitSource.getTimestamp());
                instance.setDate(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX")
                        .format(new Timestamp(hitSource.getTimestamp())));
                instance.setIntent(hitSource.getIntent());
                instance.setRejectionType(hitSource.getRejectionType());
                instance.setRejectionReason(hitSource.getRejectionReason());

                WorkflowInstanceByIdValue value = new WorkflowInstanceByIdValue();
                value.setVersion(hitSource.getValue().getVersion());
                value.setBpmnProcessId(hitSource.getValue().getBpmnProcessId());
                value.setWorkflowKey(hitSource.getValue().getWorkflowKey());
                value.setFlowScopeKey(hitSource.getValue().getFlowScopeKey());
                value.setBpmnElementType(hitSource.getValue().getBpmnElementType());
                value.setParentWorkflowInstanceKey(hitSource.getValue().getParentWorkflowInstanceKey());
                value.setElementId(hitSource.getValue().getElementId());
                value.setWorkflowInstanceKey(hitSource.getValue().getWorkflowInstanceKey());
                value.setParentElementInstanceKey(hitSource.getValue().getParentElementInstanceKey());

                instance.setValue(value);
                instances.add(instance);
            }
        }
        client.close();
        LOG.info("Retrieved " + instances.size() + " instances for getWorkflowInstanceById.");
        response.instances(new ArrayList<>(instances));
        ResponseStatus responseStatus = new ResponseStatus();
        responseStatus.status(ResponseStatus.StatusEnum.SUCCESS);
        responseStatus.message("Retrieved " + instances.size() + " instances for getWorkflowInstanceById.");
        response.setResponseStatus(responseStatus);
        return response;
    }

    @Deprecated
    private String cancelInstance(ZeebeClientBuilder clientBuilder, Long instanceId) {
        try (ZeebeClient zbClient = clientBuilder.build()) {
            zbClient.newCancelInstanceCommand(instanceId)
                    .requestTimeout(Duration.ofSeconds(Long.valueOf(appProps.getProperty("zeebeBroker.timeoutSecs")))).send().join();
            LOG.info("Workflow instance deleted with workflowId: " + instanceId);
            return null;
        } catch (Exception e) {
            LOG.error("Workflow instance not found with id: " + instanceId + ". " + e.getMessage());
            return e.getMessage();
        }
    }


    public WorkflowStatusByProcessIdResponse getWorkflowStatusByProcessId(String bpmProcessId) throws IOException {
        WorkflowStatusByProcessIdResponse response = new WorkflowStatusByProcessIdResponse();
        appProps = loadProperties();

        RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost(appProps.getProperty("elasticSearch.host"), Integer.parseInt(appProps.getProperty("elasticSearch.port")), "https")));
        SearchRequest searchRequest = new SearchRequest("zeebe-record-deployment");
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder query = QueryBuilders.boolQuery()
                .filter(QueryBuilders.termQuery("value.deployedWorkflows.bpmnProcessId", bpmProcessId));
        sourceBuilder.query(query);
        sourceBuilder.timeout(new TimeValue(60, TimeUnit.SECONDS));
        searchRequest.source(sourceBuilder);
        SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

        Set<WorkflowStatusByProcessId> workflowStatus = new HashSet<>();
        if (searchResponse.getHits().totalHits != 0) {
            for (SearchHit hit : searchResponse.getHits()) {
                WorkflowStatusByProcessIdSource hitSource = new Gson().fromJson(hit.getSourceAsString(), WorkflowStatusByProcessIdSource.class);
                WorkflowStatusByProcessId status = new WorkflowStatusByProcessId();
                status.setPartitionId(hitSource.getPartitionId());
                status.setSourceRecordPosition(hitSource.getSourceRecordPosition());
                status.setPosition(hitSource.getPosition());
                status.setKey(hitSource.getKey());
                status.setRecordType(hitSource.getRecordType());
                status.setValueType(hitSource.getValueType());
                status.setTimestamp(hitSource.getTimestamp());
                status.setDate(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX")
                        .format(new Timestamp(hitSource.getTimestamp())));
                status.setIntent(hitSource.getIntent());
                status.setRejectionType(hitSource.getRejectionType());
                status.setRejectionReason(hitSource.getRejectionReason());

                WorkflowStatusByProcessIdValue value = new WorkflowStatusByProcessIdValue();

                if (!hitSource.getValue().getDeployWorkFlows().isEmpty()) {
                    Workflow deployedWorkflows;
                    for (WorkflowStatusDeployWorkflowsValue deploywf : hitSource.getValue().getDeployWorkFlows()) {
                        deployedWorkflows = new Workflow();
                        deployedWorkflows.setBpmnProcessId(deploywf.getBpmnProcessId());
                        deployedWorkflows.setResourceName(deploywf.getResourceName());
                        deployedWorkflows.setVersion(deploywf.getVersion());
                        deployedWorkflows.setWorkflowKey(deploywf.getWorkflowKey());
                        value.getDeployedWorkflows().add(deployedWorkflows);
                    }
                }

                if (!hitSource.getValue().getResources().isEmpty()) {
                    WorkflowStatusByProcessIdValueResoures resources;
                    for (WorkflowStatusResourcesValue resource : hitSource.getValue().getResources()) {
                        resources = new WorkflowStatusByProcessIdValueResoures();
                        resources.setResource(new String(DatatypeConverter.parseBase64Binary(resource.getResource())));
                        resources.setResourceName(resource.getResourceName());
                        resources.setResourceType(resource.getResourceType());
                        value.resources(resources);
                    }
                }
                status.setValue(value);
                workflowStatus.add(status);
            }
        }
        client.close();
        LOG.info(workflowStatus.size() + " deployment status retrieved for getWorkflowStatusByProcessId.");
        response.workflowStatus(new ArrayList<>(workflowStatus));
        ResponseStatus responseStatus = new ResponseStatus();
        responseStatus.status(ResponseStatus.StatusEnum.SUCCESS);
        responseStatus.message(workflowStatus.size() + " deployment status retrieved for getWorkflowStatusByProcessId.");
        response.responseStatus(responseStatus);
        return response;
    }
}
