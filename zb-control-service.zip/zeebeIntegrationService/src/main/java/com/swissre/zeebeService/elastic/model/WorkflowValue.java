package com.swissre.zeebeService.elastic.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class WorkflowValue {
    @SerializedName("deployedWorkflows")
    private List<DeployedWorkflow> deployedWorkflows = null;
    @SerializedName("resources")
    private List<WorkflowResource> resources = null;

    public List<DeployedWorkflow> getDeployedWorkflows() {
        return deployedWorkflows;
    }

    public void setDeployedWorkflows(List<DeployedWorkflow> deployedWorkflows) {
        this.deployedWorkflows = deployedWorkflows;
    }

    public List<WorkflowResource> getResources() {
        return resources;
    }

    public void setResources(List<WorkflowResource> resources) {
        this.resources = resources;
    }
}
