package com.swissre.zeebeService.grpc;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Struct;
import com.google.protobuf.util.JsonFormat;
import com.swissre.bpm.zbshowworkflow.ZbShowWorkflow;
import com.swissre.bpm.zbshowworkflow.ZeebeShowWorkflowServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.concurrent.Executors;

public class ShowWorkflowClient {
    private ManagedChannel channel;
    private ZeebeShowWorkflowServiceGrpc.ZeebeShowWorkflowServiceFutureStub stub;

    private static final Logger LOG = LogManager.getLogger(ShowWorkflowClient.class);

    public ShowWorkflowClient(String authHost, int authPort) {
        this.channel = ManagedChannelBuilder
                .forAddress(authHost, authPort)
                .usePlaintext()
                .build();
        this.stub = createStub();
    }

    private ZeebeShowWorkflowServiceGrpc.ZeebeShowWorkflowServiceFutureStub createStub() {
        return ZeebeShowWorkflowServiceGrpc.newFutureStub(channel);
    }

    public void processWorknoteCandidate(String params, long workflowInstanceKey) {
        try {
            Struct.Builder structBuilder = Struct.newBuilder();
            JsonFormat.parser().merge(params, structBuilder);

            processWorknoteCandidate(
                ZbShowWorkflow.WorknoteCandidate
                    .newBuilder()
                    .setVariables(structBuilder.build())
                    .setWorkflowInstanceKey(workflowInstanceKey)
                    .build()
            );
        } catch (InvalidProtocolBufferException e) {
            LOG.error("Variables could not be parsed into Struct", e);
        }
    }

    public void processWorknoteCandidate(ZbShowWorkflow.WorknoteCandidate request) {
        processWorknoteCandidate(request, 3);
    }

    public void processWorknoteCandidate(ZbShowWorkflow.WorknoteCandidate request, int retries) {
        ListenableFuture<ZbShowWorkflow.WorknoteUpdateResponse> worknoteUpdateResponseFuture = stub.processWorknoteCandidate(request);

        Futures.addCallback(
                worknoteUpdateResponseFuture,
                new FutureCallback<>() {
                    @Override
                    public void onSuccess(ZbShowWorkflow.@Nullable WorknoteUpdateResponse result) {
                        LOG.debug("gRPC message for instancekey {} sent successfully.", request.getWorkflowInstanceKey());
                    }

                    @Override
                    public void onFailure(Throwable t) {
                        LOG.error("Sending gRPC message for instancekey " + request.getWorkflowInstanceKey() + " failed.", t);
                        int retriesLeft = retries - 1;
                        if (retriesLeft > 0){
                            LOG.info("{} retries left ({})", retriesLeft, request.getWorkflowInstanceKey());
                            processWorknoteCandidate(request, retriesLeft);
                        } else {
                            LOG.info("Sending gRPC message for instancekey ({}) failed, no retries left.", request.getWorkflowInstanceKey());
                        }
                    }
                },
                Executors.newSingleThreadExecutor());
    }
}
