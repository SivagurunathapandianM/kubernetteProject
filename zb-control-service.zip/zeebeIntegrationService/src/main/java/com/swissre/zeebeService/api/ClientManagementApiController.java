package com.swissre.zeebeService.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.bpm.grpc.customgateway.ClientCredentialsMessage;
import com.swissre.bpm.grpc.customgateway.Status;
import com.swissre.zeebeService.grpc.ClientManagementClient;
import com.swissre.zeebeService.model.ClientCredentials;
import com.swissre.zeebeService.model.ResponseStatus;
import io.grpc.StatusRuntimeException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import static com.swissre.zeebeService.util.ResponseEntityHandler.getResponseEntityFromStatus;

@Controller
@Api(value = "ClientManagement", description = "the ClientManagement API", tags = {"Client Management",})
public class ClientManagementApiController implements ClientManagementApi {
    private static final Logger LOG = LogManager.getLogger(ClientManagementApiController.class);
    private final ObjectMapper objectMapper;
    private final HttpServletRequest request;

    @Value("${zeebeBroker.host}")
    private String hostName;

    @Value("${zeebeBroker.port}")
    private String portNumber;

    @Value("${zeebeBroker.grpc.retries}")
    private String maxGrpcRetries;

    @org.springframework.beans.factory.annotation.Autowired
    public ClientManagementApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<ResponseStatus> registerClient(@ApiParam(value = "Client credentials", required = true) @Valid @RequestBody ClientCredentials clientCredentials) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();
        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            httpStatus = HttpStatus.NOT_ACCEPTABLE;
            return new ResponseEntity<>(responseStatus, httpStatus);
        }
        LOG.info("Registering client: {}", clientCredentials.getClientId());

        ClientManagementClient client = new ClientManagementClient(hostName, Integer.valueOf(portNumber));
        ClientCredentialsMessage clientRequest = ClientCredentialsMessage.newBuilder()
                .setClientId(com.swissre.bpm.grpc.customgateway.ClientId.newBuilder().setClientId(clientCredentials.getClientId()).build())
                .setPassword(clientCredentials.getPassword())
                .build();

        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<ResponseStatus> response = new ResponseEntity<>(new ResponseStatus(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            LOG.debug("Registering client for the {} th time.", grpcRetries);
            response = registeringClient(client, request.getHeader("Authorization"), clientRequest);
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                grpcRetries++;
            else
                retrying = false;
        }

        return response;
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<ResponseStatus> changeClientPassword(@ApiParam(value = "Change client password credentials", required = true) @Valid @RequestBody ClientCredentials clientCredentials) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            httpStatus = HttpStatus.NOT_ACCEPTABLE;
            return new ResponseEntity<>(responseStatus, httpStatus);
        }
        LOG.info("Changing password for client: {}", clientCredentials.getClientId());

        ClientManagementClient client = new ClientManagementClient(hostName, Integer.valueOf(portNumber));
        ClientCredentialsMessage clientRequest = ClientCredentialsMessage.newBuilder()
                .setClientId(com.swissre.bpm.grpc.customgateway.ClientId.newBuilder().setClientId(clientCredentials.getClientId()).build())
                .setPassword(clientCredentials.getPassword())
                .build();

        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<ResponseStatus> response = new ResponseEntity<>(new ResponseStatus(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            LOG.debug("Changing client password for the {} th time.", grpcRetries);
            response = changingClientPassword(client, request.getHeader("Authorization"), clientRequest);
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                grpcRetries++;
            else
                retrying = false;
        }

        return response;
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<ResponseStatus> removeClient(@ApiParam(value = "ID of client that needs to be deleted", required = true) @PathVariable("clientId") String clientId) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            httpStatus = HttpStatus.NOT_ACCEPTABLE;
            return new ResponseEntity<>(responseStatus, httpStatus);
        }
        LOG.info("Removing client: {}", clientId);

        ClientManagementClient client = new ClientManagementClient(hostName, Integer.valueOf(portNumber));
        com.swissre.bpm.grpc.customgateway.ClientId clientRequest = com.swissre.bpm.grpc.customgateway.ClientId.newBuilder()
                .setClientId(clientId)
                .build();

        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<ResponseStatus> response = new ResponseEntity<>(new ResponseStatus(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            LOG.debug("Removing client for the {} th time.", grpcRetries);
            response = removingClient(client, request.getHeader("Authorization"), clientRequest);
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                grpcRetries++;
            else
                retrying = false;
        }

        return response;
    }

    private ResponseEntity<ResponseStatus> registeringClient(ClientManagementClient client, String authHash, ClientCredentialsMessage clientRequest) {
        HttpStatus httpStatus;
        ResponseStatus response = new ResponseStatus();
        Status status;

        try {
            status = client.registerClient(authHash, clientRequest);
        } catch (StatusRuntimeException e) {

            if (e.getStatus().getCode() == io.grpc.Status.Code.UNAUTHENTICATED) {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage("Unauthenticated.");
                httpStatus = HttpStatus.UNAUTHORIZED;
            } else {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage(e.getMessage());
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            }

            return new ResponseEntity<>(response, httpStatus);
        }
        LOG.debug("Client is registered: {}", clientRequest.getClientId());

        return getResponseEntityFromStatus(status);
    }

    private ResponseEntity<ResponseStatus> changingClientPassword(ClientManagementClient client, String authHash, ClientCredentialsMessage clientRequest) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();
        Status status;

        try {
            status = client.changeClientPassword(request.getHeader("Authorization"), clientRequest);
        } catch (StatusRuntimeException e) {

            if (e.getStatus().getCode() == io.grpc.Status.Code.UNAUTHENTICATED) {
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage("Unauthenticated.");
                httpStatus = HttpStatus.UNAUTHORIZED;
            } else {
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage(e.getMessage());
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            }

            return new ResponseEntity<>(responseStatus, httpStatus);
        }
        LOG.debug("Client password is changed: {}", clientRequest.getClientId());

        return getResponseEntityFromStatus(status);
    }

    private ResponseEntity<ResponseStatus> removingClient(ClientManagementClient client, String authHash, com.swissre.bpm.grpc.customgateway.ClientId clientRequest) {
        HttpStatus httpStatus;
        ResponseStatus response = new ResponseStatus();
        Status status;

        try {
            status = client.removeClient(request.getHeader("Authorization"), clientRequest);
        } catch (StatusRuntimeException e) {

            if (e.getStatus().getCode() == io.grpc.Status.Code.UNAUTHENTICATED) {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage("Unauthenticated.");
                httpStatus = HttpStatus.UNAUTHORIZED;
            } else {
                response.setStatus(ResponseStatus.StatusEnum.ERROR);
                response.setMessage(e.getMessage());
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            }

            return new ResponseEntity<>(response, httpStatus);
        }
        LOG.debug("Client is removed: {}", clientRequest.getClientId());

        return getResponseEntityFromStatus(status);
    }
}
