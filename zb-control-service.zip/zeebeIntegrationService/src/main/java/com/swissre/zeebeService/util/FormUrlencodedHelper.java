package com.swissre.zeebeService.util;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.stream.Collectors;

public class FormUrlencodedHelper {
    public static String hashMap2FormUrlencoded(HashMap<String, String> hashMap) {
        return hashMap.keySet().stream()
                .map(key -> key + "=" + URLEncoder.encode(hashMap.get(key), StandardCharsets.UTF_8))
                .collect(Collectors.joining("&"));
    }
}
