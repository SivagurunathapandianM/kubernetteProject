package com.swissre.zeebeService.elastic.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class WorkflowStatusByProcessIdValue {
    @SerializedName("deployedWorkflows")
    private List<WorkflowStatusDeployWorkflowsValue> deployWorkFlows = new ArrayList<WorkflowStatusDeployWorkflowsValue>();

    @SerializedName("resources")
    private List<WorkflowStatusResourcesValue> resources = new ArrayList<WorkflowStatusResourcesValue>();

    public List<WorkflowStatusDeployWorkflowsValue> getDeployWorkFlows() {
        return deployWorkFlows;
    }

    public void setDeployWorkFlows(List<WorkflowStatusDeployWorkflowsValue> deployWorkFlows) {
        this.deployWorkFlows = deployWorkFlows;
    }

    public List<WorkflowStatusResourcesValue> getResources() {
        return resources;
    }

    public void setResources(List<WorkflowStatusResourcesValue> resources) {
        this.resources = resources;
    }
}
