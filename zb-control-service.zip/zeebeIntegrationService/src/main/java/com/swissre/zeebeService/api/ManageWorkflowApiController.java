package com.swissre.zeebeService.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.protobuf.ByteString;
import com.swissre.zeebeService.grpc.ZeebeBrokerClient;
import com.swissre.zeebeService.model.*;
import io.grpc.StatusRuntimeException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import io.zeebe.gateway.protocol.GatewayOuterClass;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.swissre.zeebeService.util.ResponseEntityHandler.getResponseEntityFromStatusCode;

@Configuration
@PropertySource("classpath:application.properties")
@RestController
@Api(value = "Workflow", description = "the Workflow API", tags = {"Workflow",})
public class ManageWorkflowApiController implements WorkflowApi {

    @Value("${zeebeBroker.grpc.retries}")
    private String maxGrpcRetries;

    private static final Logger LOG = LogManager.getLogger(ManageWorkflowInstanceApiController.class);
    private final ObjectMapper objectMapper;
    private final HttpServletRequest request;
    private final ZeebeBrokerClient zeebeBrokerClient;

    @org.springframework.beans.factory.annotation.Autowired
    private Environment env;

    @org.springframework.beans.factory.annotation.Autowired
    public ManageWorkflowApiController(Environment env, ObjectMapper objectMapper, HttpServletRequest request) {
        this.env = env;
        this.objectMapper = objectMapper;
        this.request = request;
        zeebeBrokerClient = new ZeebeBrokerClient(env.getProperty("zeebeBroker.host"),
                Integer.parseInt(Objects.requireNonNull(env.getProperty("zeebeBroker.port"))),
                Integer.parseInt(Objects.requireNonNull(env.getProperty("zeebeBroker.timeoutSecs"))));
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<WorkflowDeployResponse> deployWorkflow(@ApiParam(value = "") @Valid @RequestPart(value = "workflow") MultipartFile uploadFile) {
        WorkflowDeployResponse workflowDeployResponse = new WorkflowDeployResponse();
        ResponseStatus responseStatus = new ResponseStatus();
        HttpStatus httpStatus;

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            workflowDeployResponse.setResponseStatus(responseStatus);
            return new ResponseEntity<>(workflowDeployResponse, HttpStatus.NOT_ACCEPTABLE);
        }

        if (!uploadFile.isEmpty()) {
            LOG.trace("Going to start the deploy functionality");
            GatewayOuterClass.DeployWorkflowResponse deployWorkflowResponse;
            try {

                ByteArrayInputStream stream = new ByteArrayInputStream(uploadFile.getBytes());
                String myString = IOUtils.toString(stream, "UTF-8");
                if (myString == null || myString.isBlank()) {
                    throw new IOException("Unable to read file.");
                }

                LOG.info("Deploying workflow with file: {}", uploadFile.getOriginalFilename());
                int grpcRetries = 0;
                boolean retrying = true;
                ResponseEntity<WorkflowDeployResponse> response = new ResponseEntity<>(new WorkflowDeployResponse(), HttpStatus.NOT_ACCEPTABLE);
                while (retrying) {
                    LOG.debug("Deploying workflow for the {} th time.", grpcRetries);
                    response = deployingWorkflow(zeebeBrokerClient, request.getHeader("Authorization"), uploadFile);
                    if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED)
                            && !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                        grpcRetries++;
                    else
                        retrying = false;
                }

                return response;

            } catch (IOException e) {
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            }
            workflowDeployResponse.setResponseStatus(responseStatus);
            return new ResponseEntity<>(workflowDeployResponse, httpStatus);
        } else {
            LOG.error("Uploaded file is empty");
            responseStatus.setMessage("Uploaded file is empty");
            responseStatus.setStatus(ResponseStatus.StatusEnum.FAILED);
            workflowDeployResponse.setResponseStatus(responseStatus);
            return new ResponseEntity<>(workflowDeployResponse, HttpStatus.BAD_REQUEST);
        }
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<RemoveObjectResponse> deleteWorkflow(@ApiParam(value = "ID of workflow that needs to be deleted", required = true) @PathVariable("workflowId") String workflowId,
                                                               @NotNull @ApiParam(value = "version of workflow that needs to be deleted", required = true) @Valid @RequestParam(value = "version", required = true) Integer version) {
        String accept = request.getHeader(HttpHeaders.ACCEPT);
        LOG.info("accept: {}", accept);
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }

    //    @Override
//    public ResponseEntity<ListWorkflowsResponse> listWorkflowsDeployedIntoZeebe(@RequestParam(name = "version", required = false) Integer version,
//                                                               @RequestParam(name = "resourceName", required = false) String workflowKey,
//                                                               @RequestParam(name = "bpmnProcessId", required = false) String bpmnProcessId,
//                                                               @RequestParam(name = "workflowKey", required = false) String resourceName) {
//        String accept = request.getHeader(HttpHeaders.ACCEPT);
//        log.info("accept: " + accept);
//        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
//        HttpStatus httpStatus;
//
//        ManageWorkflowImpl manageWorkflow = new ManageWorkflowImpl();
//        ListWorkflowsResponse response = null;
//        try {
//            response = manageWorkflow.listOfWorflows(resourceName, bpmnProcessId, workflowKey, version);
//            httpStatus = HttpStatus.OK;
//        } catch (
//                Exception e) {
//            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
//        }
//        return new ResponseEntity<>(response, httpStatus);
//    }
    //WorkflowStatus Controller
    public ResponseEntity<WorkflowInstance> workflowStatus(String workflowId, String version) {
        String accept = request.getHeader(HttpHeaders.ACCEPT);
        LOG.info("accept: {}", accept);
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }

    private ResponseEntity<WorkflowDeployResponse> deployingWorkflow(ZeebeBrokerClient client, String authHash, MultipartFile uploadFile) {
        WorkflowDeployResponse workflowDeployResponse = new WorkflowDeployResponse();
        ResponseStatus responseStatus = new ResponseStatus();
        HttpStatus httpStatus;

        GatewayOuterClass.DeployWorkflowResponse deployWorkflowResponse = null;
        try {
            deployWorkflowResponse = zeebeBrokerClient.deployWorkflow(GatewayOuterClass.DeployWorkflowRequest.newBuilder()
                    .addWorkflows(
                            GatewayOuterClass.WorkflowRequestObject.newBuilder()
                                    .setType(GatewayOuterClass.WorkflowRequestObject.ResourceType.FILE)
                                    .setName(Objects.requireNonNull(uploadFile.getOriginalFilename()))
                                    .setDefinition(ByteString.copyFrom(uploadFile.getBytes()))
                                    .build())
                    .build(), authHash);
        } catch (IOException e) {
            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
            workflowDeployResponse.setResponseStatus(responseStatus);
            return new ResponseEntity<>(workflowDeployResponse, httpStatus);
        } catch (StatusRuntimeException e) {
            ResponseEntity<ResponseStatus> responseEntity = getResponseEntityFromStatusCode(e);

            workflowDeployResponse.setResponseStatus(responseEntity.getBody());
            return new ResponseEntity<>(workflowDeployResponse, responseEntity.getStatusCode());
        }


        WorkflowDeploy workflowDeploy = new WorkflowDeploy();
        workflowDeploy.setKey(deployWorkflowResponse.getKey());
        workflowDeploy.setWorkflowName(uploadFile.getOriginalFilename());
        workflowDeploy.setWorkflowStatus("DEPLOYED");
        if (deployWorkflowResponse.getWorkflowsList().size() > 0) {
            List<Workflow> workflows = new ArrayList<>();
            for (GatewayOuterClass.WorkflowMetadata iterator : deployWorkflowResponse.getWorkflowsList()) {
                Workflow workflow = new Workflow();
                workflow.setResourceName(iterator.getResourceName());
                workflow.setBpmnProcessId(iterator.getBpmnProcessId());
                workflow.setVersion(iterator.getVersion());
                workflow.setWorkflowKey(iterator.getWorkflowKey());
                workflows.add(workflow);
            }
            workflowDeploy.setWorkflows(workflows);
        }
        workflowDeployResponse.workflowDeploy(workflowDeploy);

        LOG.debug("Workflow is deployed: {}", workflowDeploy.toString());
        responseStatus.setStatus(ResponseStatus.StatusEnum.SUCCESS);
        responseStatus.setMessage("Workflow deployed successfully");
        httpStatus = HttpStatus.OK;

        return new ResponseEntity<>(workflowDeployResponse, httpStatus);
    }

}