package com.swissre.zeebeService.util;

import com.swissre.zeebeService.model.ResponseStatus;
import com.swissre.zeebeService.util.eva.EvaTicketHandler;
import com.swissre.zeebeService.util.eva.EvaTokenHandler;
import io.zeebe.client.api.command.ClientStatusException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.UnknownHostException;

@ControllerAdvice
public class CustomExceptionHandler {

    private static final Logger LOG = LogManager.getLogger(CustomExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handle(Exception ex,
                                         HttpServletRequest request, HttpServletResponse response) {
        ResponseStatus responseStatus = new ResponseStatus();
        LOG.debug("Type of exception in CustomExceptionHandler: " + ex.getClass().getName());
        if (ex instanceof HttpMessageNotReadableException || ex instanceof HttpMediaTypeException) {
            LOG.warn(ex.getMessage());
            responseStatus.setMessage(ex.getMessage());
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            return new ResponseEntity<>(responseStatus, HttpStatus.BAD_REQUEST);
        }
        if (ex instanceof NullPointerException) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } else if (ex instanceof ClientStatusException) {
            responseStatus.setMessage(((ClientStatusException) ex).getStatus().getDescription());
            responseStatus.setStatus(ResponseStatus.StatusEnum.FAILED);
            switch (((ClientStatusException) ex).getStatus().getCode()) {
                case INVALID_ARGUMENT:
                    return new ResponseEntity<>(responseStatus, HttpStatus.BAD_REQUEST);
                case PERMISSION_DENIED:
                    return new ResponseEntity<>(responseStatus, HttpStatus.FORBIDDEN);
                case NOT_FOUND:
                    return new ResponseEntity<>(responseStatus, HttpStatus.NOT_FOUND);
                case UNAVAILABLE:
                case DEADLINE_EXCEEDED:
                    evaReport();
                    responseStatus.setMessage("Incident reported to EVA " + ((ClientStatusException) ex).getStatus().getDescription());
                    responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                default:
                    responseStatus.setMessage(((ClientStatusException) ex).getStatus().getDescription());
                    responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        } else if (ex instanceof UnknownHostException) {
            evaReport();
            responseStatus.setMessage("Incident reported to EVA " + ex.getMessage());
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            return new ResponseEntity<>(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR);
        } else if (ex instanceof MethodArgumentNotValidException) {
            responseStatus.setMessage(((MethodArgumentNotValidException) ex).getMessage());
            responseStatus.setStatus(ResponseStatus.StatusEnum.FAILED);
            return new ResponseEntity<>(responseStatus, HttpStatus.BAD_REQUEST);
        }
        responseStatus.setMessage("Unexpected error happened: " + ex.getMessage());
        responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    private void evaReport() {
        EvaTokenHandler tokenHandler = new EvaTokenHandler();
        EvaTicketHandler ticketHandler = new EvaTicketHandler();
        try {

            int evaTicketStatusCode = ticketHandler.createEvaTicket(
                    EnvironmentEnum.ENV_ENUM.valueOf(System.getenv("ENVIRONMENT")), "zbControlError",
                    tokenHandler.getAccessToken(EnvironmentEnum.ENV_ENUM.valueOf(System.getenv("ENVIRONMENT"))));
            LOG.info("Status code of Eva ticket creation: " + evaTicketStatusCode);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}