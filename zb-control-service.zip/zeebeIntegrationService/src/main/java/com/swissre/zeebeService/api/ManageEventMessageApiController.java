package com.swissre.zeebeService.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.zeebeService.grpc.ZeebeBrokerClient;
import com.swissre.zeebeService.model.PublishMessage;
import com.swissre.zeebeService.model.ResponseStatus;
import com.swissre.zeebeService.model.WorkflowInstance;
import io.grpc.StatusRuntimeException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import io.zeebe.gateway.protocol.GatewayOuterClass;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Objects;

import static com.swissre.zeebeService.util.JsonValidator.validateJson;
import static com.swissre.zeebeService.util.ResponseEntityHandler.getResponseEntityFromStatusCode;

@Configuration
@PropertySource("classpath:application.properties")
@RestController
@Api(value = "Event Message", description = "the Event Message API", tags = {"Event Message",})
public class ManageEventMessageApiController implements MessageEventApi {

    private static final Logger LOG = LogManager.getLogger(ManageEventMessageApiController.class);
    private final ObjectMapper objectMapper;
    private final HttpServletRequest request;
    private final ZeebeBrokerClient zeebeBrokerClient;
    private static final int LATEST_VERSION = -1;

    @Value("${zeebeBroker.host}")
    private String hostName;

    @Value("${zeebeBroker.port}")
    private String portNumber;

    @Value("${zeebeBroker.grpc.retries}")
    private String maxGrpcRetries;

    @org.springframework.beans.factory.annotation.Autowired
    private Environment env;

    @org.springframework.beans.factory.annotation.Autowired
    public ManageEventMessageApiController(Environment env, ObjectMapper objectMapper, HttpServletRequest request) {
        this.env = env;
        this.objectMapper = objectMapper;
        this.request = request;
        zeebeBrokerClient = new ZeebeBrokerClient(env.getProperty("zeebeBroker.host"),
                Integer.parseInt(Objects.requireNonNull(env.getProperty("zeebeBroker.port"))),
                Integer.parseInt(Objects.requireNonNull(env.getProperty("zeebeBroker.timeoutSecs"))));
    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<ResponseStatus> publishMessage(@ApiParam(value = "Publish Message", required = true) @Valid @RequestBody PublishMessage publishMessage) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            httpStatus = HttpStatus.NOT_ACCEPTABLE;
            return new ResponseEntity<>(responseStatus, httpStatus);
        }
        LOG.info("Publishing message: {}", publishMessage.getMessageName());

        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<ResponseStatus> response = new ResponseEntity<>(new ResponseStatus(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            LOG.debug("Publishing message for the {} th time.", grpcRetries);
            response = publishingMessage(zeebeBrokerClient, request.getHeader("Authorization"), publishMessage);
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                grpcRetries++;
            else
                retrying = false;
        }

        return response;
    }

    //WorkflowStatus Controller
    public ResponseEntity<WorkflowInstance> workflowStatus(String workflowId, String version) {
        String accept = request.getHeader(HttpHeaders.ACCEPT);
        LOG.info("accept: " + accept);
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }

    private ResponseEntity<ResponseStatus> publishingMessage(ZeebeBrokerClient client, String authHash, PublishMessage publishMessage) {
        HttpStatus httpStatus;
        ResponseStatus response = new ResponseStatus();

        try {
            if (publishMessage.getVariables() != null)
                validateJson(publishMessage.getVariables());
            client.publishMessage(
                    GatewayOuterClass.PublishMessageRequest.newBuilder()
                            .setCorrelationKey(publishMessage.getCorrelationKey())
                            .setName(publishMessage.getMessageName())
                            .setVariables(publishMessage.getVariables() == null ? "" : publishMessage.getVariables())
                            .build()
                    , authHash
            );
            response.setStatus(ResponseStatus.StatusEnum.SUCCESS);
            response.setMessage("Publish message has been completed.");

            httpStatus = HttpStatus.OK;

        } catch (StatusRuntimeException e) {
            return getResponseEntityFromStatusCode(e);
        } catch (JsonProcessingException e) {
            response.setStatus(ResponseStatus.StatusEnum.ERROR);
            response.setMessage("Malformed json. \n " + e.getMessage());
            httpStatus = HttpStatus.BAD_REQUEST;
            e.printStackTrace();
        }
        LOG.debug("Message is published: {}", publishMessage.getMessageName());

        return new ResponseEntity<>(response, httpStatus);
    }

}