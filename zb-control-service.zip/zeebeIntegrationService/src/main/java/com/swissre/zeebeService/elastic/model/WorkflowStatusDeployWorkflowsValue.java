package com.swissre.zeebeService.elastic.model;

import com.google.gson.annotations.SerializedName;

public class WorkflowStatusDeployWorkflowsValue {

    @SerializedName("bpmnProcessId")
    private String bpmnProcessId = null;

    @SerializedName("resourceName")
    private String resourceName = null;

    @SerializedName("version")
    private Integer version;

    @SerializedName("workflowKey")
    private long workflowKey;

    public String getBpmnProcessId() {
        return bpmnProcessId;
    }

    public void setBpmnProcessId(String bpmnProcessId) {
        this.bpmnProcessId = bpmnProcessId;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public long getWorkflowKey() {
        return workflowKey;
    }

    public void setWorkflowKey(Integer workflowKey) {
        this.workflowKey = workflowKey;
    }
}
