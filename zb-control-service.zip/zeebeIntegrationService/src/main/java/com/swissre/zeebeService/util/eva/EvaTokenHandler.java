package com.swissre.zeebeService.util.eva;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.zeebeService.util.CustomProxySelector;
import com.swissre.zeebeService.util.EnvironmentEnum;
import com.swissre.zeebeService.util.FormUrlencodedHelper;
import com.swissre.zeebeService.util.eva.rest.GetTokenResponse;

import java.io.IOException;
import java.net.ProxySelector;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;

public class EvaTokenHandler {
    public String getAccessToken(EnvironmentEnum.ENV_ENUM env_enum) throws IOException, InterruptedException {
        ProxySelector.setDefault(new CustomProxySelector("gate-zrh.swissre.com", "8080"));

        HashMap<String, String> tokenRequestParams = new HashMap<>();
        tokenRequestParams.put("grant_type", "client_credentials");
        tokenRequestParams.put("client_id", System.getenv("EVAClientId"));
        tokenRequestParams.put("resource", System.getenv("EVAClientScope"));
        tokenRequestParams.put("client_secret", System.getenv("EVAClientSecret"));

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest tokenRequest = HttpRequest.newBuilder()
                .uri(URI.create(System.getenv("EVATokenUri")))
                .POST(HttpRequest.BodyPublishers.ofString(FormUrlencodedHelper.hashMap2FormUrlencoded(tokenRequestParams)))
                .headers("Content-Type", "application/x-www-form-urlencoded")
                .build();

        HttpResponse<String> tokenRequestResponse = client.send(tokenRequest,
                HttpResponse.BodyHandlers.ofString());

        ObjectMapper mapper = new ObjectMapper();
        GetTokenResponse tokenResponse = mapper.readValue(tokenRequestResponse.body(), GetTokenResponse.class);

        return tokenResponse.getAccess_token();
    }
}