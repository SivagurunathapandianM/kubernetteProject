package com.swissre.zeebeService.elastic.model;

import com.google.gson.annotations.SerializedName;

public class WorkflowInstanceByWorkflowIdValue {
    @SerializedName("bpmnProcessId")
    private String bpmnProcessId;
    @SerializedName("workflowKey")
    private long workflowKey;
    @SerializedName("flowScopeKey")
    private long flowScopeKey;
    @SerializedName("bpmnElementType")
    private String bpmnElementType;
    @SerializedName("elementId")
    private String elementId;
    @SerializedName("version")
    private Integer version;
    @SerializedName("workflowInstanceKey")
    private long workflowInstanceKey;

    public String getBpmnProcessId() {
        return bpmnProcessId;
    }

    public void setBpmnProcessId(String bpmnProcessId) {
        this.bpmnProcessId = bpmnProcessId;
    }

    public long getWorkflowKey() {
        return workflowKey;
    }

    public void setWorkflowKey(long workflowKey) {
        this.workflowKey = workflowKey;
    }

    public long getFlowScopeKey() {
        return flowScopeKey;
    }

    public void setFlowScopeKey(long flowScopeKey) {
        this.flowScopeKey = flowScopeKey;
    }

    public String getBpmnElementType() {
        return bpmnElementType;
    }

    public void setBpmnElementType(String bpmnElementType) {
        this.bpmnElementType = bpmnElementType;
    }

    public String getElementId() {
        return elementId;
    }

    public void setElementId(String elementId) {
        this.elementId = elementId;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public long getWorkflowInstanceKey() {
        return workflowInstanceKey;
    }

    public void setWorkflowInstanceKey(long workflowInstanceKey) {
        this.workflowInstanceKey = workflowInstanceKey;
    }
}
