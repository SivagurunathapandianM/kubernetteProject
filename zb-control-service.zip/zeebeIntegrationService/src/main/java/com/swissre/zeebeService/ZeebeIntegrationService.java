package com.swissre.zeebeService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import springfox.documentation.oas.annotations.EnableOpenApi;
import org.springframework.retry.annotation.EnableRetry;

import java.util.Arrays;

@EnableRetry
@SpringBootApplication
@EnableOpenApi
@ComponentScan(basePackages = {"com.swissre.zeebeService", "com.swissre.zeebeService.api", "com.swissre.zeebeService.configuration"})
public class ZeebeIntegrationService implements CommandLineRunner {
    private static final Logger LOG = LogManager.getLogger(ZeebeIntegrationService.class);

    @Override
    public void run(String... arg0) {
        LOG.info("Arguments" + Arrays.hashCode(arg0));
        if (arg0.length > 0 && arg0[0].equals("exitcode")) {
            throw new ExitException();
        }
    }

    public static void main(String[] args) {
        LOG.info("Going to start zeebeIntegrationService");
        new SpringApplication(ZeebeIntegrationService.class).run(args);
    }

    class ExitException extends RuntimeException implements ExitCodeGenerator {
        private static final long serialVersionUID = 1L;

        @Override
        public int getExitCode() {
            return 10;
        }
    }
}