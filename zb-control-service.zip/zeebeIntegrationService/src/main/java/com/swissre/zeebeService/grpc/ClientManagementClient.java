package com.swissre.zeebeService.grpc;

import com.swissre.bpm.grpc.customgateway.ClientCredentialsMessage;
import com.swissre.bpm.grpc.customgateway.ClientId;
import com.swissre.bpm.grpc.customgateway.ClientManagementServiceGrpc;
import com.swissre.bpm.grpc.customgateway.Status;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Metadata;
import io.grpc.stub.MetadataUtils;

public class ClientManagementClient {
    ManagedChannel channel;

    public ClientManagementClient(String authHost, int authPort) {
        channel = ManagedChannelBuilder
                .forAddress(authHost, authPort)
                .usePlaintext()
                .build();
    }

    private ClientManagementServiceGrpc.ClientManagementServiceBlockingStub createStub(String authHash) {
        Metadata header = new Metadata();
        final Metadata.Key<String> AUTHORIZATION_METADATA_KEY =
                Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER);
        header.put(AUTHORIZATION_METADATA_KEY, authHash);

        ClientManagementServiceGrpc.ClientManagementServiceBlockingStub stub = ClientManagementServiceGrpc
                .newBlockingStub(channel);
        stub = MetadataUtils.attachHeaders(stub, header);

        return stub;
    }

    public Status registerClient(String authHash, ClientCredentialsMessage request) {
        return createStub(authHash).registerClient(request);
    }

    public Status changeClientPassword(String authHash, ClientCredentialsMessage request) {
        return createStub(authHash).changePassword(request);
    }

    public Status removeClient(String authHash, ClientId request) {
        return createStub(authHash).removeClient(request);
    }
}
