package com.swissre.zeebeService.util;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class CustomProxySelector extends ProxySelector {
    private static final Logger LOG = LogManager.getLogger(CustomProxySelector.class);

    private final ProxySelector def;

    private Proxy proxy;

    private List<Proxy> proxyList = new ArrayList<Proxy>();

    /*
     * We want to hang onto the default and delegate
     * everything to it unless it's one of the url's
     * we need proxied.
     */
    public CustomProxySelector(String proxyHost, String proxyPort) {
        this.def = ProxySelector.getDefault();
        proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, (null == proxyPort) ? 80 : Integer.valueOf(proxyPort)));
        proxyList.add(proxy);
        ProxySelector.setDefault(this);
    }

    @Override
    public List<Proxy> select(URI uri) {
        LOG.trace("Trying to reach URL : " + uri);
        if (uri == null) {
            throw new IllegalArgumentException("URI can't be null.");
        }
        if (uri.getHost().contains("it-gtm")) {
            LOG.info("We're trying to reach it-gtm eva portal so we're going to use the proxy.");
            return proxyList;
        } else if (uri.getHost().contains("login.microsoftonline.com")) {
            LOG.info("We're trying to reach login.microsoftonline.com so we're going to use the proxy.");
            return proxyList;
        }
        return def.select(uri);
    }

    /*
     * Method called by the handlers when it failed to connect
     * to one of the proxies returned by select().
     */
    @Override
    public void connectFailed(URI uri, SocketAddress sa, IOException ioe) {
        LOG.info("Failed to connect to a proxy when connecting to " + uri.getHost());
        if (uri == null || sa == null || ioe == null) {
            throw new IllegalArgumentException("Arguments can't be null.");
        }
        def.connectFailed(uri, sa, ioe);
    }
}