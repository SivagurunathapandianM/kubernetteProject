package com.swissre.zeebeService.grpc;

import io.grpc.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Base64;

public class MetadataInjector implements ClientInterceptor {

    private static final Logger LOG = LogManager.getLogger(MetadataInjector.class);

    private static final Metadata.Key<String> AUTHORIZATION_METADATA_KEY =
            Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER);

    @Override
    public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(MethodDescriptor<ReqT, RespT> method,
                                                               CallOptions callOptions, Channel next) {
        return new ForwardingClientCall.SimpleForwardingClientCall<>(next.newCall(method, callOptions)) {

            @Override
            public void start(Listener<RespT> responseListener, Metadata headers) {
                /* put custom header */
                String authHeader = ZeebeBrokerClient.authHeaderContextKey.get();
                LOG.trace("Injecting header ***** into grpc call");
                headers.put(AUTHORIZATION_METADATA_KEY, authHeader);
                super.start(responseListener, headers);
            }


        };
    }

}