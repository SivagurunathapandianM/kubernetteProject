package com.swissre.zeebeService.elastic.model;

import com.google.gson.annotations.SerializedName;

public class DeployedWorkflow {
    @SerializedName("resourceName")
    private String resourceName;
    @SerializedName("bpmnProcessId")
    private String bpmnProcessId;
    @SerializedName("workflowKey")
    private long workflowKey;
    @SerializedName("version")
    private Integer version;

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public String getBpmnProcessId() {
        return bpmnProcessId;
    }

    public void setBpmnProcessId(String bpmnProcessId) {
        this.bpmnProcessId = bpmnProcessId;
    }

    public long getWorkflowKey() {
        return workflowKey;
    }

    public void setWorkflowKey(long workflowKey) {
        this.workflowKey = workflowKey;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}
