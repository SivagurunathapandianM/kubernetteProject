package com.swissre.zeebeService.util;

import com.swissre.bpm.grpc.customgateway.Status;
import com.swissre.zeebeService.model.ResponseStatus;
import io.grpc.StatusRuntimeException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ResponseEntityHandler {

    public static ResponseEntity<ResponseStatus> getResponseEntityFromStatus(Status status) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();

        switch (status.getStatusCode()) {
            case FAILURE:
                responseStatus.setStatus(ResponseStatus.StatusEnum.FAILED);
                responseStatus.setMessage(status.getDescription());
                httpStatus = HttpStatus.BAD_REQUEST;
                break;
            case INTERNAL_ERROR:
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage(status.getDescription());
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
                break;
            case NOT_FOUND:
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage(status.getDescription());
                httpStatus = HttpStatus.NOT_FOUND;
                break;
            case UNAUTHORIZED:
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage(status.getDescription());
                httpStatus = HttpStatus.UNAUTHORIZED;
                break;
            case SUCCESS:
                responseStatus.setStatus(ResponseStatus.StatusEnum.SUCCESS);
                responseStatus.setMessage(status.getDescription());
                httpStatus = HttpStatus.OK;
                break;
            default:
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage("Unknown error happened.");
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
                break;
        }
        return new ResponseEntity<>(responseStatus, httpStatus);
    }

    public static ResponseEntity<ResponseStatus> getResponseEntityFromStatusCode(StatusRuntimeException e) {
        HttpStatus httpStatus;
        ResponseStatus responseStatus = new ResponseStatus();

        switch (e.getStatus().getCode()) {
            case NOT_FOUND:
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage("Correlation key not found.");
                httpStatus = HttpStatus.NOT_FOUND;
                break;
            case UNAUTHENTICATED:
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage("Unauthenticated.");
                httpStatus = HttpStatus.UNAUTHORIZED;
                break;
            case INVALID_ARGUMENT:
                responseStatus.setStatus(ResponseStatus.StatusEnum.FAILED);
                responseStatus.setMessage(e.getStatus().getDescription());
                httpStatus = HttpStatus.BAD_REQUEST;
                break;
            case PERMISSION_DENIED:
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage(e.getStatus().getDescription());
                httpStatus = HttpStatus.FORBIDDEN;
                break;
            default:
                responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
                responseStatus.setMessage("Unknown error happened. \n StatusCode: " + e.getStatus().getCode()
                        + "\nMessage: " + e.getStatus().getDescription());
                httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
                break;
        }
        return new ResponseEntity<>(responseStatus, httpStatus);
    }
}
