package com.swissre.zeebeService.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonValidator {

    public static void validateJson(String jsonInString) throws JsonProcessingException {
        final ObjectMapper mapper = new ObjectMapper();
        mapper.readTree(jsonInString);
    }
}
