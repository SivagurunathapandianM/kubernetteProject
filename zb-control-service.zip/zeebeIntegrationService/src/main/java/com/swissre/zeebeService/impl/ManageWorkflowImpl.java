package com.swissre.zeebeService.impl;

import com.google.gson.Gson;
import com.swissre.zeebeService.elastic.model.WorkflowSource;
import com.swissre.zeebeService.grpc.ZeebeBrokerClient;
import com.swissre.zeebeService.model.*;
import io.zeebe.client.api.response.WorkflowInstanceEvent;
import org.apache.http.HttpHost;
import org.apache.logging.log4j.LogManager;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.apache.logging.log4j.Logger;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class ManageWorkflowImpl {

    private static final Logger LOG = LogManager.getLogger(ManageWorkflowImpl.class);
    private static Properties appProps;

    private ZeebeBrokerClient zeebeBrokerClient;

    public ManageWorkflowImpl(ZeebeBrokerClient zeebeBrokerClient) {
        this.zeebeBrokerClient = zeebeBrokerClient;
    }

    public ManageWorkflowImpl() {}


    private static Properties loadProperties() throws IOException {
        Properties appProps = new Properties();
        appProps.load(Objects.requireNonNull(ManageWorkflowInstanceImpl.class.getClassLoader().getResourceAsStream("application.properties")));
        return appProps;
    }

    //Delete Workflow Implementation
    public WorkflowInstanceEvent deleteWorkflowImpl(String workflowId, String version) {
        return null;
    }

    //List of workflows implementation
    public ListWorkflowsResponse listOfWorflows(String resourceName, String bpmnProcessId, String workflowKey, Integer version) throws IOException {
        ListWorkflowsResponse response = new ListWorkflowsResponse();

        appProps = loadProperties();
        RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost(appProps.getProperty("elasticSearch.host"), Integer.parseInt(appProps.getProperty("elasticSearch.port")), "https")));
        SearchRequest searchRequest = new SearchRequest("zeebe-record-deployment_*");
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder query = QueryBuilders.boolQuery();
        if (resourceName != null && !resourceName.isEmpty())
            query.filter(QueryBuilders.termQuery("value.deployedWorkflows.resourceName", resourceName));
        if (bpmnProcessId != null && !bpmnProcessId.isEmpty())
            query.filter(QueryBuilders.termQuery("value.deployedWorkflows.bpmnProcessId", bpmnProcessId));
        if (workflowKey != null && !workflowKey.isEmpty())
            query.filter(QueryBuilders.termQuery("value.deployedWorkflows.workflowKey", Long.parseLong(workflowKey)));
        if (version != null)
            query.filter(QueryBuilders.termQuery("value.deployedWorkflows.version", version));
        sourceBuilder.query(query);
        sourceBuilder.timeout(new TimeValue(60, TimeUnit.SECONDS));
        searchRequest.source(sourceBuilder);
        SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

        List<Workflow> workflows = new ArrayList<>();
        if (searchResponse.getHits().totalHits != 0) {
            for (SearchHit hit : searchResponse.getHits()) {
                WorkflowSource hitSource = new Gson().fromJson(hit.getSourceAsString(), WorkflowSource.class);
                for (int i = 0; i < hitSource.getValue().getDeployedWorkflows().size(); i++) {
                    Workflow workflow = new Workflow();
                    workflow.setBpmnProcessId(hitSource.getValue().getDeployedWorkflows().get(i).getBpmnProcessId());
                    workflow.setVersion(hitSource.getValue().getDeployedWorkflows().get(i).getVersion());
                    workflow.setResourceName(hitSource.getValue().getDeployedWorkflows().get(i).getResourceName());
                    workflow.setWorkflowKey(hitSource.getValue().getDeployedWorkflows().get(i).getWorkflowKey());
                    workflows.add(workflow);
                }
            }
        }
        client.close();
        LOG.info("Retrieved " + workflows.size() + " workflows for listOfWorflows.");
        response.setListWorkflows(workflows);
        ResponseStatus responseStatus = new ResponseStatus();
        responseStatus.status(ResponseStatus.StatusEnum.SUCCESS);
        responseStatus.message("Retrieved " + workflows.size() + " workflows for listOfWorflows.");
        response.setResponseStatus(responseStatus);
        return response;
    }

    //Workflow status implementation
    public WorkflowInstanceEvent workflowStatusController(String workflowId, String version) {
        return null;
    }
}


