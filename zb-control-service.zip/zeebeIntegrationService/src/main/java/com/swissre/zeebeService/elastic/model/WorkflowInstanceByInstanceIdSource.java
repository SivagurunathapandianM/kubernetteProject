package com.swissre.zeebeService.elastic.model;

import com.google.gson.annotations.SerializedName;

public class WorkflowInstanceByInstanceIdSource {
    @SerializedName("key")
    private long key;
    @SerializedName("position")
    private long position;
    @SerializedName("timestamp")
    private long timestamp;
    @SerializedName("recordType")
    private String recordType;
    @SerializedName("intent")
    private String intent;
    @SerializedName("partitionId")
    private Integer partitionId;
    @SerializedName("valueType")
    private String valueType;
    @SerializedName("rejectionType")
    private String rejectionType;
    @SerializedName("rejectionReason")
    private String rejectionReason;
    @SerializedName("sourceRecordPosition")
    private long sourceRecordPosition;
    @SerializedName("value")
    private WorkflowInstanceByInstanceIdValue value;

    public long getKey() {
        return key;
    }

    public void setKey(long key) {
        this.key = key;
    }

    public long getPosition() {
        return position;
    }

    public void setPosition(long position) {
        this.position = position;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public Integer getPartitionId() {
        return partitionId;
    }

    public void setPartitionId(Integer partitionId) {
        this.partitionId = partitionId;
    }

    public String getValueType() {
        return valueType;
    }

    public void setValueType(String valueType) {
        this.valueType = valueType;
    }

    public String getRejectionType() {
        return rejectionType;
    }

    public void setRejectionType(String rejectionType) {
        this.rejectionType = rejectionType;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    public long getSourceRecordPosition() {
        return sourceRecordPosition;
    }

    public void setSourceRecordPosition(long sourceRecordPosition) {
        this.sourceRecordPosition = sourceRecordPosition;
    }

    public WorkflowInstanceByInstanceIdValue getValue() {
        return value;
    }

    public void setValue(WorkflowInstanceByInstanceIdValue value) {
        this.value = value;
    }
}
