package com.swissre.zeebeService;

import com.fasterxml.jackson.databind.util.StdDateFormat;

import java.text.FieldPosition;
import java.util.Date;


public class RFC3339DateFormat extends StdDateFormat {

    private static final long serialVersionUID = 1L;

    // Same as ISO8601DateFormat but serializing milliseconds.
    @Override
    public StringBuffer format(Date date, StringBuffer toAppendTo, FieldPosition fieldPosition) {
        StdDateFormat dateFormat = new StdDateFormat();
        toAppendTo.append(dateFormat.format(date));
        return toAppendTo;
    }
}