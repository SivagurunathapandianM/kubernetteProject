package com.swissre.zeebeService.elastic.model;

import com.google.gson.annotations.SerializedName;

public class WorkflowStatusResourcesValue {

    @SerializedName("resourceType")
    private String resourceType = null;

    @SerializedName("resource")
    private String resource = null;

    @SerializedName("resourceName")
    private String resourceName = null;

    public String getResourceType() {
        return resourceType;
    }

    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }
}
