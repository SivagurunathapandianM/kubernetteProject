package com.swissre.zeebeService.grpc;
import io.grpc.Context;
import io.grpc.ManagedChannelBuilder;
import io.zeebe.gateway.protocol.GatewayGrpc;
import io.zeebe.gateway.protocol.GatewayOuterClass;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.TimeUnit;

public class ZeebeBrokerClient {
    private static final Logger LOG = LogManager.getLogger(ZeebeBrokerClient.class);

    private final GatewayGrpc.GatewayBlockingStub stubTowardsBroker;
    private final int grpcDeadline;
    static final String AUTH_HEADER_CONTEXT_KEY_STRING = "AUTH_HEADER_CONTEXT_KEY";
    public static final Context.Key<String> authHeaderContextKey = Context.key(AUTH_HEADER_CONTEXT_KEY_STRING);

    public ZeebeBrokerClient(String brokerHost, int brokerPort, int grpcDeadline) {
        LOG.info("Created ZeebeBrokerClient towards address: {}:{}", brokerHost,brokerPort);
        this.grpcDeadline = grpcDeadline;
        stubTowardsBroker = GatewayGrpc.newBlockingStub(ManagedChannelBuilder
                .forAddress(brokerHost,brokerPort)
                .usePlaintext()
                .build())
                .withInterceptors(new MetadataInjector());
    }

    public GatewayOuterClass.CancelWorkflowInstanceResponse cancelWorkflowInstance(GatewayOuterClass.CancelWorkflowInstanceRequest request, String authHeader) {
        final Context contextWithCredentials = Context.current().withValue(authHeaderContextKey, authHeader);
        final Context previousContext = contextWithCredentials.attach();
        try {
            return stubTowardsBroker.withDeadlineAfter(grpcDeadline, TimeUnit.SECONDS).cancelWorkflowInstance(request);
        } finally {
            contextWithCredentials.detach(previousContext);
        }

    }

    public GatewayOuterClass.CreateWorkflowInstanceResponse createWorkflowInstance(GatewayOuterClass.CreateWorkflowInstanceRequest request, String authHeader) {

        final Context contextWithCredentials = Context.current().withValue(authHeaderContextKey, authHeader);
        final Context previousContext = contextWithCredentials.attach();
        try {
            return stubTowardsBroker.withDeadlineAfter(grpcDeadline, TimeUnit.SECONDS).createWorkflowInstance(request);
        } finally {
            contextWithCredentials.detach(previousContext);
        }
    }

    public GatewayOuterClass.DeployWorkflowResponse deployWorkflow(GatewayOuterClass.DeployWorkflowRequest request, String authHeader) {

        final Context contextWithCredentials = Context.current().withValue(authHeaderContextKey, authHeader);
        final Context previousContext = contextWithCredentials.attach();
        try {
            return stubTowardsBroker.withDeadlineAfter(grpcDeadline, TimeUnit.SECONDS).deployWorkflow(request);
        } finally {
            contextWithCredentials.detach(previousContext);
        }
    }

    public GatewayOuterClass.PublishMessageResponse publishMessage(GatewayOuterClass.PublishMessageRequest request, String authHeader) {

        final Context contextWithCredentials = Context.current().withValue(authHeaderContextKey, authHeader);
        final Context previousContext = contextWithCredentials.attach();
        try {
            return stubTowardsBroker.withDeadlineAfter(grpcDeadline, TimeUnit.SECONDS).publishMessage(request);
        } finally {
            contextWithCredentials.detach(previousContext);
        }
    }

    public GatewayOuterClass.SetVariablesResponse setVariables(GatewayOuterClass.SetVariablesRequest request, String authHeader) {
        final Context contextWithCredentials = Context.current().withValue(authHeaderContextKey, authHeader);
        final Context previousContext = contextWithCredentials.attach();
        try {
            return stubTowardsBroker.withDeadlineAfter(grpcDeadline, TimeUnit.SECONDS).setVariables(request);
        } finally {
            contextWithCredentials.detach(previousContext);
        }
    }
}
