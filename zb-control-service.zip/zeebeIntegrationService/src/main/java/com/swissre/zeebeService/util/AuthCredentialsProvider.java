package com.swissre.zeebeService.util;

import io.grpc.Metadata;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.zeebe.client.CredentialsProvider;

public class AuthCredentialsProvider implements CredentialsProvider {
    String authCredentials;

    public AuthCredentialsProvider(String authCredentials) {
        this.authCredentials = authCredentials;
    }

    @Override
    public void applyCredentials(final Metadata headers) {
        final Metadata.Key<String> authHeaderkey = Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER);
        headers.put(authHeaderkey, authCredentials);
    }

    @Override
    public boolean shouldRetryRequest(final Throwable throwable) {
        return ((StatusRuntimeException) throwable).getStatus() == Status.DEADLINE_EXCEEDED;
    }
}
