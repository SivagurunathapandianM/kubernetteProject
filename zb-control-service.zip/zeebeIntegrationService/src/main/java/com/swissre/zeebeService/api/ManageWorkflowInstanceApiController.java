package com.swissre.zeebeService.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.zeebeService.grpc.ShowWorkflowClient;
import com.swissre.zeebeService.grpc.ZeebeBrokerClient;
import com.swissre.zeebeService.model.*;
import io.grpc.StatusRuntimeException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import io.zeebe.gateway.protocol.GatewayOuterClass;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Objects;

import static com.swissre.zeebeService.util.ResponseEntityHandler.getResponseEntityFromStatusCode;

@Configuration
@PropertySource("classpath:application.properties")
@Controller
@Api(value = "WorkflowInstances", description = "the WorkflowInstances API", tags = {"Workflow Instances",})
public class ManageWorkflowInstanceApiController implements WorkflowInstancesApi {

    private static final Logger LOG = LogManager.getLogger(ManageWorkflowInstanceApiController.class);
    private final ObjectMapper objectMapper;
    private final HttpServletRequest request;
    private final ZeebeBrokerClient zeebeBrokerClient;
    private final ShowWorkflowClient showWorkflowClient;
    private static final int LATEST_VERSION = -1; //@see https://github.com/zeebe-io/zeebe/blob/develop/gateway-protocol/src/main/proto/gateway.proto#L93

    @Value("${zeebeBroker.host}")
    private String hostName;

    @Value("${zeebeBroker.port}")
    private String portNumber;

    @Value("${zeebeBroker.grpc.retries}")
    private String maxGrpcRetries;

    @org.springframework.beans.factory.annotation.Autowired
    public ManageWorkflowInstanceApiController(Environment env, ObjectMapper objectMapper, HttpServletRequest request) {
        this.env = env;
        this.objectMapper = objectMapper;
        this.request = request;
        zeebeBrokerClient = new ZeebeBrokerClient(env.getProperty("zeebeBroker.host"),
                Integer.parseInt(Objects.requireNonNull(env.getProperty("zeebeBroker.port"))),
                Integer.parseInt(Objects.requireNonNull(env.getProperty("zeebeBroker.timeoutSecs"))));
        showWorkflowClient = new ShowWorkflowClient(
                env.getProperty("showWorkflow.host"),
                Integer.parseInt(Objects.requireNonNull(env.getProperty("showWorkflow.port")))
        );
    }

    @org.springframework.beans.factory.annotation.Autowired
    private Environment env;

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<CancelWorkflowInstanceResponse> cancelWorkflowInstance(@ApiParam(value = "Instance Id to delete the instance", required = true) @PathVariable("instanceId") Long instanceId) {
        CancelWorkflowInstanceResponse cancelWorkflowInstanceResponse = new CancelWorkflowInstanceResponse();
        ResponseStatus responseStatus = new ResponseStatus();

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            cancelWorkflowInstanceResponse.setResponseStatus(responseStatus);
            return new ResponseEntity<>(cancelWorkflowInstanceResponse, HttpStatus.NOT_ACCEPTABLE);
        }

        LOG.info("Cancelling instance with id: {}", instanceId);
        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<CancelWorkflowInstanceResponse> response = new ResponseEntity<>(new CancelWorkflowInstanceResponse(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            LOG.debug("Cancelling instance for the {} th time.", grpcRetries);
            response = cancelingWorkflowInstance(zeebeBrokerClient, request.getHeader("Authorization"), instanceId);
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                grpcRetries++;
            else
                retrying = false;
        }

        return response;
    }

//    @Override
//    public ResponseEntity<CancelAllWorkflowInstancesResponse> cancelAllWorkflowInstances(@ApiParam(value = "Workflow id to delete the instances", required = true) @PathVariable("workflowId") String workflowId,
//                                                                                         @ApiParam(value = "version of Workflow", required = true) @RequestParam(value = "version") Integer version) {
//        CancelAllWorkflowInstancesResponse response = new CancelAllWorkflowInstancesResponse();
//        ResponseStatus responseStatus = new ResponseStatus();
//        HttpStatus httpStatus;
//
//        if (request.getHeader("Authorization") == null) {
//            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
//            responseStatus.setMessage("Basic Auth required.");
//            response.setResponseStatus(responseStatus);
//            return new ResponseEntity<>(response, HttpStatus.NOT_ACCEPTABLE);
//        }
//
//        String accept = request.getHeader(HttpHeaders.ACCEPT);
//        LOG.info("accept: " + accept);
//
//        ManageWorkflowInstanceImpl manageWorkflowInstance = new ManageWorkflowInstanceImpl();
//        try {
//            response = manageWorkflowInstance.cancelAllWorkflowInstances(request.getHeader("Authorization"), workflowId, version, hostName, portNumber);
//            httpStatus = HttpStatus.OK;
//        } catch (IOException e) {
//            e.printStackTrace();
//            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
//        }
//        return new ResponseEntity<>(response, httpStatus);
//    }

//    @Override
//    public ResponseEntity<WorkflowInstancesResponse> getWorkflowInstancesByWorkflowId(@ApiParam(value = "Workflow Id to retrieve workflow status", required = true) @PathVariable("workflowId") String workflowId,
//                                                                                      @NotNull @ApiParam(value = "Get all the worklfow instances by status", required = true, allowableValues = "all, active, completed, cancelled") @Valid @RequestParam(value = "status", required = true) String status,
//                                                                                      @ApiParam(value = "from parameter for pagination") @Valid @RequestParam(value = "from", required = false) Integer from,
//                                                                                      @ApiParam(value = "size parameter for pagination") @Valid @RequestParam(value = "size", required = false) Integer size) {
//        String accept = request.getHeader(HttpHeaders.ACCEPT);
//        log.info("accept: " + accept);
//        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
//        ManageWorkflowInstanceImpl manageWorkflowInstance = new ManageWorkflowInstanceImpl();
//        WorkflowInstancesResponse response = null;
//        HttpStatus httpStatus;
//
//        try {
//            response = manageWorkflowInstance.getWorkflowInstancesByWorkflowId(workflowId, status, from == null ? 0 : from, size == null ? 20 : size);
//            httpStatus = HttpStatus.OK;
//        } catch (IOException e) {
//            e.printStackTrace();
//            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
//        }
//        return new ResponseEntity<>(response, httpStatus);
//    }

//    @Override
//    public ResponseEntity<WorkflowInstanceByIdResponse> getWorkflowInstancesById(@ApiParam(value = "Instance Id to retrieve instance status", required = true) @PathVariable("instanceId") String instanceId,
//                                                                                 @ApiParam(value = "from parameter for pagination") @Valid @RequestParam(value = "from", required = false) Integer from,
//                                                                                 @ApiParam(value = "size parameter for pagination") @Valid @RequestParam(value = "size", required = false) Integer size) {
//        String accept = request.getHeader(HttpHeaders.ACCEPT);
//        log.info("accept: " + accept);
//        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
//        ManageWorkflowInstanceImpl manageWorkflowInstance = new ManageWorkflowInstanceImpl();
//        WorkflowInstanceByIdResponse response = null;
//        HttpStatus httpStatus;
//
//        try {
//            response = manageWorkflowInstance.getWorkflowInstancesById(instanceId, from == null ? 0 : from, size == null ? 20 : size);
//            httpStatus = HttpStatus.OK;
//        } catch (IOException e) {
//            e.printStackTrace();
//            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
//        }
//        return new ResponseEntity<>(response, httpStatus);
//    }

//    @Override
//    public ResponseEntity<WorkflowStatusByProcessIdResponse> getWorkflowStatusByProcessId(@ApiParam(value = "Process Id to retrieve workflow status", required = true) @PathVariable("bpmnProcessId") String bpmnProcessId,
//                                                                                          @ApiParam(value = "from value for pagination") @Valid @RequestParam(value = "from", required = false) String from,
//                                                                                          @ApiParam(value = "size value for pagination") @Valid @RequestParam(value = "size", required = false) String size) {
//        String accept = request.getHeader(HttpHeaders.ACCEPT);
//        log.info("accept: " + accept);
//        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
//        ManageWorkflowInstanceImpl manageWorkflowInstance = new ManageWorkflowInstanceImpl();
//        WorkflowStatusByProcessIdResponse response = null;
//        HttpStatus httpStatus;
//
//        try {
//            response = manageWorkflowInstance.getWorkflowStatusByProcessId(bpmProcessId);
//            httpStatus = HttpStatus.OK;
//        } catch (IOException e) {
//            e.printStackTrace();
//            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
//        }
//        return new ResponseEntity<>(response, httpStatus);
//    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<WorkflowInstanceResponse> startWorkflowInstance(@ApiParam(value = "ID of workflow that needs to be started", required = true) @PathVariable("workflowId") String workflowId,
                                                                          @ApiParam(value = "Variables in JSON to update", required = true) @Valid @RequestBody Object payload) {
        JsonNode params = objectMapper.valueToTree(payload);
        WorkflowInstanceResponse workflowInstanceResponse = new WorkflowInstanceResponse();
        ResponseStatus responseStatus = new ResponseStatus();

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            workflowInstanceResponse.setResponseStatus(responseStatus);
            return new ResponseEntity<>(workflowInstanceResponse, HttpStatus.NOT_ACCEPTABLE);
        }

        LOG.info("Creating instance for {} with {} payload.", workflowId, payload);
        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<WorkflowInstanceResponse> response = new ResponseEntity<>(new WorkflowInstanceResponse(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            LOG.debug("Instance creation for the {} th time.", grpcRetries);
            response = startingWorkflowInstance(zeebeBrokerClient, request.getHeader("Authorization"), workflowId, params.toString());
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries)) {
                grpcRetries++;
            } else {
                retrying = false;
            }
        }
        return response;
    }

//    @Override
//    public ResponseEntity<WorkflowInstanceResponse> updateWorkflowInstance(@ApiParam(value = "Workflow Instance Id to update", required = true) @PathVariable("workflowId") Integer workflowId,
//                                                                           @ApiParam(value = "Variables in JSON to update", required = true) @Valid @RequestBody Object payload) {
//        JsonNode params = objectMapper.valueToTree(payload);
//
//        WorkflowInstanceResponse response = new WorkflowInstanceResponse();
//        ResponseStatus responseStatus = new ResponseStatus();
//        HttpStatus httpStatus;
//
//        if (request.getHeader("Authorization") == null) {
//            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
//            responseStatus.setMessage("Basic Auth required.");
//            response.setResponseStatus(responseStatus);
//            return new ResponseEntity<>(response, HttpStatus.NOT_ACCEPTABLE);
//        }
//
//        String accept = request.getHeader(HttpHeaders.ACCEPT);
//        LOG.info("accept: " + accept);
//
//        ManageWorkflowInstanceImpl manageWorkflowInstance = new ManageWorkflowInstanceImpl();
//
//        try {
//            response = manageWorkflowInstance.startWorkflowInstance(request.getHeader("Authorization"), workflowId.toString(), params, hostName, portNumber);
//            httpStatus = HttpStatus.OK;
//        } catch (IOException e) {
//            e.printStackTrace();
//            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
//        }
//        return new ResponseEntity<>(response, httpStatus);
//    }

    @Override
    @Retryable(value = { Exception.class }, backoff = @Backoff(delay = 1000))
    public ResponseEntity<ResponseStatus> updateElementInstance(@ApiParam(value = "Workflow Instance Id to update", required = true) @PathVariable("workflowId") Long elementInstanceId,
                                                                @ApiParam(value = "Variables in JSON to update", required = true) @Valid @RequestBody Object payload) {
        JsonNode params = objectMapper.valueToTree(payload);
        ResponseStatus responseStatus = new ResponseStatus();
        HttpStatus httpStatus;

        if (request.getHeader("Authorization") == null) {
            responseStatus.setStatus(ResponseStatus.StatusEnum.ERROR);
            responseStatus.setMessage("Basic Auth required.");
            return new ResponseEntity<>(responseStatus, HttpStatus.NOT_ACCEPTABLE);
        }

        int grpcRetries = 0;
        boolean retrying = true;
        ResponseEntity<ResponseStatus> response = new ResponseEntity<>(new ResponseStatus(), HttpStatus.NOT_ACCEPTABLE);
        while (retrying) {
            response = updatingWorkflowInstance(zeebeBrokerClient, request.getHeader("Authorization"), elementInstanceId, params.toString());
            if (!response.getStatusCode().equals(HttpStatus.OK) && !response.getStatusCode().equals(HttpStatus.CREATED) &&
                    !response.getStatusCode().equals(HttpStatus.UNAUTHORIZED) && grpcRetries < Integer.valueOf(maxGrpcRetries))
                grpcRetries++;
            else
                retrying = false;
        }

        return response;


    }

    private ResponseEntity<CancelWorkflowInstanceResponse> cancelingWorkflowInstance(ZeebeBrokerClient client, String authHash, Long instanceId) {
        CancelWorkflowInstanceResponse response = new CancelWorkflowInstanceResponse();
        ResponseStatus responseStatus = new ResponseStatus();
        HttpStatus httpStatus;

        try {
            GatewayOuterClass.CancelWorkflowInstanceResponse responseFromZeebe = zeebeBrokerClient.cancelWorkflowInstance(
                    GatewayOuterClass.CancelWorkflowInstanceRequest.newBuilder()
                            .setWorkflowInstanceKey(instanceId)
                            .build()
                    , authHash);

            responseStatus.setMessage("Instance successfully canceled!");
            responseStatus.setStatus(ResponseStatus.StatusEnum.SUCCESS);

            RemoveObjectResponse removeObject = new RemoveObjectResponse();
            removeObject.setStatus(RemoveObjectResponse.StatusEnum.SUCCESS);
            removeObject.setInstanceId(instanceId);
            response.setCancelWorkflowInstance(removeObject);

            httpStatus = HttpStatus.OK;
            LOG.debug("Instance is cancelled: {}", removeObject.toString());

        } catch (StatusRuntimeException e) {
            ResponseEntity<ResponseStatus> responseEntity = getResponseEntityFromStatusCode(e);
            responseStatus = responseEntity.getBody();
            httpStatus = responseEntity.getStatusCode();
        }
        response.setResponseStatus(responseStatus);
        return new ResponseEntity<>(response, httpStatus);
    }

    private ResponseEntity<WorkflowInstanceResponse> startingWorkflowInstance(ZeebeBrokerClient client, String authHash, String workflowId, String params) {
        WorkflowInstanceResponse response = new WorkflowInstanceResponse();
        ResponseStatus responseStatus = new ResponseStatus();
        HttpStatus httpStatus;

        try {
            GatewayOuterClass.CreateWorkflowInstanceRequest createWorkflowInstanceRequest = GatewayOuterClass.CreateWorkflowInstanceRequest.newBuilder()
                    .setBpmnProcessId(workflowId)
                    .setVersion(LATEST_VERSION)
                    .setVariables(params)
                    .build();

            GatewayOuterClass.CreateWorkflowInstanceResponse responseFromZeebe =
                    zeebeBrokerClient.createWorkflowInstance(createWorkflowInstanceRequest
                            , authHash);

            WorkflowInstance instance = new WorkflowInstance();
            instance.setBpmnProcessId(responseFromZeebe.getBpmnProcessId());
            instance.setVersion(responseFromZeebe.getVersion());
            instance.setWorkflowInstanceKey(responseFromZeebe.getWorkflowInstanceKey());
            instance.setWorkflowKey(responseFromZeebe.getWorkflowKey());
            response.setWorkflowInstance(instance);

            responseStatus.status(ResponseStatus.StatusEnum.SUCCESS);
            responseStatus.message("Instance succesfully started!");

            httpStatus = HttpStatus.OK;
            LOG.debug("Instance is created: {}", instance.toString());

            showWorkflowClient.processWorknoteCandidate(params, responseFromZeebe.getWorkflowInstanceKey());

        } catch (StatusRuntimeException e) {
            ResponseEntity<ResponseStatus> responseEntity = getResponseEntityFromStatusCode(e);
            responseStatus = responseEntity.getBody();
            httpStatus = responseEntity.getStatusCode();
        }
        response.setResponseStatus(responseStatus);
        return new ResponseEntity<>(response, httpStatus);
    }

    private ResponseEntity<ResponseStatus> updatingWorkflowInstance(ZeebeBrokerClient client, String authHash, Long elementInstanceId, String params) {
        ResponseStatus response = new ResponseStatus();
        HttpStatus httpStatus;

        try {

            GatewayOuterClass.SetVariablesResponse responseFromZeebe = zeebeBrokerClient.setVariables(
                    GatewayOuterClass.SetVariablesRequest.newBuilder()
                            .setElementInstanceKey(elementInstanceId)
                            .setVariables(params)
                            .build()
                    , authHash);

            response.status(ResponseStatus.StatusEnum.SUCCESS);
            response.message("Successfully updated variables.");

            httpStatus = HttpStatus.OK;
            LOG.debug("Instance is updated: {}", responseFromZeebe.toString());

        } catch (StatusRuntimeException e) {
            return getResponseEntityFromStatusCode(e);
        }
        return new ResponseEntity<>(response, httpStatus);
    }
}
