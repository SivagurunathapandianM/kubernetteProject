package com.swissre.zeebeService.util;

public class EnvironmentEnum {
    public enum ENV_ENUM {DEV, NONPROD, PROD}
}
