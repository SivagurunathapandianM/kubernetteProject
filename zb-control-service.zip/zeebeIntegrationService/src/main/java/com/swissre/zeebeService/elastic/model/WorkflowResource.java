package com.swissre.zeebeService.elastic.model;

import com.google.gson.annotations.SerializedName;

public class WorkflowResource {
    @SerializedName("resourceType")
    private String resourceType;
    @SerializedName("resourceName")
    private String resourceName;
    @SerializedName("resource")
    private String resource;

    public String getResourceType() {
        return resourceType;
    }

    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }
}
