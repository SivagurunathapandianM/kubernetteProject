package com.swissre.zeebeService.util.eva;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.zeebeService.util.CustomProxySelector;
import com.swissre.zeebeService.util.EnvironmentEnum;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.ProxySelector;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class EvaTicketHandler {
    private static final Logger LOG = LogManager.getLogger(EvaTicketHandler.class);

    public int createEvaTicket(EnvironmentEnum.ENV_ENUM env_enum, String errorPrefix, String bearerToken) throws IOException, InterruptedException {
        ProxySelector.setDefault(new CustomProxySelector("gate-zrh.swissre.com", "8080"));
        HashMap<String, Object> evaParams = new HashMap<>();
        if (env_enum == EnvironmentEnum.ENV_ENUM.PROD) {
            evaParams.put("assignment_group", "Automation OrchestrationServices");
            HashMap<String, String> evaInsideParams = new HashMap<>();
            evaInsideParams.put("sr_webhook_OASISOperations", System.getenv("EVAWebHookUri"));
            evaInsideParams.put("sr_teams_Var1", "text message");
            evaInsideParams.put("text", "Zb-control " + errorPrefix + " -  rpc error: code = ResourceExhausted desc = Reached maximum capacity of requests handled");
            evaParams.put("params", evaInsideParams);
        }
        Calendar cal = Calendar.getInstance();
        cal.setTime( new Date());
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        evaParams.put("uniqueid", errorPrefix + "_" + cal.getTimeInMillis());
        evaParams.put("apmid", "SCO");
        evaParams.put("action", "incident");
        evaParams.put("cmdbci", "SCO.prod");
        evaParams.put("environment", "prod");
        evaParams.put("shortmsg", "Zb-control -  rpc error: code = ResourceExhausted desc = Reached maximum capacity of requests handled");
        evaParams.put("fullmsg", "Zb-control gets a capacity reached for a workflow instance creation, a ticket shall be raised to the AOS team to do the corrective action (killing the leader pod).");
        evaParams.put("severity", "MEDIUM");
        evaParams.put("watchlist", "tecscoci");
        evaParams.put("sr_userid", "tecscoci");
        evaParams.put("workplace_id", "chr5ae7c");
        evaParams.put("sr_sms", "+41782582686");
        evaParams.put("sr_email", "attila_monostori@rcomext.com");
        evaParams.put("sr_emailcc", "LST.CETO.PI.AO@swissre.com");
        evaParams.put("source", "DynamicEvent");
        evaParams.put("it_product", "Data Exchange");
        evaParams.put("close_mode", "itsmclose");
        evaParams.put("time_toclose", "3600");
        evaParams.put("is_occ_involved", "false");
        evaParams.put("occ_group", "decentral");
        evaParams.put("runbook", "string");

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest evaRequest = HttpRequest.newBuilder()
                .uri(URI.create(System.getenv("EVAItGtmUri")))
                .POST(HttpRequest.BodyPublishers.ofString(new ObjectMapper().writeValueAsString(evaParams)))
                .headers("Authorization", "Bearer " + bearerToken)
                .headers("Content-Type", "application/json")
                .headers("Accept", "application/json")
                .build();

        HttpResponse<String> response = client.send(evaRequest,
                HttpResponse.BodyHandlers.ofString());
        LOG.info(response.body());
        return response.statusCode();
    }
}

