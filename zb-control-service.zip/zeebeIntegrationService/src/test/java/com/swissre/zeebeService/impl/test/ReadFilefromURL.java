package com.swissre.zeebeService.impl.test;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import org.junit.Ignore;
import org.junit.Test;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class ReadFilefromURL {

	@Ignore
	public void getBPMfilefromremotelocation() {
		try {
			System.out.println("Started the file");
			URL url = new URL(
					"https://swissre.visualstudio.com/SCO-OrchestrationPlatform/_git/orchestration-platform?path=%2FWorkflows%2FWAS_RoleManagement.bpmn&version=GBMI-729-Workflow");
			InputStream is;
			is = url.openStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			String line = br.readLine();
			System.out.println("FILE:" + line);

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void transferFileFromRemote() throws SftpException, IOException 
	{
		JSch jsch;
		Session session = null;
		Channel channel = null;
	    ChannelSftp sftpChannel = null;
	     
		System.out.println("connecting..."+"172.22.1.4");
		try {
			jsch = new JSch();
			char quotes ='"';
	        String passwordd = "Sreeram"+quotes+"1992";
	        
			session = jsch.getSession("s9pnqm", "172.22.1.4",9443);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(passwordd);
			
			session.connect();

			channel = session.openChannel("ftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;

		} catch (JSchException e) {
			e.printStackTrace();
		}
		
		System.out.println("Going to download file from remote location");	
		byte[] buffer = new byte[1024];
		BufferedInputStream bis;
		String cdDir = "/Workflows/";
		sftpChannel.cd(cdDir);
		File file = new File("WAS_RoleManagement.bpmn");
		bis = new BufferedInputStream(sftpChannel.get(file.getName()));
		
		System.out.println("File content"+bis.read(buffer));
		
		System.out.println("disconnecting...");
		sftpChannel.disconnect();
		channel.disconnect();
        session.disconnect();
	}
		

}
