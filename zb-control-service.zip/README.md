# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)

### Licences
* Apache 2.0
    ```
    Copyright 2020 Apache 2.0
    
    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at
    
        http://www.apache.org/licenses/LICENSE-2.0
    
    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
    ```

* Eclipse Public License 1.0
    ```
    Copyright 2020 EPL 1.0
    
    Eclipse Public License, Version 1.0 (EPL-1.0)
    THE ACCOMPANYING PROGRAM IS PROVIDED UNDER THE TERMS OF THIS ECLIPSE 
    PUBLIC LICENSE ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION 
    OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE OF THIS AGREEMENT.
    ```
    
* Eclipse Public License 2.0
    ```
    Copyright 2020 EPL 2.0
    
    Eclipse Public License - v 2.0
    THE ACCOMPANYING PROGRAM IS PROVIDED UNDER THE TERMS OF THIS ECLIPSE
    PUBLIC LICENSE (“AGREEMENT”). ANY USE, REPRODUCTION OR DISTRIBUTION 
    OF THE PROGRAM CONSTITUTES RECIPIENT'S ACCEPTANCE OF THIS AGREEMENT.
    ```
    
* GNU Lesser General Public License 2.1
    ```
    Copyright 2020 LGPL 2.1
    
    GNU LESSER GENERAL PUBLIC LICENSE
    Version 2.1, February 1999
    
    Copyright (C) 1991, 1999 Free Software Foundation, Inc.
    51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
    Everyone is permitted to copy and distribute verbatim copies
    of this license document, but changing it is not allowed.
    
    [This is the first released version of the Lesser GPL.  It also counts
     as the successor of the GNU Library Public License, version 2, hence
     the version number 2.1.]
    ```
    
* GNU Lesser General Public License 3.0
    ```
    Copyright 2020 LGPL 3.0
    
    GNU LESSER GENERAL PUBLIC LICENSE
    Version 3, 29 June 2007
    
    Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>
    
    Everyone is permitted to copy and distribute verbatim copies of this license
     document, but changing it is not allowed.
    
    This version of the GNU Lesser General Public License incorporates the terms
     and conditions of version 3 of the GNU General Public License, supplemented
      by the additional permissions listed below.
    ```
    
* GNU General Public License 2.0
    ```
    Copyright 2020 GPL 2.0
    
    GNU GENERAL PUBLIC LICENSE
    Version 2, June 1991
    
    Copyright (C) 1989, 1991 Free Software Foundation, Inc.  
    51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
    
    Everyone is permitted to copy and distribute verbatim copies
    of this license document, but changing it is not allowed.
    ```
    
* GNU General Public License 3.0
    ```
    Copyright 2020 GPL 3.0
    
    GNU GENERAL PUBLIC LICENSE
    Version 3, 29 June 2007
    
    Copyright © 2007 Free Software Foundation, Inc. <https://fsf.org/>
    
    Everyone is permitted to copy and distribute verbatim copies of this license
     document, but changing it is not allowed.
    ```
    
* Berkeley Software Distribution (BSD) License
    ```
    Copyright 2020 BSD
    
    BSD licenses are a family of permissive free software licenses, imposing minimal
    restrictions on the use and distribution of covered software. This is in 
    contrast to copyleft licenses, which have share-alike requirements. The original
    BSD license was used for its namesake, the Berkeley Software Distribution (BSD),
    a Unix-like operating system. The original version has since been revised, and
    its descendants are referred to as modified BSD licenses.
    
    BSD is both a license and a class of license (generally referred to as BSD-like).
    The modified BSD license (in wide use today) is very similar to the license
    originally used for the BSD version of Unix. The BSD license is a simple license
    that merely requires that all code retain the BSD license notice if 
    redistributed in source code format, or reproduce the notice if redistributed
    in binary format. The BSD license (unlike some other licenses) does not require
    that source code be distributed at all.
    ```
    
 * Berkeley Software Distribution (BSD-2) License
     ```
     Copyright 2020 BSD-2
     
     BSD licenses are a family of permissive free software licenses, imposing minimal
     restrictions on the use and distribution of covered software. This is in 
     contrast to copyleft licenses, which have share-alike requirements. The original
     BSD license was used for its namesake, the Berkeley Software Distribution (BSD),
     a Unix-like operating system. The original version has since been revised, and
     its descendants are referred to as modified BSD licenses.
     
     BSD is both a license and a class of license (generally referred to as BSD-like).
     The modified BSD license (in wide use today) is very similar to the license
     originally used for the BSD version of Unix. The BSD license is a simple license
     that merely requires that all code retain the BSD license notice if 
     redistributed in source code format, or reproduce the notice if redistributed
     in binary format. The BSD license (unlike some other licenses) does not require
     that source code be distributed at all.
     ```
     
  * Berkeley Software Distribution (BSD-3) License
      ```
      Copyright 2020 BSD-3
      
      BSD licenses are a family of permissive free software licenses, imposing minimal
      restrictions on the use and distribution of covered software. This is in 
      contrast to copyleft licenses, which have share-alike requirements. The original
      BSD license was used for its namesake, the Berkeley Software Distribution (BSD),
      a Unix-like operating system. The original version has since been revised, and
      its descendants are referred to as modified BSD licenses.
      
      BSD is both a license and a class of license (generally referred to as BSD-like).
      The modified BSD license (in wide use today) is very similar to the license
      originally used for the BSD version of Unix. The BSD license is a simple license
      that merely requires that all code retain the BSD license notice if 
      redistributed in source code format, or reproduce the notice if redistributed
      in binary format. The BSD license (unlike some other licenses) does not require
      that source code be distributed at all.
      ```
    
 * W3C DOCUMENT LICENSE
     ```
     Copyright 2020 W3C
     
     THIS WORK IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS OR
     WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, WARRANTIES OF 
     MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE 
     SOFTWARE OR DOCUMENT WILL NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, 
     TRADEMARKS OR OTHER RIGHTS.
     
     COPYRIGHT HOLDERS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL OR 
     CONSEQUENTIAL DAMAGES ARISING OUT OF ANY USE OF THE SOFTWARE OR DOCUMENT.
     
     The name and trademarks of copyright holders may NOT be used in advertising or 
     publicity pertaining to the work without specific, written prior permission. Title 
     to copyright in this work will at all times remain with copyright holders.
     ```
     
  * CCO 1.0 DOCUMENT LICENSE
      ```
      Copyright 2020 CCO-1.0
      
      CREATIVE COMMONS CORPORATION IS NOT A LAW FIRM AND DOES NOT PROVIDE LEGAL SERVICES. 
      DISTRIBUTION OF THIS DOCUMENT DOES NOT CREATE AN ATTORNEY-CLIENT RELATIONSHIP. 
      CREATIVE COMMONS PROVIDES THIS INFORMATION ON AN "AS-IS" BASIS. CREATIVE COMMONS 
      MAKES NO WARRANTIES REGARDING THE USE OF THIS DOCUMENT OR THE INFORMATION OR WORKS 
      PROVIDED HEREUNDER, AND DISCLAIMS LIABILITY FOR DAMAGES RESULTING FROM THE USE OF 
      THIS DOCUMENT OR THE INFORMATION OR WORKS PROVIDED HEREUNDER.
      ```
      
  * MIT DOCUMENT LICENSE
      ```
      Copyright 2020 MIT
            
      Permission is hereby granted, free of charge, to any person obtaining a copy of 
      this software and associated documentation files (the "Software"), to deal in the 
      Software without restriction, including without limitation the rights to use, copy, 
      modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
      and to permit persons to whom the Software is furnished to do so, subject to the 
      following conditions:
      
      The above copyright notice and this permission notice shall be included in all 
      copies or substantial portions of the Software.
      
      THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
      INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
      PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
      HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION 
      OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
      SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
      ```