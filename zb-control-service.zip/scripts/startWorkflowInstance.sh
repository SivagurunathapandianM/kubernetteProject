#!/usr/bin/env bash

for i in "First attempt..." "Second attempt..." "Last attempt...";do
		echo "Wait patiently 10 secs for app to be available..."
		sleep 10
		response=$(curl --header 'Content-Type: application/json' --header 'Accept: application/json' https://zb-control.sco-dev.swissre.com/workflowInstance/workflowId -d '{"params": "{}"}')
        echo ${response}
		status=$(grep -Po '"status":.*?[^\\]"' <<< "$response")
		if [[ ${status} == '"status":"FAILED"' ]];then
				echo "OK response, exiting"
				exit 0;
		fi
done

# All attempt failed
error "All attempt failed, exiting with error code=1"
exit 1