#!/usr/bin/env bash

for i in "First attempt..." "Second attempt..." "Last attempt...";do
		echo "Wait patiently 30 secs for app to be available..."
		sleep 30
		response=$(curl -X POST -H 'Content-Type: multipart/form-data' -H 'Accept: application/json' {"type":"formData"}  -d 'file=`pwd`/../src/test/resources/SR_WAS_ROLEMANAGEMENT_P.bpmn' 'http://zb-control.sco-dev.caas.swissre.com/deployWorkflow')
		status=$(grep -Po '"status":.*?[^\\]"' <<< "$response")
		if [[ ${status} == '"status":"FAILED"' ]];then
				echo "OK response, exiting"
				exit 0;
		fi
done

# All attempt failed
echo "All attempt failed, exiting with error code=1"
exit 1