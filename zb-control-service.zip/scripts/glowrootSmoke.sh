#!/usr/bin/env bash

for i in "First attempt..." "Second attempt..." "Last attempt...";do
		echo "Wait patiently 30 secs for app to be available..."
		sleep 30
		response=$(curl --write-out %{http_code} --silent --output /dev/null -k https://zb-control-apm.sco-dev.swissre.com)
		echo "HTTP Status Code: "$response
		if [ $response == "200" ];then
				echo "OK response, exiting"
				exit 0;
		fi
done

# All attempt failed
error "All attempt failed, exiting with error code=1"
exit 1
