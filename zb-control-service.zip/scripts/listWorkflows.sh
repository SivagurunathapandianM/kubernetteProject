#!/usr/bin/env bash

for i in "First attempt..." "Second attempt..." "Last attempt...";do
		echo "Wait patiently 10 secs for app to be available..."
		sleep 10
		response=$(curl -k https://zb-control.sco-dev.swissre.com/listWorkflows?resourceName=dhdf)
		status=$(grep -Po '"status":.*?[^\\]"' <<< "$response")
		if [[ ${status} == '"status":"SUCCESS"' ]];then
				echo "OK response, exiting"
				exit 0;
		fi
done

# All attempt failed
error "All attempt failed, exiting with error code=1"
exit 1